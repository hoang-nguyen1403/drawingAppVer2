classdef AKSLibrary < handle
% AKSLibrary CLASS

% author: Phuong Huynh, Akselos S.A 
% email: (phuong.huynh@akselos.com)
% license: MIT (see license_mit.txt)    

    properties
        name = [];
        configuration = load_config('akselos_config.json');
        collections = struct();
        physics = struct();
        mapping_functions = struct();
        meshes = struct('components',struct(),'faces',struct());
        rb_component_face_dof_objects = struct();
        rb_component_faces = struct();
        rb_components = struct();
        rb_ref_components = struct();
        units = [];
        components = struct();
    end
    methods
        % ----- MANAGEMENT METHODS ----- %
        % -----
        function obj = AKSLibrary(collname, sync)
            % sync once a day
            if diff([datenum(obj.configuration.mui_version.date), datenum(now)]) > 1.0
                if not(isfield(obj.configuration.server,'auto_update'))
                    sync_mui
                elseif obj.configuration.server.auto_update
                    sync_mui
                end
            end
            
            cp = mfilename('fullpath'); I = regexp(regexprep(cp,'\','/'),'/'); cp = cp(1:I(end));
            
            if not(exist([cp,'collections'],'dir'))
                mkdir([cp,'collections']);
            end
            if not(exist('sync','var'))
                sync = 0;
            end
            fname = [cp,'collections/',collname,'.acl'];
            % check if a collection is existed
            if sync || not(exist(fname,'file'))
                % try downloading it
                fprintf('Connect to server and sync collection (%s)... ',collname);
                server = obj.configuration.server;
                params = struct('type', 'download', 'data', ['collections/',collname,'.acl']);
                [response, status] = server_post(server, params);
                if length(response)<2000 % noway to tell if we're failed
%                     error_msg = loadjson(char(response));
%                     error_msg.developer_message
                    error('Server error: Collection not found!')
                end
                fprintf('done! (%2.2f MB)\n', length(response)/(2^20));
                fid = fopen(fname,'w');
                fwrite(fid,response,'uint8');
                fclose(fid);
            end
            
            % Create a Java file of the ZIP filename.
            zipJavaFile = java.io.File(fname);
            % Create a Java ZipFile and validate it.
            zipFile = org.apache.tools.zip.ZipFile(zipJavaFile);
            % Extract the entries from the ZipFile.
            entries = zipFile.getEntries;
            % Generate a file list
            filelist={};
            while entries.hasMoreElements
                filelist = cat(1,filelist,char(entries.nextElement));
            end
            % units
            for i = 1:length(filelist)
                % collections
                if regexp(filelist{i},'collection.json')
                    strdat = stream2bytes(zipFile.getInputStream(zipFile.getEntry(filelist{i})));
                    name = extract_name(filelist{i});
                    obj.collections.(collname) = loadjson(strdat);
                end
                % component meshes
                if regexp(filelist{i},'meshes/components/')
                    if not(isempty(regexp(filelist{i},'\.exo','once'))) && isempty(regexp(filelist{i},'pickle'))
                        strdat = stream2bytes(zipFile.getInputStream(zipFile.getEntry(filelist{i})),1);
                        name = extract_name(filelist{i});
                        % write to a immediate file then read back in then delete it
                        fname = 'tmp_exo.exo';
                        fid = fopen(fname,'w');
                        fwrite(fid,strdat,'uint8');
                        fclose(fid);
                        mesh = EXO_reader(fname);
                        delete(fname);
                        obj.meshes.components.(name) = mesh;
                    end
                end
%                 % mapping functions
%                 if regexp(filelist{i},'mapping_functions/')
%                     strdat = stream2bytes(zipFile.getInputStream(zipFile.getEntry(filelist{i})));
%                     name = extract_name(filelist{i});
%                     obj.mapping_functions.(name) = loadjson(strdat);
%                 end
                % rb_components
                if regexp(filelist{i},'types_json/rb_components/')
                    if not(isempty(regexp(filelist{i},'\.json','once')))
                        strdat = stream2bytes(zipFile.getInputStream(zipFile.getEntry(filelist{i})));
                        name = extract_name(filelist{i});
                        obj.rb_components.(name) = loadjson(strdat);
                    end
                end
                % rb_ref_components
                if regexp(filelist{i},'types_json/rb_ref_components/')
                    if not(isempty(regexp(filelist{i},'\.json','once')))
                        strdat = stream2bytes(zipFile.getInputStream(zipFile.getEntry(filelist{i})));
                        name = extract_name(filelist{i});
                        obj.rb_ref_components.(name) = loadjson(strdat);
                        if not(isfield(obj.rb_ref_components.(name),'collection'))
                            obj.rb_ref_components.(name).collection = collname;
                        end
                    end
                end
            end
            obj.name = collname;
            
            fname = [cp,'physics.acl'];
            % Create a Java file of the ZIP filename.
            zipJavaFile  = java.io.File(fname);
            % Create a Java ZipFile and validate it.
            zipFile = org.apache.tools.zip.ZipFile(zipJavaFile);
            % Extract the entries from the ZipFile.
            entries = zipFile.getEntries;
            % Generate a file list
            filelist={};
            while entries.hasMoreElements
                filelist = cat(1,filelist,char(entries.nextElement));
            end
            % units
            for i = 1:length(filelist)
                % units
                if regexp(filelist{i},'units.json')
                    strdat = stream2bytes(zipFile.getInputStream(zipFile.getEntry(filelist{i})));
                    obj.units = loadjson(strdat);
                end
                % physics
                if regexp(filelist{i},'physics/')
                    if not(isempty(regexp(filelist{i},'\.json','once')))
                        strdat = stream2bytes(zipFile.getInputStream(zipFile.getEntry(filelist{i})));
                        name = extract_name(filelist{i});
                        obj.physics.(name) = loadjson(strdat);
                    end
                end
            end
            
            obj.parse_units();
        end
        % -----
        function obj = load_from_path(obj)
            % units
            obj.units = loadjson([obj.configuration.json_path,'/json/units.json']);
            % collections
            dpath = [obj.configuration.json_path,'/json/collections'];
            files = dir(dpath);
            for i = 1:length(files)
                if not(isempty(regexp(files(i).name,'.json','once')))
                    collection = loadjson([dpath,'/',files(i).name]);
                    obj.collections.(collection.name) = collection;
                end
            end
            % physics
            dpath = [obj.configuration.json_path,'/json/physics'];
            files = dir(dpath);
            for i = 1:length(files)
                if not(isempty(regexp(files(i).name,'.json','once')))
                    physic = loadjson([dpath,'/',files(i).name]);
                    obj.physics.(physic.name) = physic;
                end
            end
            % component meshes
            dpath = [obj.configuration.json_path,'/json/meshes/components'];
            files = dir(dpath);
            for i = 1:length(files)
                if not(isempty(regexp(files(i).name,'.exo','once'))) && isempty(regexp(files(i).name,'pickled','once'))
                    mesh_name = files(i).name(1:end-4);
                    mesh = EXO_reader([dpath,'/',files(i).name]);
                    obj.meshes.components.(mesh_name) = mesh;
                end
            end
            % mapping_functions
            dpath = [obj.configuration.json_path,'/json/mapping_functions'];
            files = dir(dpath);
            for i = 1:length(files)
                if not(isempty(regexp(files(i).name,'.json','once')))
                    mapping_function = loadjson([dpath,'/',files(i).name]);
                    mapping_function_name = mapping_function.name;
                    obj.mapping_functions.(mapping_function_name) = mapping_function;
                end
            end
            % rb_components
            dpath = [obj.configuration.json_path,'/json/rb_components'];
            files = dir(dpath);
            for i = 1:length(files)
                if not(isempty(regexp(files(i).name,'.json','once')))
                    rb_component = loadjson([dpath,'/',files(i).name]);
                    obj.rb_components.(rb_component.name) = rb_component;
                end
            end
            % rb_ref_components
            dpath = [obj.configuration.json_path,'/json/rb_ref_components'];
            files = dir(dpath);
            for i = 1:length(files)
                if not(isempty(regexp(files(i).name,'.json','once')))
                    rb_ref_component = loadjson([dpath,'/',files(i).name]);
                    obj.rb_ref_components.(rb_ref_component.name) = rb_ref_component;
                end
            end
        end
        % -----
        function parse_units(obj)
            collnames = fieldnames(obj.collections);
            for i = 1:length(collnames)
                coll_name = collnames{i};
                ptype = obj.collections.(coll_name).physics;
                obj.collections.(coll_name).units = obj.physics.(ptype).units;
                dim_keys = fieldnames(obj.collections.(coll_name).dimensional_variables);
                dimensional_variables = {};
                for j = 1:length(dim_keys)
                    dim_val = obj.collections.(coll_name).dimensional_variables.(dim_keys{j});
                    I = regexp(dim_val,' ');
                    if isempty(I)
                        dimensional_variables.(dim_keys{j}) = struct('val',str2double(dim_val),'unit','');
                    else
                        dimensional_variables.(dim_keys{j}) = struct('val',str2double(dim_val(1:I-1)),'unit',dim_val(I+1:end));
                    end
                    eval([dim_keys{j},'=',num2str(dimensional_variables.(dim_keys{j}).val),';']);
                end
                % dummy values;
                m = 1; s = 1; kg = 1;
                % evaluate scaling values
                unit_keys = fieldnames(obj.collections.(coll_name).units);
                for j = 1:length(unit_keys)
                    obj.collections.(coll_name).units.(unit_keys{j}).scaling_val = eval(obj.collections.(coll_name).units.(unit_keys{j}).scaling);
                end
            end
        end
        % -----
        function list_components(obj)
            component_names = fieldnames(obj.rb_ref_components);
            fprintf('Library: %s\n Components:\n',obj.name);
            for i = 1:length(component_names)
                fprintf('%60s\n',component_names{i});
            end
        end
        % -----
        function component = create_component(obj, name, id)
            lib_data = struct();
            lib_data.ref = obj.rb_ref_components.(name);
            lib_data.def = obj.rb_components.(obj.rb_ref_components.(name).component_type);
            if isfield(lib_data.ref,'collection')
                lib_data.collection = obj.collections.(lib_data.ref.collection);
            else
                collection_names = fieldnames(obj.collections);
                lib_data.collection = obj.collections.(collection_names{1});
            end
            lib_data.physics = obj.physics.(lib_data.collection.physics);
            % mesh
            lib_data.mesh = obj.meshes.components.(obj.rb_ref_components.(name).component_type);
            % mapping functions
            regnames = fieldnames(lib_data.ref.mapping_function);
            for i = 1:length(regnames)
                mapname = lib_data.ref.mapping_function.(regnames{i});
                if not(strcmp(mapname,'identity'))
                    if iscell(lib_data.ref.xyz_functions)
                        for j = 1:length(lib_data.ref.xyz_functions)
                            if strcmp(lib_data.ref.xyz_functions{j}.name,mapname)
                                break;
                            end
                        end
                        lib_data.mesh.mapping_functions.(mapname) = lib_data.ref.xyz_functions{j};
                    else
                        lib_data.mesh.mapping_functions.(mapname) = lib_data.ref.xyz_functions;
                    end
                else
                    lib_data.mesh.mapping_functions.(mapname) = [];
                end
            end
            component = AKSComponent(lib_data);
            if exist('id','var')
                component.id = id;
            end
        end
    end
end

function outdat = stream2bytes(stream, keepbin)
    byteoutstream = java.io.ByteArrayOutputStream();
    streamCopier = com.mathworks.mlwidgets.io.InterruptibleStreamCopier.getInterruptibleStreamCopier;
    streamCopier.copyStream(stream, byteoutstream);
    sbytes = byteoutstream.toByteArray();
    outdat = (uint8(int16(sbytes) + 256*int16(sbytes < 0)))';
    if not(exist('keepbin','var')) || keepbin == 0
        outdat = char(outdat);
    end
end

function name = extract_name(fname)
    slashloc = regexp(fname,'/');
    dotloc = regexp(fname,'\.');
    name = fname(slashloc(end)+1:dotloc(end)-1);
end

function [response, status] = server_post(server,params)
    if ~isfield(params,'username') || ~isfield(params,'password')
        params.username = server.username;
        params.password = server.password;
    end
    headers = struct('name',{'content-type','Accept-Encoding'},...
                     'value',{'application/x-www-form-urlencoded', 'identity'});
    params = savejson('',params);
    url = ['http://',server.ip_address,':',num2str(server.http_port),server.prefix,'/'];
    [response, extra] = urlread2(url,'POST',params,headers,1);
%     response = char(response);
    status = extra.status;
end