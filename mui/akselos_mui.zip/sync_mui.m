function sync_mui(url)

if not(exist('url','var'))
    url = 'http://akselos.com/atpwui/test/mui';
end

mui_fname = 'akselos_mui.zip';
url = [url,'/',mui_fname];
    
currentCD = cd;

akselosCD = fileparts(which('sync_mui'));

cd(akselosCD);

% fetch MUI package
try
    fprintf('%s','Checking MUI version... ');
    urlwrite(url,mui_fname);
    mui_info = dir(mui_fname);
catch
    fprintf('%s\n%s','error!','An unknown error occured. Please try again later.');
end

is_update = 0;
% check for existing MUI
config_fname = 'akselos_config.json';
if not(isempty(which(config_fname)))
    current_config = loadjson(config_fname);
    % check if we need to update...
    if not(isfield(current_config,'mui_version')) || (current_config.mui_version.bytes ~= mui_info.bytes)
        is_update = 1;
    end
else
    is_update = 1;
end

if is_update
    unzip(mui_fname);
    fprintf('%s\n', 'synced!');
else
    fprintf('%s\n', 'up-to-date!');
end

rehash;

% update configuration data
config_fname = 'akselos_config.json';
current_config = loadjson(config_fname);
current_config.mui_version = struct('date', mui_info.date,...
                                        'bytes', mui_info.bytes);
savejson('',current_config,config_fname);

% clean up
delete(mui_fname);

cd(currentCD);

end