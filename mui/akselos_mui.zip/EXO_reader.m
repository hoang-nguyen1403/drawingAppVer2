function mesh = EXO_reader(fname)

% EXO Mesh parser utility

% author: Phuong Huynh, Akselos S.A 
% email: (phuong.huynh@akselos.com)
% license: MIT (see license_mit.txt)

show_log = 0;

ncid = netcdf.open(fname, 'NOWRITE');

% read coordinations of all nodes
try netcdf.inqVarID(ncid,'coord');
    node = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coord'));
catch exception
    node = [netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordx')),...
        netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordy')),...
        netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordz'))];
end
% number of nodes
[tmp, node_num] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_nodes'));
% all element ids
all_elem_id = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,'eb_prop1')));
% number of block
[tmp, num_el_blk] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_el_blk'));
elem = []; tnum = [];
edge = []; enum = []; all_edge_id = [];
blk_part_names = [];
blk_map_names = [];
count = 1;
% read each block
elem_type = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,'connect1'),'elem_type');
for i = 1:num_el_blk
    elem_tmp = netcdf.getVar(ncid,netcdf.inqVarID(ncid,['connect',num2str(i)]))';
    blk_elem_type = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['connect',num2str(i)]),'elem_type');
    if strcmp(blk_elem_type,elem_type)
        elem = [elem;elem_tmp];
        tnum = [tnum; all_elem_id(i)*ones(length(elem_tmp),1)];
        % reading part/map information
        try
            blk_part_names{count} = strtrim(netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['connect',num2str(i)]),'part_name'));
            blk_map_names{count} = strtrim(netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['connect',num2str(i)]),'map_name'));
        catch
            blk_part_names{count} = 'default';
            blk_map_names{count} = 'identity';
        end
        blk_elem{i} = elem_tmp;
        blk_node{i} = unique(elem_tmp(:));
        count = count + 1;
    else
        all_edge_id = [all_edge_id; all_elem_id(i)];
        edge = [edge;elem_tmp];
        enum = [enum; all_elem_id(i)*ones(length(elem_tmp),1)];
    end
end
[tmp, elem_num] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_elem'));

% read block names
try tmp = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'eb_names'));
    for i = 1:num_el_blk
        blk_name = deblank(tmp(:,i)');
        if isempty(blk_name)
            blk_name = ['region_',num2str(i)];
        end
        blk_names{i} = blk_name;
    end
catch exception
    blk_names = cell(num_el_blk);
    for i = 1:num_el_blk
        blk_names{i} = ['region_',num2str(i)];
    end
end

all_elem_id = setdiff(all_elem_id, all_edge_id);
if show_log
    fprintf(' Mesh: %d nodes, %d elements\n', node_num, elem_num);
    fprintf(' ELEMENT SOLID BLOCKS: %d; ID = %s (%s)\n', length(all_elem_id), regexprep(num2str(all_elem_id'),'  ',', '), elem_type);
    if length(all_edge_id)>0
        fprintf(' ELEMENT EDGE BLOCKS: %d; ID = %s (%s)\n', length(all_edge_id), regexprep(num2str(all_edge_id'),'  ',', '), blk_elem_type);
    end
end

try
    elem_map = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,'elem_map')));
    if norm(elem_map - (1:1:length(elem_map))'), error(''),
    end
end

all_elem_ss_id = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,'ss_prop1')));
[tmp, num_elem_ss] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_side_sets'));

% read sideset names
try tmp = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'ss_names'));
    for i = 1:num_elem_ss
        ss_names{i} = deblank(tmp(:,i)');
    end
catch exception
    ss_names = cell(num_elem_ss);
    for i = 1:num_elem_ss
        ss_names{i} = ['surface_',num2str(i)];
    end
end

% EXODUS MESH INDICES
% ennum = element nodes number
% snnum = surface nodes number

if strcmp(elem_type,'TETRA') || strcmp(elem_type,'TETRA4')
    face_indices = [1,2,4;2,3,4;1,4,3;1,3,2];
    ennum = 4; snnum = 3;
    
elseif strcmp(elem_type,'TETRA10')
    face_indices = [1,2,4,5,9,8;2,3,4,6,10,9;1,4,3,8,10,7;1,3,2,7,6,5];
    ennum = 10; snnum = 6;

elseif strcmp(elem_type(1:4),'HEX8')
    face_indices = [1,2,6,5;2,3,7,6;3,4,8,7;1,5,8,4;1,4,3,2;5,6,7,8];
    ennum = size(elem,2); snnum = 4;
    
elseif length(elem_type)>=5 && strcmp(elem_type(1:5),'HEX20')
    face_indices = [1,2,6,5,9,14,17,13;2,3,7,6,10,15,18,14;...
                    3,4,8,7,11,16,19,15;1,5,8,4,13,20,16,12;...
                    1,4,3,2,12,11,10,9;5,6,7,8,17,18,19,20];
    ennum = size(elem,2); snnum = 8;
end

surf = []; snum = [];
elem_tmp = elem';

ss_prop = struct('id','','type','','name','');
for i = 1:num_elem_ss
    % elements in sideset
    elem_ss = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,['elem_ss',num2str(i)]))');
    % side indice of elements
    side_ss = netcdf.getVar(ncid,netcdf.inqVarID(ncid,['side_ss',num2str(i)]))';
    surf_tmp = reshape(elem_tmp(reshape(repmat((elem_ss-1)*ennum,snnum,1)' + face_indices(side_ss,:),1,[])),[],snnum);
    surf = [surf; surf_tmp];
    snum = [snum; all_elem_ss_id(i)*ones(size(surf_tmp,1),1)];
    ss_prop(i).id = all_elem_ss_id(i);
    try
        ss_prop(i).type = strtrim(netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['prop_ss',num2str(i)]),'type'));
        ss_prop(i).name = strtrim(netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['prop_ss',num2str(i)]),'name'));
    catch
        if (ss_prop(i).id >= 100) && (ss_prop(i).id < 200)
            ss_prop(i).type = 'port';
        elseif (ss_prop(i).id >= 200) && (ss_prop(i).id < 250)
            ss_prop(i).type = 'surface_load';
            ss_prop(i).name = ['undefined_',num2str(ss_prop(i).id-199)];            
        elseif (ss_prop(i).id >= 250) && (ss_prop(i).id < 300)
            ss_prop(i).type = 'normal_load';
            ss_prop(i).name = ['undefined_',num2str(ss_prop(i).id-249)];
        elseif (ss_prop(i).id == 300)
            ss_prop(i).type = 'dirichlet';
            ss_prop(i).name = 'dirichlet_surface_xyz';
        elseif (ss_prop(i).id == 301)
            ss_prop(i).type = 'dirichlet';
            ss_prop(i).name = 'dirichlet_surface_xy';
        elseif (ss_prop(i).id == 302)
            ss_prop(i).type = 'dirichlet';
            ss_prop(i).name = 'dirichlet_surface_yz';
        elseif (ss_prop(i).id == 303)
            ss_prop(i).type = 'dirichlet';
            ss_prop(i).name = 'dirichlet_surface_zx';
            ss_prop(i).param = {'u','z'};
        elseif (ss_prop(i).id == 304)
            ss_prop(i).type = 'dirichlet';
            ss_prop(i).name = 'dirichlet_surface_x';
        elseif (ss_prop(i).id == 305)
            ss_prop(i).type = 'dirichlet';
            ss_prop(i).name = 'dirichlet_surface_y';
        elseif (ss_prop(i).id == 306)
            ss_prop(i).type = 'dirichlet';
            ss_prop(i).name = 'dirichlet_surface_z';
        else
            ss_prop(i).type = 'undefined';
        end
    end
    %  patch('Vertices',node,'Faces',surf_tmp,'FaceColor','none'); keyboard
end
[stype_names,temp,I] = unique({ss_prop.type});
if show_log
    fprintf(' SIDESETS: %d; ID = ',num_elem_ss);
    for i = 1:length(stype_names)
        fprintf('%s(%s)', stype_names{i}, regexprep(num2str(all_elem_ss_id(find(I == i))'),'  ',', '));
        if i < length(stype_names)
            fprintf(', ');
        else
            fprintf('\n');
        end
    end
end

try
    all_node_ns_id = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,'ns_prop1')));
    [tmp, num_node_ns] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_node_sets'));
    if show_log
        fprintf(' NODESETS: %d; ID = %s\n', num_node_ns, regexprep(num2str(all_node_ns_id'),'  ',', '));
    end
catch
    num_node_ns = 0;
    all_node_ns_id = [];
end

% Nodeset handle
keyp = []; knum = [];
for i = 1:num_node_ns
    node_ns = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,['node_ns',num2str(i)]))');
    keyp = [keyp; node_ns(:)];
    knum = [knum; all_node_ns_id(i)*ones(length(node_ns),1)];
end

% read part data (only elasticity for now)
try
    [tmp, num_part] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_part'));
    part = struct('name','','mat_name','','mat_type','','E',[],'nu',[],'rho',[]);
    for i = 1:num_part
        part(i).name = strtrim(netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'name'));
        part(i).mat_name = strtrim(netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'mat_name'));
        try
            part(i).mat_type = strtrim(netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'mat_type'));
        catch
            part(i).mat_type = 'none';
        end
        try
            part(i).E = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'E');
            part(i).nu = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'nu');
            part(i).rho = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'rho');
        catch
            part(i).E = 0.0;
            part(i).nu = 0.0;
            part(i).rho = 0.0;
        end
        % dirty Young modulus fix
        try
            part(i).E_min = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'E_min');
            part(i).E_max = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'E_max');
        catch
            if regexp(lower(part(i).mat_name),'steel')
                part(i).E_min = 150e9;
                part(i).E_max = 400e9;
            elseif regexp(lower(part(i).mat_name),'concrete')
                part(i).E_min = 20e9;
                part(i).E_max = 40e9;
            else
                part(i).E_min = 10e9;
                part(i).E_max = 400e9;
            end
        end
        % dirty Poisson ratio fix
        if part(i).nu == 0.0
            if regexp(lower(part(i).mat_name),'steel')
                part(i).nu = 0.3;
            elseif regexp(lower(part(i).mat_name),'concrete')
                part(i).nu = 0.2;
            end     
        end
        try
            part(i).parameter = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['part',num2str(i)]),'parameter');
        catch
            part(i).parameter = '111';
        end 
    end
catch
    part = struct('name','default','mat_type','steel','mat_name','Generic Steel','E',200e9,'nu',0.3,'rho',7850,'parameter','000');
end

% parameters data
try
[tmp, num_param] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_param'));
    parameters = struct('name','','min','','max',[],'default',[]);
    for i = 1:num_param
        parameters(i).name = strtrim(netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['param',num2str(i)]),'name'));
        parameters(i).min = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['param',num2str(i)]),'min');
        parameters(i).max = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['param',num2str(i)]),'max');
        parameters(i).default = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['param',num2str(i)]),'default');
    end
catch
    parameters = [];
end

% read drescription in title
try
    mesh_description = netcdf.getAtt(ncid,netcdf.getConstant('NC_GLOBAL'),'title');
    if regexp(mesh_description,'cubit')
        mesh_description = '';
    end
catch
    mesh_description = '';
end

% read tags
try
    [tmp, num_tag] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_tag'));
    name_tags = cell(1,num_tag);
    for i = 1:num_tag
        name_tags{i} = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,['tag',num2str(i)]),'name');
    end
catch
    name_tags = {};
end

netcdf.close(ncid);

elem = double(elem);
surf = double(surf);

surf = [snum, surf];

starting_snum = 0;
surf_num = size(surf,1);
old_surf = surf(1:surf_num,:);
clear surf;
snum = old_surf(:,1) - starting_snum; % starting port number
surf = old_surf(:,2:end);

allpnum = unique(snum);

% trim port edge data
if exist('portdata','var')
    port_num = length(portdata);
    I = find(snum > port_num);
    snum(I) = [];
    surf(I,:) = [];
else
    portdata = {};
    port_num = length(unique(snum));
end

tr_elem = [];
for i = 1:size(face_indices,1)
    tr_elem = [tr_elem; elem(:,face_indices(i,:))];
end
tmp = tr_elem;
tmp = sort(tmp,2);
[ttmp,Is,Iv] = unique(tmp,'rows');
[sIv,I] = sort(Iv);
dsIv = diff([min(sIv)-1;sIv;max(sIv)+1]);
I1 = all([dsIv(1:end-1),dsIv(2:end)],2);
I2 = find(I1);
tr_elem = tr_elem(I(I2),:);

all_tnum = unique(tnum);
nnum = zeros(node_num,1);
for i = 1:length(all_tnum)
    I = elem(find(tnum == all_tnum(i)),:);
    nnum(unique(I(:))) = all_tnum(i);
end

% % condense mesh
% all_node = unique(tr_elem(:));
% I = zeros(node_num,1); I(all_node) = 1:length(all_node);
% node = node(all_node,:);
% nnum = nnum(all_node,:);
% node_num = length(node);
% surf = I(surf);
% edge = I(edge);
% keyp = I(keyp);
% tr_elem = I(tr_elem);

all_surf = length(tr_elem);
fnum = (length(unique(snum)) + 1)*ones(all_surf,1);
sort_tr_elem = sort(tr_elem,2);
sort_surf = sort(surf,2);
for i = 1:length(surf)
    [tmp, loc] =  ismember(sort_surf(i,:),sort_tr_elem,'rows');
    if loc~=0
        fnum(loc) = snum(i);
    end
end

old_tr_elem = tr_elem;

% % split quads to tris
% if size(elem,2) == 8
%     tr_elem = [tr_elem(:,[1,2,3]); tr_elem(:,[1,3,4])];
%     fnum = [fnum; fnum];
% end

%----------------------------------------------------
% if length(old_tr_elem) == length(surf)
    shell_elem = tr_elem;
% else
%     shell_elem = tr_elem(fnum == (length(unique(snum)) + 1),:);
% end
% find boundary edges
% calculate normals
normal = zeros(length(shell_elem), 3);
for i = 1:length(shell_elem)
    normal(i,:) = cross(node(shell_elem(i,2),:)-node(shell_elem(i,1),:),node(shell_elem(i,3),:)-node(shell_elem(i,1),:));
    normal(i,:) = normal(i,:)/norm(normal(i,:));
end

shell_elem_size = size(tr_elem,2);
switch shell_elem_size
    case 3
        shell_surf = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,1])];
        shell_elem_adj_size = 3;
    case 4
        shell_surf = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,4]);shell_elem(:,[4,1])];
        shell_elem_adj_size = 4;
    case 6
        shell_surf = [shell_elem(:,[1,2,4]);shell_elem(:,[2,3,5]);shell_elem(:,[3,1,6])];
        shell_elem_adj_size = 3;
    case 8
        shell_surf = [shell_elem(:,[1,2,5]);shell_elem(:,[2,3,6]);shell_elem(:,[3,4,7]);shell_elem(:,[4,1,8])];
        shell_elem_adj_size = 4;
end

tr_surf = shell_surf;
etmp = shell_surf;
ee = sort(shell_surf(:,[1,2]),2);
[ee,I,J] = unique(ee,'rows');
shell_surf = shell_surf(I,:);
ne = size(shell_surf,1);
te = reshape(reshape(1:(size(shell_elem,1)*shell_elem_adj_size),size(shell_elem,1),shell_elem_adj_size)',size(shell_elem,1)*shell_elem_adj_size,1);
te = reshape(J(te),shell_elem_adj_size,size(shell_elem,1))';

% find boundary surfs
tmp = sort(tr_surf(:,[1,2]),2);
[ttmp,Is,Iv] = unique(tmp,'rows');
[sIv,I] = sort(Iv);
dsIv = diff([min(sIv)-1;sIv;max(sIv)+1]);
I1 = all([dsIv(1:end-1),dsIv(2:end)],2);
I2 = find(I1);
tr_surf = tr_surf(I(I2),:);

% find a list of adjacent triangles for each triangle
% first, we find duplicated edges and an associated tri list
ttmp = sort(shell_elem,2);
nt = size(shell_elem,1);
trinum = repmat((1:nt)',shell_elem_size,1);
etmp = sort(etmp,2);
[etmp,tags] = sortrows(etmp);
trinum = trinum(tags);
tags = find(all(diff(etmp,[],1)==0,2));
% then we find the list of adjacent tris
tadj = zeros(size(shell_elem,1),shell_elem_adj_size);
tadjcount = zeros(size(shell_elem,1),1);
for i = 1:size(tags,1)
    itmp = [trinum(tags(i)),trinum(tags(i)+1)];
    for j = 1:2
        tadjcount(itmp(j)) = tadjcount(itmp(j))+1;
    end
    tadj(itmp(1),tadjcount(itmp(1))) = itmp(2);
    tadj(itmp(2),tadjcount(itmp(2))) = itmp(1);
end

% find a list of adjacent triangles for each edge
etmp = te(:);
[etmp,tags] = sort(etmp);
trinum = repmat((1:size(te,1))',shell_elem_size,1);
trinum = trinum(tags);
tags = find(diff(etmp)==0); % the share edges
ntags = find(diff(etmp)~=0); % the rest
eadj = zeros(size(shell_surf,1),2);
eadjcount = zeros(size(shell_surf,1),1);
for i = 1:size(etmp,1);
    itmp = etmp(i);
    eadjcount(itmp) = eadjcount(itmp) + 1;
    eadj(itmp,eadjcount(itmp)) = trinum(i);
end
eadj = sort(eadj,2);

tol = 0.8;
eflag = zeros(ne,1);
for i = 1:ne
    if all(eadj(i,:)) && abs(dot(normal(eadj(i,1),:),normal(eadj(i,2),:)))<tol
        eflag(i) = 1;
    end
end

% % vertex normal (for plotting)
% vnormal = zeros(node_num,3);
% for i = 1:size(shell_elem,1)
%     vnormal(shell_elem(i,:),:) = vnormal(shell_elem(i,:),:) + ones(3,1)*normal(i,:);
% end
% vnormal = vnormal./(sqrt(sum(vnormal.*vnormal,2))*ones(1,3));

shell_surf = [shell_surf(find(eflag),:); tr_surf];

allsnum = unique(snum);
alltnum = unique(tnum);

%%% export the data %%%
mesh.description = mesh_description;
% number of elements
mesh.elem = elem;
mesh.node = node;
mesh.edge = edge;
% all external edge surfaces (defined by 3 points)
mesh.tr_elem = tr_elem;
% edge surfaces (defined by 3 points) of all sideset
mesh.surf = surf;
% all external curves except curves in surf
mesh.tr_surf = shell_surf;
% block id of all nodes
mesh.nnum = nnum;
%
mesh.lnum = zeros(length(mesh.tr_surf),1);
% block id of all elements
mesh.tnum = tnum;
% sideset id of all surfaces
mesh.snum = snum;
mesh.enum = enum;
% sideset of 'tr_elem'
mesh.fnum = fnum;
% all meaning values in 'fnum'
mesh.allpnum = allpnum;
% id of node having nodeset
mesh.keyp = keyp;
% nodeset existing
mesh.knum = knum;

mesh.node_num = size(mesh.node,1);
mesh.elem_num = size(mesh.elem,1);
mesh.surf_num = size(mesh.surf,1);
mesh.edge_num = size(mesh.edge,1);
mesh.keyp_num = size(mesh.keyp,1);

end

% function mesh = EXO_reader(fname)
% 
% show_log = 0;
% 
% ncid = netcdf.open(fname, 'NOWRITE');
% 
% try netcdf.inqVarID(ncid,'coord')
%     node = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coord'));
% catch exception
%     node = [netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordx')),...
%             netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordy')),...
%             netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordz'))];
% end
% [tmp, node_num] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_nodes'));
% 
% all_elem_id = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,'eb_prop1')));
% [tmp, num_el_blk] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_el_blk'));
% elem = []; tnum = []; emat = [];
% for i = 1:num_el_blk
%     elem_tmp = netcdf.getVar(ncid,netcdf.inqVarID(ncid,['connect',num2str(i)]))';
%     elem = [elem;elem_tmp];
%     tnum = [tnum; all_elem_id(i)*ones(length(elem_tmp),1)];
%     try
%         emat_tmp = netcdf.getVar(ncid,netcdf.inqVarID(ncid,['attrib',num2str(i)]))';
%     catch
%         emat_tmp = [ones(length(elem_tmp),1),0.3*ones(length(elem_tmp),1)];
%     end
%     emat = [emat; emat_tmp];
% end
% 
% [tmp, elem_num] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_elem'));
% elem_type = netcdf.getAtt(ncid,netcdf.inqVarID(ncid,'connect1'),'elem_type');
% 
% if show_log
%     fprintf(' Mesh: %d nodes, %d elements\n', node_num, elem_num);
%     fprintf(' ELEMENT BLOCKS: %d(%s); ID = %s\n', num_el_blk, elem_type, regexprep(num2str(all_elem_id'),'  ',', '));
% end
% 
% elem_map = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,'elem_map')));
% if norm(elem_map - (1:1:length(elem_map))'), error(''), end
% 
% all_elem_ss_id = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,'ss_prop1')));
% [tmp, num_elem_ss] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_side_sets'));
% 
% % EXODUS MESH INDICES
% if strcmp(elem_type,'TETRA10')
%     face_indices = [1,2,4,5,9,8;2,3,4,6,10,9;1,4,3,8,10,7;1,3,2,7,6,5];
%     ennum = 10; snnum = 6;
% elseif strcmp(elem_type,'TETRA')
%     face_indices = [1,2,4;2,3,4;1,4,3;1,3,2];
%     ennum = 4; snnum = 3;
% elseif strcmp(elem_type,'HEX20')
%     face_indices = [1,2,6,5,9,14,17,13;2,3,7,6,10,15,18,14;3,4,8,7,11,16,19,15;1,5,8,4,13,20,16,12;1,4,3,2,12,11,10,9;5,6,7,8,17,18,19,20];
%     ennum = 20; snnum = 8;    
% elseif strcmp(elem_type(1:3),'HEX')
%     face_indices = [1,2,6,5;2,3,7,6;3,4,8,7;1,5,8,4;1,4,3,2;5,6,7,8];
%     ennum = 8; snnum = 4;
% end
% 
% surf = []; snum = []; surf_val = [];
% elem_tmp = elem';
%     
% for i = 1:num_elem_ss
%     elem_ss = double(netcdf.getVar(ncid,netcdf.inqVarID(ncid,['elem_ss',num2str(i)]))');
%     side_ss = netcdf.getVar(ncid,netcdf.inqVarID(ncid,['side_ss',num2str(i)]))';
%     surf_tmp = reshape(elem_tmp(reshape(repmat((elem_ss-1)*ennum,snnum,1)' + face_indices(side_ss,:),1,[])),[],snnum);
%     surf = [surf; surf_tmp];
%     snum = [snum; all_elem_ss_id(i)*ones(length(surf_tmp),1)];
%     surf_val_tmp = netcdf.getVar(ncid,netcdf.inqVarID(ncid,['dist_fact_ss',num2str(i)]));
%     surf_val = [surf_val; sum(surf_val_tmp)/length(surf_val_tmp)*ones(length(surf_tmp),1)];
% %     patch('Vertices',node,'Faces',surf_tmp,'FaceColor','none'); keyboard
% end
% 
% if show_log
% fprintf(' SIDESETS: %d; ID = %s\n', num_elem_ss, regexprep(num2str(all_elem_ss_id'),'  ',', '));
% end
% 
% netcdf.close(ncid);
% 
% elem = double(elem);
% surf = double(surf);
% surf_val = double(surf_val);
% emat = double(emat);
% 
% edge = [snum, surf]; 
% edge_num = length(surf);
% 
% edge_num = size(edge,1);
% old_edge = edge(1:edge_num,:);
% clear edge;
% enum = old_edge(:,1);
% edge = old_edge(:,2:end);
% 
% allpnum = unique(enum);
% 
% tr_elem = [];
% for i = 1:size(face_indices,1)
%     tr_elem = [tr_elem; elem(:,face_indices(i,:))];
% end
% tmp = tr_elem;
% tmp = sort(tmp,2);
% [ttmp,Is,Iv] = unique(tmp,'rows');
% [sIv,I] = sort(Iv);
% dsIv = diff([min(sIv)-1;sIv;max(sIv)+1]);
% I1 = all([dsIv(1:end-1),dsIv(2:end)],2);
% I2 = find(I1);
% tr_elem = tr_elem(I(I2),:);
% 
% all_tnum = unique(tnum);
% nnum = zeros(node_num,1);
% for i = 1:length(all_tnum)
%     I = elem(find(tnum == all_tnum(i)),:);
%     nnum(unique(I(:))) = all_tnum(i);
% end
% 
% % % condense mesh
% % all_node = unique(tr_elem(:));
% % I = zeros(node_num,1); I(all_node) = 1:length(all_node);
% % node = node(all_node,:);
% % nnum = nnum(all_node,:);
% % node_num = length(node);
% % edge = I(edge);
% % tr_elem = I(tr_elem);
% 
% all_edges = length(tr_elem);
% 
% fnum = (length(unique(enum)) + 1)*ones(all_edges,1);
% sort_tr_elem = sort(tr_elem,2);
% sort_edge = sort(edge,2);
% for i = 1:length(edge)
%     [tmp, loc] = ismember(sort_edge(i,:),sort_tr_elem,'rows');
%     fnum(loc) = enum(i);
% end
% 
% % % split quads to tris
% % if size(elem,2) == 8
% %     tr_elem = [tr_elem(:,[1,2,3]); tr_elem(:,[1,3,4])];
% %     fnum = [fnum; fnum];
% % end
% 
% %----------------------------------------------------
% shell_elem = tr_elem(fnum == (length(unique(enum)) + 1),:);
% % find boundary edges
% % calculate normals
% normal = zeros(length(shell_elem), 3);
% for i = 1:length(shell_elem)
%     normal(i,:) = cross(node(shell_elem(i,2),:)-node(shell_elem(i,1),:),node(shell_elem(i,3),:)-node(shell_elem(i,1),:));
%     normal(i,:) = normal(i,:)/norm(normal(i,:));
% end
% 
% shell_elem_size = size(shell_elem,2);
% switch shell_elem_size
%     case 3
%         shell_surf = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,1])];
%         tr_edge = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,1])];
%         shell_edge = [tr_elem(:,[1,2]);tr_elem(:,[2,3]);tr_elem(:,[3,1])];
%     case 4
%         shell_surf = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,4]);shell_elem(:,[4,1])];
%         tr_edge = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,4]);shell_elem(:,[4,1])];
%         shell_edge = [tr_elem(:,[1,2]);tr_elem(:,[2,3]);tr_elem(:,[3,4]);tr_elem(:,[4,1])];
%     case 6
%         shell_surf = [shell_elem(:,[1,2,4]);shell_elem(:,[2,3,5]);shell_elem(:,[3,1,6])];
%         tr_edge = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,1])];
%         shell_edge = [tr_elem(:,[1,2]);tr_elem(:,[2,3]);tr_elem(:,[3,1])];
%     case 8
%         shell_surf = [shell_elem(:,[1,2,5]);shell_elem(:,[2,3,6]);shell_elem(:,[3,4,7]);shell_elem(:,[4,1,8])];
%         tr_edge = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,4]);shell_elem(:,[4,1])];
%         shell_edge = [tr_elem(:,[1,2]);tr_elem(:,[2,3]);tr_elem(:,[3,4]);tr_elem(:,[4,1])];
% end
% 
% ee = sort(shell_edge,2);
% [ee,I,J] = unique(ee,'rows');
% shell_edge = shell_edge(I,:);
% ne = size(shell_edge,1);
% 
% te = reshape(reshape(1:(size(shell_elem,1)*3),size(shell_elem,1),3)',size(shell_elem,1)*3,1);
% te = reshape(J(te),3,size(shell_elem,1))';
% 
% % find boundary edges
% tmp = sort(tr_edge,2);
% [ttmp,Is,Iv] = unique(tmp,'rows');
% [sIv,I] = sort(Iv);
% dsIv = diff([min(sIv)-1;sIv;max(sIv)+1]);
% I1 = all([dsIv(1:end-1),dsIv(2:end)],2);
% I2 = find(I1);
% tr_edge = tr_edge(I(I2),:);
% 
% % find a list of adjacent triangles for each triangle
% % first, we find duplicated edges and an associated tri list
% ttmp = sort(shell_elem,2);
% etmp = [shell_elem(:,[1,2]);shell_elem(:,[2,3]);shell_elem(:,[3,1])];
% nt = size(shell_elem,1);
% trinum = repmat((1:nt)',3,1);
% etmp = sort(etmp,2);
% [etmp,tags] = sortrows(etmp);
% trinum = trinum(tags);
% tags = find(all(diff(etmp,[],1)==0,2));
% % then we find the list of adjacent tris
% tadj = zeros(size(shell_elem,1),3);
% tadjcount = zeros(size(shell_elem,1),1);
% for i = 1:size(tags,1)
%     itmp = [trinum(tags(i)),trinum(tags(i)+1)];
%     for j = 1:2
%         tadjcount(itmp(j)) = tadjcount(itmp(j))+1;
%     end
%     tadj(itmp(1),tadjcount(itmp(1))) = itmp(2);
%     tadj(itmp(2),tadjcount(itmp(2))) = itmp(1);
% end
% 
% % find a list of adjacent triangles for each edge
% etmp = te(:);
% [etmp,tags] = sort(etmp);
% trinum = repmat((1:size(te,1))',3,1);
% trinum = trinum(tags);
% tags = find(diff(etmp)==0); % the share edges
% ntags = find(diff(etmp)~=0); % the rest
% eadj = zeros(size(shell_edge,1),2);
% eadjcount = zeros(size(shell_edge,1),1);
% for i = 1:size(etmp,1);
%     itmp = etmp(i);
%     eadjcount(itmp) = eadjcount(itmp) + 1;
%     eadj(itmp,eadjcount(itmp)) = trinum(i);
% end
% eadj = sort(eadj,2);
% 
% tol = 0.8;
% eflag = zeros(ne,1);
% for i = 1:ne
%     if all(eadj(i,:)) && abs(dot(normal(eadj(i,1),:),normal(eadj(i,2),:)))<tol
%         eflag(i) = 1;
%     end
% end
% 
% shell_edge = [shell_edge(find(eflag),:); tr_edge];
% 
% allenum = unique(enum);
% alltnum = unique(tnum);
% 
% % % Make a picture
% % close all;
% % hold on;
% % patch('Vertices',node,'Faces',tr_elem,'FaceColor','b','FaceAlpha',0.5,'EdgeAlpha',0);
% % for i = 1:length(allenum)
% % %     pause
% %     patch('Vertices',node,'Faces',edge(find(enum==allenum(i)),:),'FaceColor',rand(3,1));
% % end
% % patch('Vertices',node,'Faces',[shell_edge,shell_edge(:,2)],'EdgeColor','k','LineWidth',1);
% % % patch('Vertices',node,'Faces',shell_elem,'FaceColor','r');
% % %----------------------------------------------------
% % axis equal; axis tight;
% 
% mesh.node = node;
% mesh.elem = elem;
% mesh.elem_id = tnum;
% mesh.surf = surf;
% mesh.surf_val = surf_val;
% mesh.surf_id = snum;
% mesh.tr_elem = tr_elem;
% mesh.tr_edge = shell_edge;
% mesh.emat = emat;
% 
% mesh.node_num = size(node,1);
% mesh.elem_num = size(elem,1);
% 
% end