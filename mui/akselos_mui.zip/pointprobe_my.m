function varargout = pointprobe(aks_system,xx,opt)
% Author: Dr Masayuki Yano
% Copyright: MIT, 2015
%MYPOINTPROBE evalutes the solution at specific points
%
%INPUTS
%  aks_system: AKSSystem object
%  xx: npt x 3 array of points at which solution is evaluated
%  opt (optional): opt.verbosity sets the verbosity level (1 for verbose)
%
%OUTPUTS
%  u: npt x M array of solution at the specified points.  For acoustics, 
%     M = 3 and the components are (r_p,i_p,a_p).  If the target point is
%     not in the domain, then the value for the point is NaN.
%  ux: npt x M x dim array of solution derivatives
if (nargin < 3)
    opt = [];
else
    if isfield(opt,'debug') && opt.debug
        opt.verbosity = 10;
    end
end
ptstruct = coordglob2loc(aks_system,xx,opt);
varargout = cell(1,nargout);
[varargout{:}] = evalfunc(aks_system,ptstruct,opt);

function [u,ux,debugdata] = evalfunc(aks_system,ptstruct,opt)
if (nargin > 3) && isfield(opt,'debug') && opt.debug
    debugmode = true;
else
    debugmode = false;
    debugdata = [];
end
dim = 3;

ccomp = ptstruct.comp;
eelem = ptstruct.elem;
xxi = ptstruct.xi;

npt = size(ccomp,1);
compnames = fieldnames(aks_system.components);
comp = aks_system.components.(compnames{1});
nshp = size(comp.mesh.elem,2);
etype = nnode2etype(nshp);
M = size(comp.mesh.u(comp.mesh.elem(1,:),:),2);
sshp = shape3d(etype,xxi);
sshpx = shapex3d(etype,xxi);
u = zeros(npt,M);
ux = zeros(npt,M,dim);
for ipt = 1:npt
    icomp = ccomp(ipt);
    ielem = eelem(ipt);
    shp = sshp(ipt,:);
    if ielem == -1  % point not in the domain
        u(ipt,:) = NaN;
        continue;
    end
    comp = aks_system.components.(compnames{icomp});
    uelem = comp.mesh.u(comp.mesh.elem(ielem,:),:);
    u(ipt,:) = shp*uelem;
    if (nargout > 1)
        shpx = reshape(sshpx(ipt,:,:),[nshp,dim]);
        enodes = comp.mesh.elem(ielem,:);
        R = reshape(comp.state.docking_parameters(1:9),3,3)';
        T = comp.state.docking_parameters(10:12);
        xtri = comp.mesh.tnode(enodes,:)*R' + ones(length(enodes),1)*T;
        jac = xtri'*shpx;
        phix = shpx/jac; % shpx*inv(jac)
        ux(ipt,:,:) = uelem.'*phix;
    end
    if (debugmode)
        debugdata.comp(ipt,1) = icomp;
        debugdata.elem(ipt,1) = ielem;
        debugdata.xi(ipt,:) = xxi(ipt,:);
        debugdata.jaccond(ipt) = cond(jac);
    end
end


function ptstruct = coordglob2loc(aks_system,xx,opt)
if (nargin < 3)
    opt = [];
end
compnames = fieldnames(aks_system.components);
ncomp = length(compnames);
npt = size(xx,1);
ccomp = -ones(npt,1);
eelem = -ones(npt,1);
xxi = zeros(npt,3);
for icomp = 1:ncomp
    if isfield(opt,'verbosity') && (opt.verbosity > 0)
        fprintf('comp %d/%d\n',icomp,ncomp);
    end
    comp = aks_system.components.(compnames{icomp});
    [elem,xi,marker] = coordglob2loccomp(comp,xx,opt);
    apt = (marker==1);
    if any(ccomp(apt) ~= -1) && (opt.verbosity > 0)
        for ipt = find(ccomp(apt)~=-1)'
            fprintf('warning: point %d at %.2e %.2e %.2e belongs to multiple components\n',ipt,xx(ipt,:));
        end
    end
    ccomp(apt) = icomp;
    eelem(apt) = elem(apt);
    xxi(apt,:) = xi(apt,:);
end
if any(eelem==-1)
    for ipt = 1:npt
        if (eelem(ipt) == -1)
            fprintf('warning: could not find point %d at %.8e %.8e %.8e in the system domain\n',ipt,xx(ipt,:));
        end
    end
end
ptstruct.comp = ccomp;
ptstruct.elem = eelem;
ptstruct.xi = xxi;


function [eelem,xxi,marker] = coordglob2loccomp(comp,xx,opt)
if (nargin < 3)
    opt = [];
end
mesh = comp.mesh;
R = reshape(comp.state.docking_parameters(1:9),3,3)';
T = comp.state.docking_parameters(10:12);
node = comp.mesh.tnode*R' + ones(comp.mesh.node_num,1)*T;

npt = size(xx,1);
dim = 3;
[ntri,nshp] = size(mesh.elem);
etype = nnode2etype(nshp);
% initialization
eelem = -ones(npt,1);
xxi = zeros(npt,dim);

% bounding box to limit the number of points
marker = -ones(npt,1);
bb = [min(node); max(node)];
ii = all(bsxfun(@minus,xx,bb(1,:)) > 0,2)  ...
    & all(bsxfun(@minus,bb(2,:),xx) > 0,2);
marker(ii) = 0;

% nearest point search
xtri = reshape(node(mesh.elem,:),[ntri,nshp,dim]);
ctri = reshape(mean(xtri,2),[ntri,dim]);
eelem(marker==0) = dsearchn(ctri,xx(marker==0,:));
switch etype
    case 'tet2'
        xxi = 0.25*ones(npt,dim);
    case 'hex2'
        xxi = 0.5*ones(npt,dim);
end
tol = 1e-11; % physical coordinate tolerance
tolr = 1e-6; % reference coordinate in-out tolerance

% construct elem-to-elem connectivty
mesh.t2t = mktri2tri(mesh);

% newton iteration
for iter = 1:75
    iact = find(marker==0);
    if isfield(opt,'verbosity') && (opt.verbosity > 1)
        fprintf('%d %d\n',iter,length(iact));
    end
    
    if isempty(iact)
        break;
    end
    sshp = shape3d(etype,xxi(iact,:));
    sshpx = shapex3d(etype,xxi(iact,:));
    for iia = 1:length(iact)
        ipt = iact(iia);
        xt = xx(ipt,:);
        elem = eelem(ipt);
        shp = sshp(iia,:);
        
        shpx = reshape(sshpx(iia,:,:),[nshp,dim]);
        xloc = reshape(xtri(elem,:,:),[nshp,dim]);
        r = xt' - xloc'*shp';
        
        if isfield(opt,'debug') && opt.debug && (length(iact) < 10)
            fprintf('%2d : %5d %6d : %15.6e %15.6e %15.6e %15.6e : %15.6e\n',iter,ipt,elem,xxi(ipt,:),1-sum(xxi(ipt,:)),norm(r));
        end
        
        if (norm(r) < tol)
            switch etype
                case 'tet2'
                    if (xxi(ipt,1) < -tolr)
                        eelem(ipt) = mesh.t2t(elem,3);
                        xxi(ipt,:) = 0.25;
                    elseif (xxi(ipt,2) < -tolr)
                        eelem(ipt) = mesh.t2t(elem,2);
                        xxi(ipt,:) = 0.25;
                    elseif (xxi(ipt,3) < -tolr)
                        eelem(ipt) = mesh.t2t(elem,1);
                        xxi(ipt,:) = 0.25;
                    elseif (sum(xxi(ipt,:)) > 1+tolr)
                        eelem(ipt) = mesh.t2t(elem,4);
                        xxi(ipt,:) = 0.25;
                    else
                        marker(ipt) = 1;
                    end
                case 'hex2'
                    if (xxi(ipt,1) < -tolr)
                        eelem(ipt) = mesh.t2t(elem,1);
                        xxi(ipt,:) = 0.5;
                    elseif (xxi(ipt,1) > 1+tolr)
                        eelem(ipt) = mesh.t2t(elem,2);
                        xxi(ipt,:) = 0.5;
                    elseif (xxi(ipt,2) < -tolr)
                        eelem(ipt) = mesh.t2t(elem,3);
                        xxi(ipt,:) = 0.5;
                    elseif (xxi(ipt,2) > 1+tolr)
                        eelem(ipt) = mesh.t2t(elem,4);
                        xxi(ipt,:) = 0.5;
                    elseif (xxi(ipt,3) < -tolr)
                        eelem(ipt) = mesh.t2t(elem,5);
                        xxi(ipt,:) = 0.5;
                    elseif (xxi(ipt,3) > 1+tolr)
                        eelem(ipt) = mesh.t2t(elem,6);
                        xxi(ipt,:) = 0.5;
                    else
                        marker(ipt) = 1;
                    end
            end           
            if (eelem(ipt) == -1) % fell outside of the component
                marker(ipt) = -1;
            end
            continue;
        end
        drdxi = -xloc'*shpx;
        dxi = -drdxi\r;
        xxi(ipt,:) = xxi(ipt,:) + dxi';
    end
end


function shp = shape3d(etype,xx)
x = xx(:,1);
y = xx(:,2);
z = xx(:,3);
switch etype
    case 'tet2'
        shp = zeros(size(x,1),10);
        shp(:,1) = 1.0-3.0.*z-3.0.*y-3.0.*x+2.0.*z.*z+4.0.*y.*z+4.0.*x.*z+2.0.*y.*y+4.0.*x.*y+2.0.*x.*x;
        shp(:,2) = -x+2.0.*x.*x;
        shp(:,3) = -y+2.0.*y.*y;
        shp(:,4) = -z+2.0.*z.*z;
        shp(:,5) = 4.0.*x-4.0.*x.*z-4.0.*x.*y-4.0.*x.*x;
        shp(:,6) = 4.0.*x.*y;
        shp(:,7) = 4.0.*y-4.0.*y.*z-4.0.*y.*y-4.0.*x.*y;
        shp(:,8) = 4.0.*z-4.0.*z.*z-4.0.*y.*z-4.0.*x.*z;
        shp(:,9) = 4.0.*x.*z;
        shp(:,10) = 4.0.*y.*z;
    case 'hex2'
        shp = zeros(size(x,1),20);
        shp(:,1) = (1. - x).*(1. - y).*(1. - z).*(1. - 2.*x - 2.*y - 2.*z);
        shp(:,2) = x.*(1. - y).*(1. - z).*(2.*x - 2.*y - 2.*z - 1.);
        shp(:,3) = x.*y.*(1. - z).*(2.*x + 2.*y - 2.*z - 3.);
        shp(:,4) = (1. - x).*y.*(1. - z).*(2.*y - 2.*x - 2.*z - 1.);
        shp(:,5) = (1. - x).*(1. - y).*z.*(2.*z - 2.*x - 2.*y - 1.);
        shp(:,6) = x.*(1. - y).*z.*(2.*x - 2.*y + 2.*z - 3.);
        shp(:,7) = x.*y.*z.*(2.*x + 2.*y + 2.*z - 5.);
        shp(:,8) = (1. - x).*y.*z.*(2.*y - 2.*x + 2.*z - 3.);
        shp(:,9) = 4.*x.*(1. - x).*(1. - y).*(1. - z);
        shp(:,10) = 4.*x.*y.*(1. - y).*(1. - z);
        shp(:,11) = 4.*x.*(1. - x).*y.*(1. - z);
        shp(:,12) = 4.*(1. - x).*y.*(1. - y).*(1. - z);
        shp(:,13) = 4.*(1. - x).*(1. - y).*z.*(1. - z);
        shp(:,14) = 4.*x.*(1. - y).*z.*(1. - z);
        shp(:,15) = 4.*x.*y.*z.*(1. - z);
        shp(:,16) = 4.*(1. - x).*y.*z.*(1. - z);
        shp(:,17) = 4.*x.*(1. - x).*(1. - y).*z;
        shp(:,18) = 4.*x.*y.*(1. - y).*z;
        shp(:,19) = 4.*x.*(1. - x).*y.*z;
        shp(:,20) = 4.*(1. - x).*y.*(1. - y).*z;
    otherwise
        error('unsupported element type');
end

function shpx = shapex3d(etype,xx)
x = xx(:,1);
y = xx(:,2);
z = xx(:,3);
switch etype
    case 'tet2'
        shpx = zeros(size(x,1),10,3);
        shpx(:,1,1) = -3.0+4.0*z+4.0*y+4.0*x;
        shpx(:,2,1) = -1.0+4.0*x;
        shpx(:,3,1) = 0.0;
        shpx(:,4,1) = 0.0;
        shpx(:,5,1) = 4.0-4.0*z-4.0*y-8.0*x;
        shpx(:,6,1) = 4.0*y;
        shpx(:,7,1) = -4.0*y;
        shpx(:,8,1) = -4.0*z;
        shpx(:,9,1) = 4.0*z;
        shpx(:,10,1) = 0.0;
        shpx(:,1,2) = -3.0+4.0*z+4.0*y+4.0*x;
        shpx(:,2,2) = 0.0;
        shpx(:,3,2) = -1.0+4.0*y;
        shpx(:,4,2) = 0.0;
        shpx(:,5,2) = -4.0*x;
        shpx(:,6,2) = 4.0*x;
        shpx(:,7,2) = 4.0-4.0*z-8.0*y-4.0*x;
        shpx(:,8,2) = -4.0*z;
        shpx(:,9,2) = 0.0;
        shpx(:,10,2) = 4.0*z;
        shpx(:,1,3) = -3.0+4.0*z+4.0*y+4.0*x;
        shpx(:,2,3) = 0.0;
        shpx(:,3,3) = 0.0;
        shpx(:,4,3) = -1.0+4.0*z;
        shpx(:,5,3) = -4.0*x;
        shpx(:,6,3) = 0.0;
        shpx(:,7,3) = -4.0*y;
        shpx(:,8,3) = 4.0-8.0*z-4.0*y-4.0*x;
        shpx(:,9,3) = 4.0*x;
        shpx(:,10,3) = 4.0*y;
    case 'hex2'
        shpx = zeros(size(x,1),20,3);
        shpx(:,1,1) = (1. - y).*(1. - z).*((1. - x).*(-2.) + (-1.).*(1. - 2.*x - 2.*y - 2.*z));
        shpx(:,2,1) = (1. - y).*(1. - z).*(x.*(2.) + (1.).*(2.*x - 2.*y - 2.*z - 1.));
        shpx(:,3,1) = y.*(1. - z).*(x.*(2.) + (1.).*(2.*x + 2.*y - 2.*z - 3.));
        shpx(:,4,1) = y.*(1. - z).*((1. - x).*(-2.) + (-1.).*(2.*y - 2.*x - 2.*z - 1.));
        shpx(:,5,1) = (1. - y).*z.*((1. - x).*(-2.) + (-1.).*(2.*z - 2.*x - 2.*y - 1.));
        shpx(:,6,1) = (1. - y).*z.*(x.*(2.) + (1.).*(2.*x - 2.*y + 2.*z - 3.));
        shpx(:,7,1) = y.*z.*(x.*(2.) + (1.).*(2.*x + 2.*y + 2.*z - 5.));
        shpx(:,8,1) = y.*z.*((1. - x).*(-2.) + (-1.).*(2.*y - 2.*x + 2.*z - 3.));
        shpx(:,9,1) = 4.*(1. - y).*(1. - z).*(1. - 2.*x);
        shpx(:,10,1) = 4.*y.*(1. - y).*(1. - z);
        shpx(:,11,1) = 4.*y.*(1. - z).*(1. - 2.*x);
        shpx(:,12,1) = 4.*y.*(1. - y).*(1. - z).*(-1.);
        shpx(:,13,1) = 4.*(1. - y).*z.*(1. - z).*(-1.);
        shpx(:,14,1) = 4.*(1. - y).*z.*(1. - z);
        shpx(:,15,1) = 4.*y.*z.*(1. - z);
        shpx(:,16,1) = 4.*y.*z.*(1. - z).*(-1.);
        shpx(:,17,1) = 4.*(1. - y).*z.*(1. - 2.*x);
        shpx(:,18,1) = 4.*y.*(1. - y).*z;
        shpx(:,19,1) = 4.*y.*z.*(1. - 2.*x);
        shpx(:,20,1) = 4.*y.*(1. - y).*z.*(-1.);
        shpx(:,1,2) =(1. - x).*(1. - z).*((1. - y).*(-2.) + (-1.).*(1. - 2.*x - 2.*y - 2.*z));
        shpx(:,2,2) = x.*(1. - z).*((1. - y).*(-2.) + (-1.).*(2.*x - 2.*y - 2.*z - 1.));
        shpx(:,3,2) = x.*(1. - z).*(y.*(2.) + (1.).*(2.*x + 2.*y - 2.*z - 3.));
        shpx(:,4,2) = (1. - x).*(1. - z).*(y.*(2.) + (1.).*(2.*y - 2.*x - 2.*z - 1.));
        shpx(:,5,2) = (1. - x).*z.*((1. - y).*(-2.) + (-1.).*(2.*z - 2.*x - 2.*y - 1.));
        shpx(:,6,2) = x.*z.*((1. - y).*(-2.) + (-1.).*(2.*x - 2.*y + 2.*z - 3.));
        shpx(:,7,2) = x.*z.*(y.*(2.) + (1.).*(2.*x + 2.*y + 2.*z - 5.));
        shpx(:,8,2) = (1. - x).*z.*(y.*(2.) + (1.).*(2.*y - 2.*x + 2.*z - 3.));
        shpx(:,9,2) = 4..*x.*(1. - x).*(1. - z).*(-1.);
        shpx(:,10,2) = 4.*x.*(1. - z).*(1. - 2.*y);
        shpx(:,11,2) = 4.*x.*(1. - x).*(1. - z);
        shpx(:,12,2) = 4.*(1. - x).*(1. - z).*(1. - 2.*y);
        shpx(:,13,2) = 4.*(1. - x).*z.*(1. - z).*(-1.);
        shpx(:,14,2) = 4.*x.*z.*(1. - z).*(-1.);
        shpx(:,15,2) = 4.*x.*z.*(1. - z);
        shpx(:,16,2) = 4.*(1. - x).*z.*(1. - z);
        shpx(:,17,2) = 4.*x.*(1. - x).*z.*(-1.);
        shpx(:,18,2) = 4.*x.*z.*(1. - 2.*y);
        shpx(:,19,2) = 4.*x.*(1. - x).*z;
        shpx(:,20,2) = 4.*(1. - x).*z.*(1. - 2.*y);
        shpx(:,1,3) = (1. - x).*(1. - y).*((1. - z).*(-2.) + (-1.).*(1. - 2.*x - 2.*y - 2.*z));
        shpx(:,2,3) = x.*(1. - y).*((1. - z).*(-2.) + (-1.).*(2.*x - 2.*y - 2.*z - 1.));
        shpx(:,3,3) = x.*y.*((1. - z).*(-2.) + (-1.).*(2.*x + 2.*y - 2.*z - 3.));
        shpx(:,4,3) = (1. - x).*y.*((1. - z).*(-2.) + (-1.).*(2.*y - 2.*x - 2.*z - 1.));
        shpx(:,5,3) = (1. - x).*(1. - y).*(z.*(2.) + (1.).*(2.*z - 2.*x - 2.*y - 1.));
        shpx(:,6,3) = x.*(1. - y).*(z.*(2.) + (1.).*(2.*x - 2.*y + 2.*z - 3.));
        shpx(:,7,3) = x.*y.*(z.*(2.) + (1.).*(2.*x + 2.*y + 2.*z - 5.));
        shpx(:,8,3) = (1. - x).*y.*(z.*(2.) + (1.).*(2.*y - 2.*x + 2.*z - 3.));
        shpx(:,9,3) = 4.*x.*(1. - x).*(1. - y).*(-1.);
        shpx(:,10,3) = 4.*x.*y.*(1. - y).*(-1.);
        shpx(:,11,3) = 4.*x.*(1. - x).*y.*(-1.);
        shpx(:,12,3) = 4.*(1. - x).*y.*(1. - y).*(-1.);
        shpx(:,13,3) = 4.*(1. - x).*(1. - y).*(1. - 2.*z);
        shpx(:,14,3) = 4.*x.*(1. - y).*(1. - 2.*z);
        shpx(:,15,3) = 4.*x.*y.*(1. - 2.*z);
        shpx(:,16,3) = 4.*(1. - x).*y.*(1. - 2.*z);
        shpx(:,17,3) = 4.*x.*(1. - x).*(1. - y);
        shpx(:,18,3) = 4.*x.*y.*(1. - y);
        shpx(:,19,3) = 4.*x.*(1. - x).*y;
        shpx(:,20,3) = 4.*(1. - x).*y.*(1. - y);
    otherwise
        error('unsupported element type');
end
% xx = [0,0,0
%      1,0,0
%      0,1,0
%      0,0,1
%      0.5,0,0
%      0.5,0.5,0
%      0.0,0.5,0
%      0,0,0.5
%     0.5,0,0.5
%     0,0.5,0.5];

function t2t = mktri2tri(mesh)
[nt,nln] = size(mesh.elem);
switch nnode2etype(nln);
    case 'tet2' % tet
        f2v = [1,2,3
               1,2,4
               1,3,4
               2,3,4];
    case 'hex2'
        f2v = [4 1 5 8
               2 3 7 6
               1 2 6 5
               3 4 8 7
               2 1 4 3
               5 6 7 8];
    otherwise
        error('unsupported element type');     
end
[nlface,nlfv] = size(f2v);
efaces = reshape(mesh.elem(:,f2v(:)),[nt*nlface,nlfv]);
efaces = sort(efaces,2);
ts=[repmat((1:nt)',nlface,1), kron((1:nlface)',ones(nt,1))];

[~,~,jx] = unique(efaces,'rows'); % jx is the global face number for each element face
[jx,ix] = sort(jx); % jx is sorted, 
ts=ts(ix,:); % ts(:,1) is face-to-elem; ts(:,2) is face-to-lface
ix=find(diff(jx)==0);
ts1=ts(ix,:); % left face: elem and lface
ts2=ts(ix+1,:); % right face: elem and lface
t2t=-ones(nt,nlface);
t2t(ts1(:,1)+nt*(ts1(:,2)-1))=ts2(:,1);
t2t(ts2(:,1)+nt*(ts2(:,2)-1))=ts1(:,1);

function etype = nnode2etype(nnode)
switch nnode
    case 10
        etype = 'tet2';
    case 20
        etype = 'hex2';
    otherwise
        error('unknown element type');
end