function conf = load_config(fname)
% JSON config reader

% author: Phuong Huynh, Akselos S.A 
% email: (phuong.huynh@akselos.com)
% license: MIT (see license_mit.txt)

fname = which(fname);
conf = loadjson(fname);

if isfield(conf.server,'password')
    conf.server.username = textswap('matlabAPI',conf.server.username,0);
    conf.server.password = textswap(conf.server.username,conf.server.password,0);
end

count = 0;
while not(isfield(conf.server,'username')) || not(isfield(conf.server,'validated')) || not(conf.server.validated)
    count = count + 1;
    info = get_login_info();
    conf.server.username = info{1};
    conf.server.password = info{2};
    
    [response, status] = server_post(conf.server, struct('type', 'AuthenticationRequest'));
    if regexp(char(response),'incorrect')
        successed = -1;
        err_dlg = errordlg('Incorrect username/password!','Login failed!');
        waitfor(err_dlg);
        if count == 3
            error('Login failed!')
        end
    else
        results = loadjson(char(response));
        msgbox(results.license_info,'Login successful!','modal');
        
        successed = 1;
        conf.server.validated = true;
        conf.server.password = textswap(conf.server.username,conf.server.password,1);
        conf.server.username = textswap('matlabAPI',conf.server.username,1);
        savejson('',conf,fname);
        return;
    end
end

end

function info = get_login_info()
    info = {'',''};
    d = dialog('Position',[500 500 140 140],'Name','Login');
    u_t = uicontrol('Parent',d,...
                    'Style','text',...
                    'Position',[10 110 120 20],...
                    'String','Username');
       
    u_e = uicontrol('Parent',d,...
                    'Style','Edit',...
                    'Position',[10 90 120 25]);
                
    p_t = uicontrol('Parent',d,...
                    'Style','text',...
                    'Position',[10 70 120 20],...
                    'String','Password');
       
    p_e = uicontrol('Parent',d,...
                    'Style','Edit',...
                    'Position',[10 50 120 25],...
                    'UserData','',...
                    'KeyPressfcn',{@masked_callback,d,u_e});
       
    b_ok = uicontrol('Parent',d,...
                     'Position',[15 20 50 25],...
                     'String','OK',...
                     'Callback',{@ok_callback,d,u_e,p_e});
       
    b_cc = uicontrol('Parent',d,...
                     'Position',[75 20 50 25],...
                     'String','Cancel',...
                     'Callback',{@ok_callback,d,u_e,p_e});
       
    % Wait for d to close before running to completion
    uiwait(d);
    
    function ok_callback(h,callbackdata,d,u_e,p_e)
        info = {get(u_e,'String'), get(p_e,'UserData')};
        close(d);
    end
        
    function masked_callback(h,callbackdata,d,u_e)
        p_t = get(h,'UserData');
        key = get(d,'currentkey');
        switch key
            case 'backspace'
                p_t = p_t(1:end-1);
        end
        c = get(d,'currentcharacter');
        if not(isempty(c)) && abs(c) >= 34 && abs(c) <= 127
            p_t = [p_t, c];
        end
        p_d = '';
        p_d(1:length(p_t)) = '*';
        set(h,'String',p_d);
        set(h,'UserData',p_t);
    end
end

function new_text = textswap(key,text,flag)
    key = abs(key); 
    key = repmat(key,1,ceil(length(text)/length(key)));
    key = key(1:length(text));
    if flag
        new_text = dec2hex(abs(text) + key + 128);
        new_text = sprintf('%s',new_text(:,end:-1:1)');
    else
        text = reshape(text,3,[])';
        new_text = '';
        for i = 1:size(text,1)
            new_text(i) = char(hex2dec(text(i,end:-1:1)) - key(i) - 128);
        end
    end
end

function [response, status] = server_post(server,params)
    if ~isfield(params,'username') || ~isfield(params,'password')
        params.username = server.username;
        params.password = server.password;
    end
    headers = struct('name',{'content-type','Accept-Encoding'},...
                     'value',{'application/x-www-form-urlencoded', 'identity'});
    params = savejson('',params);
    url = ['http://',server.ip_address,':',num2str(server.http_port),server.prefix,'/'];
    [response, extra] = urlread2(url,'POST',params,headers,1);
    status = extra.status;
end