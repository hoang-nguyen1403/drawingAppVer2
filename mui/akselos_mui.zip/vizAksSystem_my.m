function vizAksSystem(akssystem,transf)
% Author: Dr Masayuki Yano
% Copyright: MIT, 2015
compnames = fieldnames(akssystem.components);
for icomp = 1:length(compnames)
    comp = akssystem.components.(compnames{icomp});
    R = reshape(comp.state.docking_parameters(1:9),3,3)';
    T = comp.state.docking_parameters(10:12);
    node = comp.mesh.tnode*R' + ones(comp.mesh.node_num,1)*T;
    node = bsxfun(@minus,node,transf.bb(:)')/(transf.aa');
    
    switch size(comp.mesh.surf,2)
        case {3,6}
            surf_idx = 1:3;
        case {4,8}
            surf_idx = 1:4;
        otherwise
            error('unknown mesh type');
    end
    tri_all = comp.mesh.tr_elem(:,surf_idx); % all surfaces
    tri_port = zeros(0,length(surf_idx));
    tri_clear = zeros(0,length(surf_idx));
    sid = unique(comp.mesh.snum);
    for k = 1:length(sid)
        stype = comp.dict.ids.(sprintf('id_%d',sid(k)));
        if length(stype) > 4 && strcmp(stype(1:4),'port')
            tri_port = [tri_port; comp.mesh.surf(comp.mesh.snum==sid(k),surf_idx)];
        end
        if any(strcmp(stype,{'inlet_surface','output_surface','radiation_surface'}))
            tri_clear = [tri_clear; comp.mesh.surf(comp.mesh.snum==sid(k),surf_idx)];
        end
    end
    %if isfield(comp.dict.parameters,'Bubble_radius')
    %    tri_clear = tri_all;
    %end
    [~,ia] = setdiff(sort(tri_all,2),sort([tri_port; tri_clear],2),'rows');
    tri_solid = tri_all(ia,:);
    patch('vertices',node,'faces',tri_solid,...
        'facecolor','r','edgecolor','none','facealpha',0.6,'facelighting','gouraud'); hold on;
    patch('vertices',node,'faces',tri_clear,...
        'facecolor','b','edgecolor','none','facealpha',0.15,'facelighting','gouraud'); hold on;
end
axis equal;
axis on;
%view([50,-62]);
view([30,20]);
xlabel('x_1');
ylabel('x_2');
zlabel('x_3');
camlight
%lighting gouraud
end
