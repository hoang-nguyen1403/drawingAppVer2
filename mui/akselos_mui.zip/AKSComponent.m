classdef AKSComponent < handle
% AKSComponent CLASS

% author: Phuong Huynh, Akselos S.A 
% email: (phuong.huynh@akselos.com)
% license: MIT (see license_mit.txt)

    properties
        id = [];
        ref = [];
        def = [];
        mesh = [];
        physics = [];
        state = [];
        dict = [];
        collection = [];
    end
    methods
        % ----- MANAGEMENT METHODS ----- %
        % -----
        function obj = AKSComponent(lib_data)
            obj.def = lib_data.def;
            obj.ref = lib_data.ref;
            obj.collection = lib_data.collection;
            obj.physics = lib_data.physics;
            obj.mesh = lib_data.mesh;
            obj.mesh.color = rand(1,3);
            obj.init(); 
        end
%         function obj = AKSComponent(library, name)
%             obj.ref = library.rb_ref_components.(name);
%             obj.def = library.rb_components.(library.rb_ref_components.(name).component_type);
%             obj.collection = library.collections.(obj.ref.collection);
%             % mesh
%             obj.mesh = library.meshes.components.(library.rb_ref_components.(name).component_type);
%             % mapping functions
%             regnames = fieldnames(obj.ref.mapping_function);
%             for i = 1:length(regnames)
%                 mapname = obj.ref.mapping_function.(regnames{i});
%                 obj.mesh.mapping_functions.(mapname) = library.mapping_functions.(mapname);
%             end
%             obj.init(); 
%         end
        % -----
        function obj = init(obj)
            % generate an id
            obj.id = char(round(rand(1,6)*(double('z')-double('a'))+double('a')));
            % fix formats
            obj.fix_format();
%             % find dom_ids of the ref points
%             obj.find_ref_ids();
            % a dictionary to quickly query properties
            obj.gen_dict();
            % a structure to hold current component states
            obj.gen_state();
            obj.transform_mesh();
        end
        % -----
        function fix_format(obj)
            % fix json single cell issues
%             obj.def.subdomains = json_struct2cell(obj.def.subdomains);
%             obj.ref.main_operator_defn = json_struct2cell(obj.ref.main_operator_defn);
%             obj.ref.sources = json_struct2cell(obj.ref.sources);
%             obj.def.faces = json_struct2cell(obj.def.faces);
%             obj.ref.parameters = json_struct2cell(obj.ref.parameters);
%             obj.def.surfaces = json_struct2cell(obj.def.surfaces);
            % fix subdomains issue
            % get a list of subdomains
            all_subdomains = {};
            for i = 1:length(obj.def.subdomains)
                all_subdomains = [all_subdomains, obj.def.subdomains{i}.name];
            end
            % search and fix "all_subdomains" in main operator definitions
            for i = 1:length(obj.ref.main_operator_defn)
                if isfield(obj.ref.main_operator_defn{i},'subdomains') && (length(obj.ref.main_operator_defn{i}.subdomains)==1) && (strcmp(obj.ref.main_operator_defn{i}.subdomains{1},'all_subdomains'))
                    obj.ref.main_operator_defn{i}.subdomains = all_subdomains;
                end
                % not defining "subdmomains" in main operators also means
                % we use "all_subdomains"...
                if not(isfield(obj.ref.main_operator_defn{i},'subdomains'))
                    obj.ref.main_operator_defn{i}.subdomains = all_subdomains;
                end
            end
            % search and fix "all_subdomains" in source definitions
            for i = 1:length(obj.ref.sources)
                if isfield(obj.ref.sources{i},'subdomains') && (length(obj.ref.sources{i}.subdomains)==1) && (strcmp(obj.ref.sources{i}.subdomains{1},'all_subdomains'))
                    obj.ref.sources{i}.subdomains = all_subdomains;
                end
            end
            % an empty outputs/sources by default
            if not(isfield(obj.ref,'outputs'))
                obj.ref.outputs = {};
            end
            if not(isfield(obj.ref,'sources'))
                obj.ref.sources = {};
            end
            for i = 1:length(obj.ref.parameters)
                if not(isfield(obj.ref.parameters{i},'type'))
                    obj.ref.parameters{i}.type = 'nondim';
                end
            end
        end
        % -----
        function type = get_type(obj)
            type = obj.ref.name;
        end
        % -----
        function type = get_collection(obj)
            type = obj.ref.collection;
        end
        % -----
        function type = get_physics(obj)
            type = obj.collection.physics;
        end
        % -----
        function gen_state(obj)
            obj.state = struct('docking_parameters', [1,0,0,0,1,0,0,0,1,0,0,0],...
                               'parameters', struct());
            % scan and initialize parameter values
            for i = 1:length(obj.ref.parameters)
                if isfield(obj.ref.parameters{i},'discrete_values')
                    obj.state.parameters.(obj.ref.parameters{i}.name) = obj.ref.parameters{i}.discrete_values{1}.value;
                else
                    obj.state.parameters.(obj.ref.parameters{i}.name) = 0.5*(obj.ref.parameters{i}.min + obj.ref.parameters{i}.max);
                end
            end
            % assign sources
            obj.state.sources = cell(1,length(obj.ref.sources));
            for i = 1:length(obj.ref.sources)
                obj.state.sources{i} = struct('name', obj.ref.sources{i}.name,...
                                              'on', false,...
                                              'parameters', struct());
                if isfield(obj.ref.sources{i},'parameters')
                    for j = 1:length(obj.ref.sources{i}.parameters)
                        obj.state.sources{i}.parameters.(obj.ref.sources{i}.parameters{j}.name) = 0.0;
                    end
                end
            end
            % assign free ports
            obj.state.ports = cell(1,length(obj.ref.faces));
            for i = 1:length(obj.ref.faces)
                obj.state.ports{i} = struct('connection', struct('component',[],'port',[]),...
                                            'configuration', obj.ref.faces{i}.port_configurations{1},...
                                            'boundary_condition', struct('on',false));
            end
            % outputs
            obj.state.outputs = cell(1,length(obj.ref.outputs));
            if isfield(obj.ref,'outputs') && (length(obj.ref.outputs)>0)
                for i = 1:length(obj.ref.outputs)
                    obj.state.outputs{i} = struct('name',obj.ref.outputs{i}.name,'on',true);
                end
            end
        end
        % -----
        function gen_dict(obj)
            obj.dict = struct('parameters',struct(),...
                              'ids',struct(),...
                              'idnames',struct());
            % parameter list
            for i = 1:length(obj.ref.parameters)
                if isfield(obj.ref.parameters{i},'discrete_values')
                    pvals = []; pnames = {};
                    for j = 1:length(obj.ref.parameters{i}.discrete_values)
                        pvals = [pvals, obj.ref.parameters{i}.discrete_values{j}.value];
                        pnames = [pnames, obj.ref.parameters{i}.discrete_values{j}.name];
                    end
                    obj.dict.parameters.(obj.ref.parameters{i}.name) = struct('location','global','id',0,'type',obj.ref.parameters{i}.type,'range',pvals,'names',{pnames});
                else
                    obj.dict.parameters.(obj.ref.parameters{i}.name) = struct('location','global','id',0,'type',obj.ref.parameters{i}.type,'range',[obj.ref.parameters{i}.min,obj.ref.parameters{i}.max]);
                end
            end
            for i = 1:length(obj.ref.sources)
                if isfield(obj.ref.sources{i},'parameters')
                    for j = 1:length(obj.ref.sources{i}.parameters)
                        obj.dict.parameters.(obj.ref.sources{i}.parameters{j}.name) = struct('location','source','id',i,'type',obj.ref.sources{i}.parameters{j},'range',[-inf, inf]);
                    end                  
                end
            end
            % mesh id to name dictionary
            obj.dict.idnames = struct();
            % ports
            for i = 1:length(obj.def.faces)
                obj.dict.ids.(['id_',num2str(obj.def.faces{i}.boundary_id)]) = ['port_',num2str(i)];
                obj.dict.idnames.(['port_',num2str(i)]) = struct('type','surface','locations',{{}},'ids',obj.def.faces{i}.boundary_id);
            end
            % subdomains
            for i = 1:length(obj.def.subdomains)
                obj.dict.ids.(['id_',num2str(obj.def.subdomains{i}.id)]) = obj.def.subdomains{i}.name;
                obj.dict.idnames.(obj.def.subdomains{i}.name) = struct('type','subdomain','locations',{{}},'ids',obj.def.subdomains{i}.id);
            end
            % surfaces
            for i = 1:length(obj.def.surfaces)
                for j = 1:length(obj.def.surfaces{i}.ids)
                    obj.dict.ids.(['id_',num2str(obj.def.surfaces{i}.ids(j))]) = obj.def.surfaces{i}.name;
                end
                obj.dict.idnames.(obj.def.surfaces{i}.name) = struct('type','surface','locations',{{}},'ids',obj.def.surfaces{i}.ids);
            end
            % id names to location
            % main operators
            for i = 1:length(obj.ref.main_operator_defn)
                if isfield(obj.ref.main_operator_defn{i},'subdomains')
                    for j = 1:length(obj.ref.main_operator_defn{i}.subdomains)
                        obj.dict.idnames.(obj.ref.main_operator_defn{i}.subdomains{j}).locations = [obj.dict.idnames.(obj.ref.main_operator_defn{i}.subdomains{j}).locations, ['main_',num2str(i)]];
                    end
                end
                if isfield(obj.ref.main_operator_defn{i},'surfaces')
                    for j = 1:length(obj.ref.main_operator_defn{i}.surfaces)
                        obj.dict.idnames.(obj.ref.main_operator_defn{i}.surfaces{j}).locations = [obj.dict.idnames.(obj.ref.main_operator_defn{i}.surfaces{j}).locations, ['main_',num2str(i)]];
                    end
                end
            end
            % source operators
            for i = 1:length(obj.ref.sources)
                if isfield(obj.ref.sources{i}.source_operator_defn,'subdomains')
                    for j = 1:length(obj.ref.sources{i}.source_operator_defn.subdomains)
                        obj.dict.idnames.(obj.ref.sources{i}.source_operator_defn.subdomains{j}).locations = [obj.dict.idnames.(obj.ref.sources{i}.source_operator_defn.subdomains{j}).locations, ['source_',num2str(i)]];
                    end
                end
                if isfield(obj.ref.sources{i}.source_operator_defn,'surfaces')
                    for j = 1:length(obj.ref.sources{i}.source_operator_defn.surfaces)
                        obj.dict.idnames.(obj.ref.sources{i}.source_operator_defn.surfaces{j}).locations = [obj.dict.idnames.(obj.ref.sources{i}.source_operator_defn.surfaces{j}).locations, ['source_',num2str(i)]];
                    end
                end
            end
            % output operators
            for i = 1:length(obj.ref.outputs)
                if isfield(obj.ref.outputs{i}.output_operator_defn,'subdomains')
                    for j = 1:length(obj.ref.outputs{i}.output_operator_defn.subdomains)
                        obj.dict.idnames.(obj.ref.outputs{i}.output_operator_defn.subdomains{j}).locations = [obj.dict.idnames.(obj.ref.outputs{i}.output_operator_defn.subdomains{j}).locations, ['outputs_',num2str(i)]];
                    end
                end
                if isfield(obj.ref.outputs{i}.output_operator_defn,'surfaces')
                    for j = 1:length(obj.ref.outputs{i}.output_operator_defn.surfaces)
                        obj.dict.idnames.(obj.ref.outputs{i}.output_operator_defn.surfaces{j}).locations = [obj.dict.idnames.(obj.ref.outputs{i}.output_operator_defn.surfaces{j}).locations, ['outputs_',num2str(i)]];
                    end
                end
            end
            % consolidate names
            idnames = fieldnames(obj.dict.idnames);
            for i = 1:length(idnames)
                obj.dict.idnames.(idnames{i}).locations = unique(obj.dict.idnames.(idnames{i}).locations);
            end
        end
        % -----
        function find_ref_ids(obj)
            node_id = zeros(obj.mesh.node_num,1);
            for j = 1:size(obj.mesh.elem,2)
                node_id(obj.mesh.elem(:,j)) = obj.mesh.tnum;
            end
            for i = 1:length(obj.def.faces)
                [I,d] = knnsearch(obj.mesh.node,...
                                  obj.def.faces{i}.reference_points,'dist','euclidean','k',1);
                obj.def.faces{i}.reference_nids = I;
                obj.def.faces{i}.reference_domids = node_id(I);
            end
        end
        % -----
        function set_parameter(obj, pname, pval)
            % TODO: non-parameter parameters and range check
            I = find(strcmp(fieldnames(obj.state.parameters), pname));
            if not(isempty(I))
                range_check = false;
                range_type_str = '';
                if isfield(obj.dict.parameters.(pname),'names')
                    range_check = ismember(pval,obj.dict.parameters.(pname).range);
                    range_type_str = '(discrete) ';
                else
                    range_check = ((pval>=(obj.dict.parameters.(pname).range(1)-10*eps)) && (pval<=(obj.dict.parameters.(pname).range(2)+10*eps)));
                end
                if range_check
                    obj.state.parameters.(pname) = pval;
                    % most like a geometric parameter, so we'll transform the mesh
                    obj.transform_mesh();
                else
                    error(sprintf('parameter value %f is out of %srange %s',pval,range_type_str,regexprep(mat2str(obj.dict.parameters.(pname).range),' ',', ')));
                end
                return;
            else % search for source parameters
                for i = 1:length(obj.state.sources)
                    if isfield(obj.state.sources{i},'parameters')
                        I = find(strcmp(fieldnames(obj.state.sources{i}.parameters), pname));
                        if not(isempty(I))
                            obj.state.sources{i}.parameters.(pname) = pval;
                            if (pval~=0)
                                obj.state.sources{i}.on = true;
                            end
                            return;
                        end
                    end
                end
            end
            error(sprintf('cannot find parameter name %s',pname));
        end
        % -----
        function set_source(obj, sname, sval)
            if ~((sval ==true) || (sval ==false))
                error('source value must be true or false');
            end
            success = 0;
            for i = 1:length(obj.state.sources)
                if strcmp(obj.state.sources{i}.name,sname)
                    obj.state.sources{i}.on = sval;
                    success = 1;
                    break;
                end
            end
            if ~success
                error('cannot find source name %s',sname);
            end
        end
        % -----
        function transform_mesh(obj)
            obj.mesh.tnode = obj.mesh.node;
            allregs = fieldnames(obj.ref.mapping_function);
            % avoid applying two different mappings on the shared surfaces
            node_regnum = zeros(length(obj.mesh.node),1);
            for j = 1:length(allregs)
                for k = 1:length(obj.def.subdomains)
                    if strcmp(obj.def.subdomains{k}.name,allregs{j})
                        break;
                    end
                end
                domid = obj.def.subdomains{k}.id;
                I = unique(reshape(obj.mesh.elem(find(obj.mesh.tnum == domid),:),[],1));
                node_regnum(I) = j;
            end
            for j = 1:length(allregs)
                for k = 1:length(obj.def.subdomains)
                    if strcmp(obj.def.subdomains{k}.name,allregs{j})
                        break;
                    end
                end
                % get the mapping
                mapping_name = obj.ref.mapping_function.(allregs{j});
                f = obj.mesh.mapping_functions.(mapping_name);
                domid = obj.def.subdomains{k}.id;
                I = find(node_regnum == j);
                obj.mesh.tnode(I,:) = apply_mapping(f, obj.mesh.node(I,:), obj.state.parameters);
            end
        end
        % -----
        function ref_pts = get_reference_pts(obj, type, id)
            if strcmp(type,'faces')
                pts = obj.def.faces{id}.reference_points;
                ref_pts = 0*pts;
                ids = obj.def.faces{id}.reference_ids;
                id_group = unique(ids);
                for i = 1:length(id_group)
                    allregs = fieldnames(obj.ref.mapping_function);
%                     for j = 1:length(allregs)
%                         if strcmp(obj.def.subdomains{id_group(i)}.name,allregs{j})
%                             break;
%                         end
%                     end
%                     mapping_name = obj.ref.mapping_function.(allregs{j});
                    for j = 1:length(obj.def.subdomains)
                        if (obj.def.subdomains{j}.id == id_group(i))
                            dom_name = obj.def.subdomains{j}.name;
                            break;
                        end
                    end
                    mapping_name = obj.ref.mapping_function.(dom_name);
                    f = obj.mesh.mapping_functions.(mapping_name);
                    I = find(ids == id_group(i));
                    ref_pts(I,:) = apply_mapping(f, pts(I,:), obj.state.parameters);
                end
            end
        end
        % -----
        function output = description(obj)
            output = obj.ref.description;
        end
        % -----
        function list_ports(obj)
            if isempty((obj.ref.faces))
                fprintf('Component: %s\nPorts: none\n', obj.ref.name);
            else
                fprintf('Component: %s\nPorts:\n', obj.ref.name);
                for i = 1:length(obj.ref.faces)
                    fprintf('#%2d: %s\n', i, obj.ref.faces{i}.split_face_dof_objects{1});
                end
            end
        end
        % -----
        function list_parameters(obj)
            fprintf('Component: %s\nParameters:\n', obj.ref.name);
            pnames = fieldnames(obj.dict.parameters);
            for i = 1:length(pnames)
                if strcmp(obj.dict.parameters.(pnames{i}).location,'global')
                    pval = obj.state.parameters.(pnames{i});
                elseif strcmp(obj.dict.parameters.(pnames{i}).location,'source')
                    pval = obj.state.sources{obj.dict.parameters.(pnames{i}).id}.parameters.(pnames{i});
                end
                fprintf(' %30s: %7.2f %s\n', pnames{i}, pval, regexprep(mat2str(obj.dict.parameters.(pnames{i}).range),' ',', '));
            end
        end
        % -----
        function list_sources(obj)
            fprintf('Component: %s\nSources:\n', obj.ref.name);
            for i = 1:length(obj.state.sources)
                fprintf('#%2d: %8s ', i, obj.state.sources{i}.name);
                if obj.state.sources{i}.on
                    fprintf('(on)\n');
                else
                    fprintf('(off)\n');
                end
                fnames = fieldnames(obj.state.sources{i}.parameters);
                if length(fnames)>0
                    fprintf(' Parameters:\n');
                end
                for j = 1:length(fnames)
                    fprintf('%35s\n',fnames{j});
                end
            end
        end
        % -----
        function bb = get_bb(obj)
            R = reshape(obj.state.docking_parameters(1:9),3,3)';
            T = obj.state.docking_parameters(10:12);
            node = obj.mesh.tnode*R' + ones(obj.mesh.node_num,1)*T;
            bb =  [min(node); max(node)];
        end
        % -----
        function aks_data = gen_aks(obj)
            aks_data = struct('ref_component_type',obj.ref.name);
            % mostly a clone of state save for a few exceptions
            aks_data.('docking_parameters') = obj.state.docking_parameters;
            aks_data.('parameters') = obj.state.parameters;
            aks_data.('outputs') = obj.state.outputs;
            aks_data.('sources') = obj.state.sources;
            aks_data.('ports') = cell(1,length(obj.state.ports));
            for i = 1:length(obj.state.ports)
                [o,c] = configuration_to_oc(obj.state.ports{i}.configuration);
                aks_data.('ports'){i} = struct('orientation',o,'clicks',c);
                % TODO: switch type (LE/acoustics)
                if strcmp(obj.physics_type,'acoustics')
                    if not(isempty(obj.state.ports{i}.connection.component))
                        aks_data.('ports'){i}.('boundary_conditions') = [];
                    else
                        aks_data.('ports'){i}.('boundary_conditions') = struct('name',{'real(p)','imag(p)'},'on',{false,false},'value',{0,0});
                    end
                elseif strcmp(obj.physics_type,'structural')
                end
            end
            % use tags for component names
            aks_data.('tags') = {['idname_',obj.id]};
            aks_data.('edge_ports') = [];
            aks_data.('node_ports') = [];

        end
        % -----
        function u_fld = get_field(obj, fld_name)
            u_fld = [];
            if not(isfield(obj.mesh,'unames'))
                disp('ERROR: no solution field is available!');
                return;
            end
            id = find(strcmp(obj.mesh.unames, fld_name));
            if isempty(id)
                all_fld_names = sprintf('%s, ', obj.mesh.unames{:});
                all_fld_names = all_fld_names(1:end-2);
                disp(sprintf('ERROR: field name %s does not existed!\nAvailable field names: %s', fld_name, all_fld_names));
                return;
            else
                u_fld = obj.mesh.u(:,id);
            end
        end
        % -----
        function read_cdf_solution(obj, fname)
            if not(exist(fname,'file'))
                keyboard % mystery error?
            end
            ncid = netcdf.open(fname, 'NOWRITE');
            try
                node_ids = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'node_ids'));
            catch exception
                [tmp, node_num] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'data_size'));
                node_ids = 1:node_num;
            end
            
            try
                % acoustics
                u = zeros(node_num,2);
                u(node_ids,1) = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'data_real'));
                u(node_ids,2) = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'data_imag'));
                u(node_ids,3) = sqrt(u(:,1).^2+ u(:,2).^2);
                unames = {'r_p','i_p','a_p'};
            catch exception
                try
                    % elasticity
                    u = zeros(node_num,3);
                    u_all = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'data'));
                    u = reshape(u_all,3,[])';
                    unames = {'u','v','w'};
                catch exception
                    % heat
                    u = zeros(node_num,1);
                    u = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'data_heat'));
                    unames = {'p'};
                end
            end
            
            netcdf.close(ncid);
            
            obj.mesh.u = u;
            obj.mesh.unames = unames;
        end
        % -----
        function read_exo_solution(obj, fname)
            ncid = netcdf.open(fname, 'NOWRITE');
            % read all fields
            tmp = ncread(fname,'name_nod_var');
            for i = 1:size(tmp,2)
                unames{i} = deblank(tmp(:,i)');
            end
            node = [netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordx')),...
                    netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordy')),...
                    netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordz'))];
            if (size(node,1) ~= obj.mesh.node_num)
                R = reshape(obj.state.docking_parameters(1:9),3,3)';
                T = obj.state.docking_parameters(10:12);
                onode = obj.mesh.tnode*R' + ones(obj.mesh.node_num,1)*T;
                I = knnsearch(node, onode, 'dist', 'euclidean', 'k', 1);
            else
                I = 1:obj.mesh.node_num;
            end
            
            u = zeros(obj.mesh.node_num,length(unames));
            for i = 1:length(unames)
                uval = netcdf.getVar(ncid,netcdf.inqVarID(ncid,['vals_nod_var',num2str(i)]));
                u(:,i) = uval(I);
            end
            netcdf.close(ncid);
            
            obj.mesh.u = u;
            obj.mesh.unames = unames;
        end
        % -----
        function visualize(obj, mesh_alpha, newfigure, uname, dscale)
            if nargin <=3
                if nargin == 1
                    mesh_alpha = 0;
                end
                newfigure = 1;
                uname = 'none';
            end
            % transform the mesh
            R = reshape(obj.state.docking_parameters(1:9),3,3)';
            T = obj.state.docking_parameters(10:12);
            node = obj.mesh.tnode*R' + ones(obj.mesh.node_num,1)*T;
            
            if newfigure
                figure;
            else
                figure(gcf);
            end
            hold on;
            
            if not(strcmp(uname,'none')) && exist('dscale','var') && (strcmp(obj.physics.name,'elasticity') || strcmp(obj.physics.name,'elasticity_eigen'))
                I = [find(strcmp(obj.mesh.unames,'u')),find(strcmp(obj.mesh.unames,'v')),find(strcmp(obj.mesh.unames,'w'))];
                patch('Vertices',node,'Faces',[obj.mesh.tr_surf(:,1),obj.mesh.tr_surf(:,2)],'EdgeColor','k','LineWidth',1,'LineStyle',':');
                node = node + dscale*obj.mesh.u(:,I);
                patch('Vertices',node,'Faces',[obj.mesh.tr_surf(:,1),obj.mesh.tr_surf(:,2)],'EdgeColor','k','LineWidth',1);
            else
                patch('Vertices',node,'Faces',[obj.mesh.tr_surf(:,1),obj.mesh.tr_surf(:,2)],'EdgeColor','k','LineWidth',1);
            end
            
            switch size(obj.mesh.tr_elem,2)
                case 3
                    tmp_elem = obj.mesh.tr_elem(:,1:3);
                    tmp_elem_size = 3;
                    surf_idx = 1:3;
                    tmp_welem = obj.mesh.tr_elem(:,1:3);
                    tmp_welem_size = 3;
                case 6
                    tmp_elem = [obj.mesh.tr_elem(:,[1,4,6]);...
                                obj.mesh.tr_elem(:,[4,2,5]);...
                                obj.mesh.tr_elem(:,[6,5,3]);...
                                obj.mesh.tr_elem(:,[6,4,5])];
                    tmp_elem_size = 3;
                    surf_idx = 1:3;
                    tmp_welem = obj.mesh.tr_elem(:,1:3);
                    tmp_welem_size = 3;
                case 4
                    tmp_elem = obj.mesh.tr_elem(:,1:4);
                    tmp_elem_size = 4;
                    surf_idx = 1:4;
                    tmp_welem = obj.mesh.tr_elem(:,1:4);
                    tmp_welem_size = 4;
                case 8
                    tmp_elem = [obj.mesh.tr_elem(:,[1,5,8]);...
                                obj.mesh.tr_elem(:,[5,2,6]);...
                                obj.mesh.tr_elem(:,[6,3,7]);...
                                obj.mesh.tr_elem(:,[7,4,8]);...
                                obj.mesh.tr_elem(:,[5,6,7]);...
                                obj.mesh.tr_elem(:,[5,7,8])];
                    tmp_elem_size = 3;
                    surf_idx = 1:4;
                    tmp_welem = obj.mesh.tr_elem(:,1:4);
                    tmp_welem_size = 4;
            end
            allsnum = unique(obj.mesh.snum);
%             color = [prod(double(obj.id(1:2))-double('aa'))/prod(double('zz')-double('aa')), prod(double(obj.id(3:4))-double('aa'))/prod(double('zz')-double('aa')), prod(double(obj.id(5:6))-double('aa'))/prod(double('zz')-double('aa'))];
            
            if not(isfield(obj.mesh,'unames'))
                I = [];
            else
                I = find(strcmp(uname,obj.mesh.unames));
            end
            
            if strcmp(uname,'none') || isempty(I)
                patch('Vertices',node(reshape(transpose(tmp_elem),[],1),:),...
                      'Faces',reshape(1:length(tmp_elem)*tmp_elem_size,tmp_elem_size,[])','FaceColor',obj.mesh.color,'FaceAlpha',1,'EdgeColor','none');
                patch('Vertices',node(reshape(transpose(tmp_welem),[],1),:),...
                      'Faces',reshape(1:length(tmp_welem)*tmp_welem_size,tmp_welem_size,[])','FaceColor','none','EdgeAlpha',mesh_alpha);
                for i = 1:length(allsnum)
                    if (allsnum(i)>=100 && allsnum(i)<200)
                        col = [1,0,0];
                    elseif (allsnum(i)>=200 && allsnum(i)<300)
                        col = [0,0.25,1];
                    elseif (allsnum(i)>=300 && allsnum(i)<400)
                        col = [0,1,0];
                    end
                    % show names of the surfaces
                    patch('Vertices',node,'Faces',obj.mesh.surf(find(obj.mesh.snum==allsnum(i)),surf_idx),'FaceColor',col,'EdgeColor','none');
                    if nargin <=2
                        stext = obj.dict.ids.(['id_',num2str(allsnum(i))]);
                        es = obj.mesh.surf(find(obj.mesh.snum==allsnum(i)),surf_idx);
                        ns = node(es,:);
                        nc = sum(ns)/size(ns,1);
                        text(nc(1),nc(2),nc(3),stext,'BackgroundColor','w','FontWeight','bold','FontSize',16,'Interpreter','none');
                    end
                end
%                 light;
            else
                patch('Vertices',node(reshape(transpose(tmp_elem),[],1),:),...
                      'Faces',reshape(1:length(tmp_elem)*tmp_elem_size,tmp_elem_size,[])',...
                      'FaceVertexCData',obj.mesh.u(reshape(transpose(tmp_elem),[],1),I),...
                      'FaceColor','interp','FaceAlpha',1,'EdgeColor','none');
                patch('Vertices',node(reshape(transpose(tmp_welem),[],1),:),...
                      'Faces',reshape(1:length(tmp_welem)*tmp_welem_size,tmp_welem_size,[])',...
                      'FaceVertexCData',obj.mesh.u(reshape(transpose(tmp_welem),[],1),I),...
                      'FaceColor','none','EdgeAlpha',mesh_alpha);
                colorbar;
            end
            axis equal; axis tight; axis off; 
            hold off;
        end
        % -----
        function visualize_slice(obj, plane, newfigure, uname)
            if nargin <=2
                newfigure = 1;
                uname = 'none';
            end
            % transform the mesh
            R = reshape(obj.state.docking_parameters(1:9),3,3)';
            T = obj.state.docking_parameters(10:12);
            node = obj.mesh.tnode*R' + ones(obj.mesh.node_num,1)*T;
            if newfigure
                figure;
            else
                figure(gcf);
            end
            hold on;
            
            patch('Vertices',node,'Faces',[obj.mesh.tr_surf(:,1),obj.mesh.tr_surf(:,2)],'EdgeColor','k','LineWidth',1);
            
            if not(isfield(obj.mesh,'unames'))
                I = [];
            else
                I = find(strcmp(uname,obj.mesh.unames));
            end
            
            for i = 1:size(plane,1)
                slice_data = slice_mesh(node, obj.mesh.elem, obj.mesh.u, plane(i,:));
                % reconstruct magnitude data
                if strcmp(obj.physics.name,'acoustics')
                    slice_data.u(:,3) = sqrt(slice_data.u(:,1).^2+slice_data.u(:,2).^2);
                end
                if size(slice_data.node) > 0
                    if strcmp(uname,'none') || isempty(I)
                        patch('Vertices',slice_data.node(:,1:3),'Faces',slice_data.tri,'FaceColor',[0.5,0.5,0.5],'EdgeColor','k');
                    else
                        patch('Vertices',slice_data.node(:,1:3),'Faces',slice_data.tri,'FaceVertexCData',slice_data.u(:,I),'FaceColor','interp','EdgeColor','none');
                        colorbar;
                    end
                end
            end
            axis equal; axis tight; axis off;
            hold off;
        end
        % -----
        function visualize_clip(obj, plane, newfigure, uname)
            if nargin <=2
                newfigure = 1;
                uname = 'none';
            end
            % transform the mesh
            R = reshape(obj.state.docking_parameters(1:9),3,3)';
            T = obj.state.docking_parameters(10:12);
            node = obj.mesh.tnode*R' + ones(obj.mesh.node_num,1)*T;
            if newfigure
                figure;
            else
                figure(gcf);
            end
            hold on;
            
            patch('Vertices',node,'Faces',[obj.mesh.tr_surf(:,1),obj.mesh.tr_surf(:,2)],'EdgeColor','k','LineWidth',1);
            
            if not(isfield(obj.mesh,'unames'))
                I = [];
            else
                I = find(strcmp(uname,obj.mesh.unames));
            end
            
            for i = 1:size(plane,1)
                slice_data = slice_mesh(node, obj.mesh.elem, obj.mesh.u, plane(i,:));
                clip_data = clip_mesh(node, obj.mesh.tr_elem, obj.mesh.u, plane(i,:));
                if size(slice_data.node) > 0
                    if strcmp(uname,'none') || isempty(I)
                        patch('Vertices',slice_data.node(:,1:3),'Faces',slice_data.tri,'FaceColor',[0.5,0.5,0.5],'EdgeColor','k');
                        patch('Vertices',clip_data.node(:,1:3),'Faces',clip_data.tri,'FaceColor',[0.5,0.5,0.5],'EdgeColor','k');
                    else
                        patch('Vertices',slice_data.node(:,1:3),'Faces',slice_data.tri,'FaceVertexCData',slice_data.u(:,I),'FaceColor','interp','EdgeColor','none');
                        patch('Vertices',clip_data.node(:,1:3),'Faces',clip_data.tri,'FaceVertexCData',clip_data.u(:,I),'FaceColor','interp','EdgeColor','none');
                        colorbar;
                    end
                end
            end
            axis equal; axis tight; axis off;
            hold off;
        end
        % -----
        function val = cal_area(obj, idname)
            val = 0;
%             if (ischar(idname) || iscell(idname))
            if not(isnumeric(idname))
                all_ids = fieldnames(obj.dict.ids);
                for i = 1:length(all_ids)
                    if strcmp(obj.dict.ids.(all_ids{i}),idname)
                        id = str2num(regexprep(all_ids{i},'id_',''));
                        val = val + cal_area(obj.mesh, id);
                    end
                end
            else %isnumeric(idname)
                val = cal_area(obj.mesh, idname);
            end
        end
    end
end

function tnode_ = apply_mapping(f, node, params)
    tnode_ = node;
    if isempty(f) || isempty(f.mapping_function)
        return;
    end
    % goofy loadjson bug
    if not(iscell(f.mapping_function))
        fmap = {f.mapping_function(1),f.mapping_function(2),f.mapping_function(3)};
    else
        fmap = f.mapping_function;
    end
    pname = fieldnames(params);

    flocal = ['x=node(:,1);y=node(:,2);z=node(:,3);'];
    for p = 1:length(pname)
        flocal = [flocal,pname{p},'=',num2str(params.(pname{p})),';'];
    end
    flocal = [flocal, f.local_variables];
    flocal = regexprep(flocal,{':=','*','/'},{'=','.*','./'});
    eval(flocal);

    for fnum_ = 1:3
        func = regexprep(fmap{fnum_},{':=','*','/'},{'=','.*','./'});
        func = regexprep(func,{'sqrt'},{'~'});
        func = regexprep(func,{'~'},{'sqrt'});
        tnode_(:,fnum_) = eval(func);
    end
end

function data = json_struct2cell(data)
    if not(iscell(data))
        if length(data) == 1
            data = {data};
        else
            data_ = {length(data)};
            for i = 1:length(data)
                data_{i} = data(i);
            end
            data = data_;
        end
    end
end

function area = cal_area(mesh, id)
    switch size(mesh.surf,2)
        case 3
            % simple P1 tri mesh
            area = 0;
            I = find(mesh.snum ==id);
            for i = 1:length(I)
                nodes = mesh.tnode(mesh.surf(I(i),1:3),:);
                area = area + norm(cross(nodes(2,:)-nodes(1,:),nodes(3,:)-nodes(1,:)));
            end
            area = 0.5*area;
        case 4
            % simple P1 quad mesh
            area = 0;
            I = find(mesh.snum ==id);
            for i = 1:length(I)
                nodes = mesh.tnode(mesh.surf(I(i),[1,2,3]),:);
                area = area + norm(cross(nodes(2,:)-nodes(1,:),nodes(3,:)-nodes(1,:)));
                nodes = mesh.tnode(mesh.surf(I(i),[1,3,4]),:);
                area = area + norm(cross(nodes(2,:)-nodes(1,:),nodes(3,:)-nodes(1,:)));
            end
            area = 0.5*area;
        otherwise
            % curvy "flat" mesh
            GPoints = 1/sqrt(3)*[1,1;1,-1;-1,1;-1,-1];
            weight = 1*ones(4,1);
            area = 0;
            I = find(mesh.snum==id);
            for i = 1:length(I)
                nodes = mesh.tnode(mesh.surf(I(i),:),:);
                nodes = nodes*[cos(pi/4),0,-sin(pi/4);0,1,0;sin(pi/4),0,cos(pi/4)]';
                X = nodes(1,:)-nodes(2,:);
                Y = nodes(3,:)-nodes(2,:);
                Z = cross(Y,X);
                Y = cross(Z,X);
                R = orth([X' Y' Z']);
                R = [X'/norm(X) Y'/norm(Y) Z'/norm(Z)];
                tnodes = (inv(R)*(nodes-ones(size(nodes,1),1)*nodes(2,:))')';
                tnodes(:,sum(abs(tnodes))<1e-8) = [];
                for ipoint = 1:length(weight)
                    L = GPoints(ipoint,:);
                    L1 = L(1); L2 = L(2);
                    switch size(mesh.surf,2)
                        case 6
                            % N = [ -(L1/4 - 1/4)*(L2 - 1)*(L1 + L2 + 1), (L1/4 + 1/4)*(L2 - 1)*(L2 - L1 + 1), (L2*(L2 + 1))/2, (L1^2/2 - 1/2)*(L2 - 1), -(L1/2 + 1/2)*(L2^2 - 1), (L1/2 - 1/2)*(L2^2 - 1)];
                            dN = [-((2*L1 + L2)*(L2 - 1))/4, -((L2 - 1)*(2*L1 - L2))/4, 0, L1*(L2 - 1), 1/2 - L2^2/2, L2^2/2 - 1/2;...
                                  -((L1 + 2*L2)*(L1 - 1))/4, -((L1 - 2*L2)*(L1 + 1))/4, L2 + 1/2, L1^2/2 - 1/2, -L2*(L1 + 1), L2*(L1 - 1)];
                        case 8
                            % N = [1/4*(1-L1)*(1-L2)*(-L1-L2-1), 1/4*(1+L1)*(1-L2)*(+L1-L2-1), 1/4*(1+L1)*(1+L2)*(+L1+L2-1), 1/4*(1-L1)*(1+L2)*(-L1+L2-1), 1/2*(1-L1^2)*(1-L2), 1/2*(1+L1)*(1-L2^2), 1/2*(1-L1^2)*(1+L2), 1/2*(1-L1)*(1-L2^2)];
                            dN = [-((2*L1 + L2)*(L2 - 1))/4, -((L2 - 1)*(2*L1 - L2))/4, ((2*L1 + L2)*(L2 + 1))/4, ((L2 + 1)*(2*L1 - L2))/4, L1*(L2 - 1), 1/2 - L2^2/2, -L1*(L2 + 1), L2^2/2 - 1/2;...
                                  -((L1 + 2*L2)*(L1 - 1))/4, -((L1 - 2*L2)*(L1 + 1))/4, ((L1 + 2*L2)*(L1 + 1))/4, ((L1 - 2*L2)*(L1 - 1))/4, L1^2/2 - 1/2, -L2*(L1 + 1), 1/2 - L1^2/2, L2*(L1 - 1)];
                    end
                    w = weight(ipoint);
                    J = dN*tnodes;
                    area = area + abs(det(J))*w;
                end
            end
    end
    
end

function [orientation, click] = configuration_to_oc(conf_name)
    if not(isempty(regexp(conf_name,'OUTWARD','once')))
        orientation = 0;
    else
        orientation = 1;
    end
    click = str2double(regexprep(conf_name,{'INWARD','OUTWARD'},{'',''}));
end

function configuration = oc_to_configuration(orientation, click)
    if (orientation==0)
        configuration = 'OUTWARD';
    else
        configuration = 'INWARD';
    end
    configuration = [configuration,num2str(click)];
end

function clip_data = clip_mesh(node, elem, u, plane)
if isempty(u)
    u = zeros(length(node),1);
end

switch size(elem,2)
    case {3,6}
        tri = elem(:,1:3);
    case {4,8}
        tri = [elem(:,[1,2,3]);...
               elem(:,[1,3,4])];
end

% p = node(reshape(tri',1,[]),:);
% pu = u(reshape(tri',1,[]),:);
% tri = reshape(1:(size(tri,1)*3),3,[])';

% normalize cutting plane equation
plane = plane/norm(plane(1:3));
d = node*plane(1:3)' + plane(4);
dtri = d(tri);

ia = dtri<0;

pt = {[];[]};
ut = {[];[]};

I = find(ismember(ia,[1,1,1],'rows'));
pt{1} = node(tri(I,:)',:);
ut{1} = u(tri(I,:)',:);

I = find(ismember(ia,[0,0,0],'rows'));
pt{2} = node(tri(I,:)',:);
ut{2} = u(tri(I,:)',:);

% nodal-elem data with 5 pts
pe = node([tri,tri(:,1:2)]',:);
ue = u([tri,tri(:,1:2)]',:);
de = d([tri,tri(:,1:2)]',:);

% cases
indices = {[1,0,0],...
           [0,1,1],...
           [0,1,0],...
           [1,0,1],...
           [0,0,1],...
           [1,1,0]};
ip = {[1,2;1,3],...
      [1,2;1,3],...
      [1,2;2,3],...
      [1,2;2,3],...
      [1,3;2,3],...
      [1,3;2,3]};
it = {{[1,4,5],[2,3,5;5,4,2]},...
      {[2,3,5;5,4,2],[1,4,5]},...
      {[4,2,5],[1,4,3;4,5,3]},...
      {[1,4,3;4,5,3],[4,2,5]},...
      {[4,5,3],[1,2,5;1,5,4]},...
      {[1,2,5;1,5,4],[4,5,3]}};

for c = 1:length(indices)
    I = find(ismember(ia,indices{c},'rows'));

    nodep = [];
    up = [];
    for i = 1:2 % add 2 extra pts
        p1 = pe((I-1)*5+ip{c}(i,1),:); p2 = pe((I-1)*5+ip{c}(i,2),:);
        u1 = ue((I-1)*5+ip{c}(i,1),:); u2 = ue((I-1)*5+ip{c}(i,2),:);
        v1 = de((I-1)*5+ip{c}(i,1)); v2 = de((I-1)*5+ip{c}(i,2));    
        ivdiff = 1./(v1-v2);
        pe((I-1)*5+3+i,:) = -((v2.*ivdiff)*ones(1,3)).*p1 + ((v1.*ivdiff)*ones(1,3)).*p2;
        ue((I-1)*5+3+i,:) = -((v2.*ivdiff)*ones(1,size(u,2))).*u1 + ((v1.*ivdiff)*ones(1,size(u,2))).*u2;
    end
    for j = 1:2
        for i = 1:size(it{c}{j},1)
            pt{j} = [pt{j}; pe(((I-1)*5*ones(1,3)+ones(length(I),1)*it{c}{j}(i,:))',:)];
            ut{j} = [ut{j}; ue(((I-1)*5*ones(1,3)+ones(length(I),1)*it{c}{j}(i,:))',:)];
        end
    end
end

clip_data.u = ut{1};
clip_data.node = pt{1};
clip_data.tri = reshape(1:size(pt{1},1),3,[])';

% patch('Vertices',clip_data.node,'Faces',clip_data.tri,'FaceVertexCData',clip_data.u(:,3),'FaceColor','interp');

end

function slice_data = slice_mesh(node, elem, u, plane)
% a naive non-vectorized implenetation for now...

if isempty(u)
    u = zeros(length(node),1);
end

switch size(elem,2)
    case {4,10}
        tet = elem(:,1:4);
%     case {10}
%         tet = [elem(:,[8,9,10,4]);...
%                elem(:,[7,5,8,1]);...
%                elem(:,[6,9,5,2]);...
%                elem(:,[7,10,6,3]);...
%                elem(:,[8,9,10,4]);...
%                elem(:,[7,9,10,8]);...
%                elem(:,[7,9,5,8]);...
%                elem(:,[7,10,9,8]);...
%                elem(:,[7,5,9,6]);...
%                elem(:,[7,9,10,6])];        
    case {8,20}
        tet = [elem(:,[1,2,3,6]);...
               elem(:,[1,6,3,7]);...
               elem(:,[1,5,6,7]);...
               elem(:,[1,7,3,4]);...
               elem(:,[1,5,7,4]);...
               elem(:,[4,5,7,8])];        
end

% normalize cutting plane equation
plane = plane/norm(plane(1:3));

d = node*plane(1:3)' + plane(4);
% perturb a bit to get rid of fightting planes
d = d + 1e-8*max(abs(diff(sort(d))))*rand(length(d),1);

dtet = d(tet);
ia = dtet>0;

case_ids = {[0,0,0,1],[1,4;2,4;3,4];...
            [1,1,0,1],[1,3;2,3;3,4];...
            [1,0,1,1],[1,2;2,4;2,3];...
            [0,1,1,1],[1,2;1,3;1,4];...
            [1,0,0,1],[1,2;2,4;3,4;1,3];...
            [0,0,1,1],[2,3;1,3;1,4;2,4];...
            [0,1,0,1],[1,2;2,3;3,4;1,4]};
        
count = 0;
p = []; pu = []; t = [];
for i = 1:size(case_ids,1)
    % unflipped case
    [mp, mu, mt] = tet_index_slice(0,case_ids{i,1},case_ids{i,2},...
                               node,u,tet,dtet,ia);
    p = [p;mp];
    pu = [pu;mu];
    t = [t;mt+count];
    count = count + size(mp,1);
    % flipped case
    [mp, mu, mt] = tet_index_slice(1,not(case_ids{i,1}),case_ids{i,2},...
                               node,u,tet,dtet,ia);
    p = [p;mp];
    pu = [pu;mu];
    t = [t;mt+count];
    count = count + size(mp,1);
end
slice_data.u = pu;
slice_data.node = p;
slice_data.tri = t;
end

function [p, u, t] = tet_index_slice(tflip,df,indices,node,usol,tet,dtet,ia)
    I = find(ismember(ia,df,'rows'));
    np = size(I,1);
    nt = size(indices,1);
    p = zeros(np*nt,3);
    u = zeros(np*nt,size(usol,2));
    t = zeros(np,3);
    if np>0
        for i = 1:size(indices,1)
            p1 = node(tet(I,indices(i,1)),:); u1 = usol(tet(I,indices(i,1)),:); v1 = dtet(I,indices(i,1));
            p2 = node(tet(I,indices(i,2)),:); u2 = usol(tet(I,indices(i,2)),:); v2 = dtet(I,indices(i,2));
            ivdiff = 1./(v1-v2);
            p(i:nt:np*nt,:) = -((v2.*ivdiff)*ones(1,3)).*p1 + ((v1.*ivdiff)*ones(1,3)).*p2;
            u(i:nt:np*nt,:) = -((v2.*ivdiff)*ones(1,size(usol,2))).*u1 + ((v1.*ivdiff)*ones(1,size(usol,2))).*u2;
        end
        switch nt
            case 3
                t = [(1:nt:np*nt)', (2:nt:np*nt)', (3:nt:np*nt)'];
            case 4
                t = [(1:nt:np*nt)', (2:nt:np*nt)', (3:nt:np*nt)';...
                     (1:nt:np*nt)', (3:nt:np*nt)', (4:nt:np*nt)'];
        end
        if tflip
            t = t(:,[1,3,2]);
        end
    end
end