function sync_collections
% utility to sync all collection data from Akselos server

% author: Phuong Huynh, Akselos S.A 
% email: (phuong.huynh@akselos.com)
% license: MIT (see license_mit.txt)

conf = load_config('akselos_config.json');
server = conf.server;

cp = mfilename('fullpath'); I = regexp(regexprep(cp,'\','/'),'/'); cp = cp(1:I(end));

allfiles = dir([cp,'collections']);
for i = 1:length(allfiles)
    if not(isempty(regexp(allfiles(i).name,'.acl'))) && not(strcmp(allfiles(i).name,'physics.acl'))
        collname = regexprep(allfiles(i).name,'.acl','');
        
        fname = [cp,'collections/',collname,'.acl'];
        % try downloading it
        fprintf('Connect to server and sync collection (%s)... ',collname);
        params = struct('type', 'download', 'data', ['collections/',collname,'.acl']);
        [response, status] = server_post(server, params);
        if length(response)<2000 % noway to tell if we're failed
            fprintf('failed\n');
            warning('Server error: Collection not found!')
        else
            fprintf('done! (%2.2f MB)\n', length(response)/(2^20));
            fid = fopen(fname,'w');
            fwrite(fid,response,'uint8');
            fclose(fid);
        end
    end
end

end

function [response, status] = server_post(server,params)
    if ~isfield(params,'username') || ~isfield(params,'password')
        params.username = server.username;
        params.password = server.password;
    end
    headers = struct('name',{'content-type','Accept-Encoding'},...
                     'value',{'application/x-www-form-urlencoded', 'identity'});
    params = savejson('',params);
    url = ['http://',server.ip_address,':',num2str(server.http_port),server.prefix,'/'];
    [response, extra] = urlread2(url,'POST',params,headers,1);
%     response = char(response);
    status = extra.status;
end