classdef AKSSystem < handle
% AKSComponent CLASS

% author: Phuong Huynh, Akselos S.A 
% email: (phuong.huynh@akselos.com)
% license: MIT (see license_mit.txt)

    properties
        server = struct();
        components = struct();
        solutions = struct('viz',0);
        collection_type = [];
        physics_type = [];
        state = struct('map',[]);
        plot_option = struct('deformation_scale_factor',[]);
        solver_option = struct('max_dofs_per_port',100);
    end
    methods
        % ----- MANAGEMENT METHODS ----- %
        % -----
        function obj = AKSSystem()
            obj.components = struct();
            % get server information
            conf = load_config('akselos_config.json');
            obj.server = conf.server;
            % plot option
            obj.plot_option = struct();
            obj.plot_option.deformation_scale_factor = [];
            obj.plot_option.full_stress = true;
        end
        % -----
        function refresh(obj)
            component_names = fieldnames(obj.components);
            nc = length(component_names);
            imap = struct();
            fmap = {};
            for i = 1:nc
                fmap{i} = obj.components.(component_names{i}).id;
                imap.(component_names{i}) = i;
            end
            obj.state.map = struct('imap',imap,'fmap',{fmap});
            
            G = sparse(nc,nc);
            for i = 1:nc
                for j = 1:length(obj.components.(component_names{i}).state.ports)
                    if not(isempty(obj.components.(component_names{i}).state.ports{j}.connection.component))
                        G(imap.(component_names{i}),imap.(obj.components.(component_names{i}).state.ports{j}.connection.component)) = 1;
                    end
                end
            end
%             [S,C] = graphconncomp(0.5*(G+G'));
            C = graphcomp(0.5*(G+G'));
            obj.state.map.graph = C;
        end
        % -----
        function add_component(obj, component)
            if not(isempty(obj.state.map)) && not(isempty(find(strcmp(component.id, obj.state.map.fmap))))
                new_id = [component.id,'_'];
                component.id = new_id;
                warning('Duplicated component id, new id "%s" is assigned!',new_id);
            end
            if isempty(obj.collection_type)
                obj.components.(component.id) = component;
                obj.collection_type = component.get_collection;
                obj.physics_type = component.get_physics;
            else
                if not(strcmp(obj.collection_type,component.get_collection))
                    error('cannot mix components with different collections');
                else
                    obj.components.(component.id) = component;
                end
            end
            obj.refresh();
        end
        % -----
        function remove_component(obj, input)
            if ischar(input) % pass by id
                obj.components = rmfield(obj.components,input);
            else % pass by object
                obj.components = rmfield(obj.components,input.id);
            end
            obj.refresh();
        end
        % -----
        function click(obj, master_component_id, master_port_id, click)
            slave_component_id = obj.components.(master_component_id).state.ports{master_port_id}.connection.component;
            slave_port_id = obj.components.(master_component_id).state.ports{master_port_id}.connection.port;
            if isempty(slave_component_id) || isempty(slave_port_id)
                error('Error: component %s port %d is free!', master_component_id, master_port_id);
            end
            % generate a list of possible connections
            master_confs = obj.components.(master_component_id).ref.faces{master_port_id}.port_configurations;
            slave_confs = obj.components.(slave_component_id).ref.faces{slave_port_id}.port_configurations;
            pairs = find_valid_configurations(master_confs, slave_confs);
            num_clicks = size(pairs,1);
            % get index of current configuration
            current_conf = {obj.components.(master_component_id).state.ports{master_port_id}.configuration,...
                            obj.components.(slave_component_id).state.ports{slave_port_id}.configuration};
            for id = 1:num_clicks
                if strcmp(current_conf{1}, pairs{id,1}) && strcmp(current_conf{2}, pairs{id,2})
                    break;
                end
            end
            old_id = id;
            if exist('click','var')
                if click <= num_clicks && click >0
                    id = click;
                else
                    error('Click number is invalid! Max click = %d',num_clicks);
                end
            else
                % increase click configuration
                if id == num_clicks
                    id = 1;
                else
                    id = id+1;
                end
            end
            % undock component
            obj.components.(master_component_id).state.ports{master_port_id}.connection.component = [];
            obj.components.(master_component_id).state.ports{master_port_id}.connection.port = [];
            obj.components.(slave_component_id).state.ports{slave_port_id}.connection.component = [];
            obj.components.(slave_component_id).state.ports{slave_port_id}.connection.port = [];
            obj.refresh();
            % reconnect
            obj.dock_component(master_component_id, master_port_id, slave_component_id, slave_port_id,...
                               pairs{id,1}, pairs{id,2});
            fprintf('Click configuration: #%d/%d(%s,%s) to #%d/%d(%s,%s)\n',old_id,num_clicks,current_conf{1},current_conf{2},id,num_clicks,pairs{id,1},pairs{id,2});
        end
        % -----
        function dock_component(obj, master_component_id, master_port_id, slave_component_id, slave_port_id, master_configuration, slave_configuration)
            
            % verify if the two components are in the same group
            if obj.state.map.graph(obj.state.map.imap.(master_component_id)) == obj.state.map.graph(obj.state.map.imap.(slave_component_id))
                error('docking fails: two components are in the same subsystem, autodock?');
            end
            % verify if the ports are occupied
            if not(isempty(obj.components.(master_component_id).state.ports{master_port_id}.connection.component))
                error('docking fails: master component/port is not free');
            end
            if not(isempty(obj.components.(slave_component_id).state.ports{slave_port_id}.connection.component))
                error('docking fails: slave component/port is not free');
            end
            % verify port type compatibility
            if not(strcmp(obj.components.(master_component_id).ref.faces{master_port_id}.split_face_dof_objects,obj.components.(slave_component_id).ref.faces{slave_port_id}.split_face_dof_objects))
                error('docking fails: unmatched port types');
            end
%             master_ref_pts = obj.components.(master_component_id).mesh.tnode(obj.components.(master_component_id).def.faces{master_port_id}.reference_nids,:);
            master_ref_pts = obj.components.(master_component_id).get_reference_pts('faces',master_port_id);
            R = reshape(obj.components.(master_component_id).state.docking_parameters(1:9),3,3)';
            T = obj.components.(master_component_id).state.docking_parameters(10:12);
            master_ref_pts = master_ref_pts*R' + ones(size(master_ref_pts,1),1)*T;
%             slave_ref_pts = obj.components.(slave_component_id).mesh.tnode(obj.components.(slave_component_id).def.faces{slave_port_id}.reference_nids,:);
            slave_ref_pts = obj.components.(slave_component_id).get_reference_pts('faces',slave_port_id);
            
            if nargin == 5
                % find a good configuration
                master_confs = obj.components.(master_component_id).ref.faces{master_port_id}.port_configurations;
                slave_confs = obj.components.(slave_component_id).ref.faces{slave_port_id}.port_configurations;
                pairs = find_valid_configurations(master_confs, slave_confs);
                % verify if there is a possible connection
                if (size(pairs,1) == 0)
                    error('docking fails: no possible configuration');
                end
                master_configuration = pairs{1,1};
                slave_configuration = pairs{1,2};
            end
            [mo, mc] = configuration_to_oc(master_configuration);
            [so, sc] = configuration_to_oc(slave_configuration);
            [R, T] = find_rotation_matrix(get_three_pts(slave_ref_pts, so, sc),...
                                          get_three_pts(master_ref_pts, mo, mc));
            % validate docking parameter
            if not(validate_rotation_matrix(R))
                error('docking fails: parameters are not compatible')
            end
            % assign new configurations
            obj.components.(master_component_id).state.ports{master_port_id}.configuration = oc_to_configuration(mo, mc);
            obj.components.(slave_component_id).state.ports{slave_port_id}.configuration = oc_to_configuration(so, sc);
            % assign new docking_parameterst
            slave_group = {obj.state.map.fmap{find(obj.state.map.graph == obj.state.map.graph(obj.state.map.imap.(slave_component_id)))}};
            slave_group = setdiff(slave_group, slave_component_id);
            R_old = reshape(obj.components.(slave_component_id).state.docking_parameters(1:9),3,3)';
            T_old = obj.components.(slave_component_id).state.docking_parameters(10:12);
            R_rot = R*inv(R_old);
            T_rot = T-T_old*R_rot';
            obj.components.(slave_component_id).state.docking_parameters = [reshape(R',[],1);T(:)]';
            for i = 1:length(slave_group)
                R = reshape(obj.components.(slave_group{i}).state.docking_parameters(1:9),3,3)';
                T = obj.components.(slave_group{i}).state.docking_parameters(10:12);
                R_new = R_rot*R;
                T_new = T_rot+T*R_rot';
                obj.components.(slave_group{i}).state.docking_parameters = [reshape(R_new',[],1);T_new(:)]';
            end
            % assign connection data
            obj.components.(master_component_id).state.ports{master_port_id}.connection.component = slave_component_id;
            obj.components.(master_component_id).state.ports{master_port_id}.connection.port = slave_port_id;
            obj.components.(slave_component_id).state.ports{slave_port_id}.connection.component = master_component_id;
            obj.components.(slave_component_id).state.ports{slave_port_id}.connection.port = master_port_id;
            % rebuild graph map
            obj.refresh();
        end
        % -----
        function set_bc(obj, component_id, port_id, value)
            if not(isempty(obj.components.(component_id).state.ports{port_id}.connection.component))
                warning('Boundary condition is set to a connected port!');
            end
            value_fields = fieldnames(value);
            for i = 1:length(value_fields)
                obj.components.(component_id).state.ports{port_id}.boundary_condition.(value_fields{i}) = value.(value_fields{i});
            end
            obj.components.(component_id).state.ports{port_id}.boundary_condition.on = true;
        end
        % -----
        function set_parameter(obj, pname, pval)
            component_names = fieldnames(obj.components);
            for id = 1:length(component_names)
                name = obj.state.map.fmap{id};
                obj.components.(name).set_parameter(pname, pval);
            end
        end
        % -----
        function s_aks = gen_aks(obj, fname)
            s_aks = struct('collection_type',obj.collection_type);
            connections = zeros(0,4);
            bcs = cell(0,1);
            s_aks.('components') = cell(length(obj.components),1);
            for id = 1:length(fieldnames(obj.components))
                name = obj.state.map.fmap{id};
                component = obj.components.(name);
                
                c_aks = struct('ref_component_type',component.ref.name);
                % mostly a clone of state save for a few exceptions
                c_aks.('docking_parameters') = component.state.docking_parameters;
                c_aks.('parameters') = component.state.parameters;
                c_aks.('outputs') = component.state.outputs;
                c_aks.('sources') = component.state.sources;
                c_aks.('ports') = cell(1,length(component.state.ports));
                for i = 1:length(component.state.ports)
                    [o,c] = configuration_to_oc(component.state.ports{i}.configuration);
                    c_aks.('ports'){i} = struct('orientation',o,'clicks',c);
                    if not(isempty(component.state.ports{i}.connection.component))
                        c_aks.('ports'){i}.('boundary_conditions') = [];
                        new_connection = [id, i, obj.state.map.imap.(component.state.ports{i}.connection.component), component.state.ports{i}.connection.port];
                        % make sure we don't duplicate connections
                        if not(any(ismember([new_connection([1,2,3,4]);new_connection([3,4,1,2])],connections,'rows')))
                            connections = [connections; new_connection];
                        end
                    else
                        % TODO: switch type (LE/acoustics)
%                         if strcmp(obj.physics_type,'acoustics')
%                             if (component.state.ports{i}.boundary_condition.on)
%                                 c_aks.('ports'){i}.('boundary_conditions') = struct('name',{'real(p)','imag(p)'},'on',{true,true},'value',{component.state.ports{i}.boundary_condition.r_p,component.state.ports{i}.boundary_condition.i_p});
%                             else
%                                 c_aks.('ports'){i}.('boundary_conditions') = struct('name',{'real(p)','imag(p)'},'on',{false,false},'value',{0,0});
%                             end
%                         elseif strcmp(obj.physics_type,'heat')
%                             if (component.state.ports{i}.boundary_condition.on)
%                                 c_aks.('ports'){i}.('boundary_conditions') = {struct('name','p','on',true,'value',component.state.ports{i}.boundary_condition.p)};
%                             else
%                                 c_aks.('ports'){i}.('boundary_conditions') = {struct('name','p','on',false,'value',0)};
%                             end
%                         elseif strcmp(obj.physics_type,'elasticity')
%                             if (component.state.ports{i}.boundary_condition.on)
%                                 c_aks.('ports'){i}.('boundary_conditions') = struct('name',{'t1','t2','n','rotation'},'on',{true,true,true,true},'value',{component.state.ports{i}.boundary_condition.t1,component.state.ports{i}.boundary_condition.t2,component.state.ports{i}.boundary_condition.n,0});
%                             else
%                                 c_aks.('ports'){i}.('boundary_conditions') = struct('name',{'t1','t2','n','rotation'},'on',{false,false,false,false},'value',{0,0,0,0});
%                             end
%                         end
                        if strcmp(obj.physics_type,'acoustics')
                            if (component.state.ports{i}.boundary_condition.on)
                                bcs = [bcs; {{id, i, struct('real___p___', component.state.ports{i}.boundary_condition.r_p,...
                                                            'imag___p___', component.state.ports{i}.boundary_condition.i_p)}}];
                            end
                        elseif strcmp(obj.physics_type,'heat')
                            if (component.state.ports{i}.boundary_condition.on)
                                bcs = [bcs; {{id, i, struct('p', component.state.ports{i}.boundary_condition.p)}}];
                            end
                        elseif (strcmp(obj.physics_type,'elasticity') || strcmp(obj.physics_type,'elasticity_eigen'))
                            if (component.state.ports{i}.boundary_condition.on)
                                bcs = [bcs; {{id, i, struct('t1', component.state.ports{i}.boundary_condition.t1,...
                                                            't2', component.state.ports{i}.boundary_condition.t2,...
                                                            'n', component.state.ports{i}.boundary_condition.n)}}];
                            end
                        end
                    end
                end
                c_aks.('tags') = {['idname_',component.id]};
                c_aks.('edge_ports') = [];
                c_aks.('node_ports') = [];
            
                s_aks.('components'){id} = c_aks;
            end
            
%             s_aks.('connections') = connections - 1;
%             switch size(s_aks.('connections'),1)
%                 case 1
%                     s_aks.('connections') = {s_aks.('connections')};
%                 case 0
%                     s_aks.('connections') = {};
%             end
%             s_aks.('edge_connections') = [];
%             s_aks.('node_connections') = [];
            
            % new connection format
            connections = connections - 1;
            port_constraints = struct('port_id_data', {{}},...
                                      'constraint_data', {{}},...
                                      'boolean_data', {{}},...
                                      'constraint_type', 'direct');
            count = 0;
            for i = 1:size(bcs,1)
                count = count + 1;
                port_constraints(count).port_id_data = {struct('component_id',{bcs{i}{1}-1},...
                                                               'port_index',{bcs{i}{2}-1},...
                                                               'port_dimension', {2})};
                port_constraints(count).constraint_data = bcs{i}{3};
                port_constraints(count).constraint_type = 'direct';
                port_constraints(count).boolean_data = struct();
            end
            for i = 1:size(connections,1)
                count = count + 1;
                port_constraints(count).port_id_data = struct('component_id',{connections(i,1),connections(i,3)},...
                                                              'port_index',{connections(i,2),connections(i,4)},...
                                                              'port_dimension', {2,2});
                port_constraints(count).constraint_data = struct();
                port_constraints(count).constraint_type = 'direct';
                port_constraints(count).boolean_data = struct();
            end
            if (length(port_constraints) == 1)
                s_aks.('port_constraints') = {port_constraints};
            else
                s_aks.('port_constraints') = port_constraints;
            end
            
            if exist('fname','var');
                out_aks = struct('component_system',s_aks);
                out_aks.('load_cases') = [];
                out_aks.('load_combinations') = [];
                out_aks.('stored_selections') = [];
                savejson('',out_aks,fname);
                s_aks = out_aks;
            end
        end
        % -----
        function load_aks(obj, aks_library, fname)
            json_data = loadjson(fname);
            aks_data = json_data.component_system;
            obj.collection_type = aks_data.collection_type;
            obj.physics_type = aks_library.collections.(obj.collection_type).physics;
            % convert struct 2 cell
            if isstruct(json_data.component_system.components)
                aks_data.components = cell(length(json_data.component_system.components),1);
                for i = 1:length(json_data.component_system.components)
                    aks_data.components{i} = json_data.component_system.components(i);
                end
            end
            % find id names from tag names
            num_comps = length(aks_data.components);
            comp_names = cell(num_comps,1);
            for i = 1:num_comps
                if iscell(aks_data.components{i}.tags)
                    num_tags = length(aks_data.components{i}.tags);
                else
                    num_tags = 1;
                    aks_data.components{i}.tags = {aks_data.components{i}.tags};
                end
                comp_names{i} = char(round(rand(1,6)*(double('z')-double('a'))+double('a')));
                for j = 1:num_tags
                    if not(isempty(regexp(aks_data.components{i}.tags{j},'idname')))
                        comp_names{i} = regexprep(aks_data.components{i}.tags{j},{'idname_','-'},{'','_'});
                        break;
                    end
                end
            end
            % create component system
            for i = 1:num_comps
                component = aks_library.create_component(aks_data.components{i}.ref_component_type);
                component.id = comp_names{i};
                
                % mostly a clone of state save for a few exceptions
                component.state.docking_parameters = aks_data.components{i}.('docking_parameters');
                component.state.parameters = aks_data.components{i}.('parameters');
                component.state.outputs = aks_data.components{i}.('outputs');
                component.state.sources = aks_data.components{i}.('sources');
%                 for j = 1:length(component.state.ports)
%                     component.state.ports{j}.configuration = oc_to_configuration(aks_data.components{i}.ports{j}.orientation,aks_data.components{i}.ports{j}.clicks);
%                     bc_on = false;
%                     for k = 1:length(aks_data.components{i}.ports{j}.boundary_conditions)
%                         if aks_data.components{i}.ports{j}.boundary_conditions{k}.on
%                             bc_name = aks_data.components{i}.ports{j}.boundary_conditions{k}.name;
%                             bc_val = aks_data.components{i}.ports{j}.boundary_conditions{k}.value;
%                             component.state.ports{j}.boundary_condition.(bc_name) = bc_val;
%                             bc_on = true;
%                         end
%                     end
%                     component.state.ports{j}.boundary_condition.on = bc_on;
%                     component.state.ports{j}.connection = struct('component',[],'port',[]);
%                 end

                for j = 1:length(component.state.ports)
                    if (strcmp(obj.physics_type,'elasticitiy') || (strcmp(obj.physics_type,'elasticity_eigen')))
                        component.state.ports{j}.boundary_conditions = struct('on','false','n',0,'t1',0,'t2',0);
                    end
                    if (strcmp(obj.physics_type,'acoustics'))
                        component.state.ports{j}.boundary_conditions = struct('on','false','r_p',0,'i_p',0);
                    end
                    if (strcmp(obj.physics_type,'heat'))
                        component.state.ports{j}.boundary_conditions = struct('on','false','p',0);
                    end
                end
                component.transform_mesh();
                
                obj.add_component(component);
            end
            % create connections
%             for i = 1:size(aks_data.connections,1)
%                 % correct connection
%                 connection = aks_data.connections(i,:)+1;
%                 % assign connections
%                 obj.components.(comp_names{connection(1)}).state.ports{connection(2)}.connection = struct('component',comp_names{connection(3)},'port',connection(4));
%                 obj.components.(comp_names{connection(3)}).state.ports{connection(4)}.connection = struct('component',comp_names{connection(1)},'port',connection(2));
%             end
            for i = 1:length(aks_data.port_constraints)
                constraint_data = aks_data.port_constraints{i};
                if isempty(fieldnames(constraint_data.constraint_data))
                    % connections
                    obj.components.(comp_names{constraint_data.port_id_data{1}.component_id+1}).state.ports{constraint_data.port_id_data{1}.port_index+1}.connection = struct('component',comp_names{constraint_data.port_id_data{2}.component_id+1},'port',constraint_data.port_id_data{2}.port_index+1);
                    obj.components.(comp_names{constraint_data.port_id_data{2}.component_id+1}).state.ports{constraint_data.port_id_data{2}.port_index+1}.connection = struct('component',comp_names{constraint_data.port_id_data{1}.component_id+1},'port',constraint_data.port_id_data{1}.port_index+1);
                    
%                     obj.components.(comp_names{constraint_data.port_id_data{1}.component_id+1}).state.ports{constraint_data.port_id_data{1}.port_index+1}.connection
%                     obj.components.(comp_names{constraint_data.port_id_data{2}.component_id+1}).state.ports{constraint_data.port_id_data{2}.port_index+1}.connection
                else
                    % boundary condition
                    obj.components.(comp_names{constraint_data.port_id_data{1}.component_id+1}).state.ports{constraint_data.port_id_data{1}.port_index+1}.connection = struct('component',[],'port',[]);
                    obj.components.(comp_names{constraint_data.port_id_data{1}.component_id+1}).state.ports{constraint_data.port_id_data{1}.port_index+1}.boundary_condition.on = true;
                    field_names = fieldnames(constraint_data.constraint_data);
                    for j = 1:length(field_names)
                        obj.components.(comp_names{constraint_data.port_id_data{1}.component_id+1}).state.ports{constraint_data.port_id_data{1}.port_index+1}.boundary_condition.(field_names{j}) = constraint_data.constraint_data.(field_names{j});
                    end
                end
            end
        end
        % -----
        function list_components(obj)
            component_names = fieldnames(obj.components);
            for i = 1:length(component_names)
                fprintf('%10s: %s\n', component_names{i}, obj.components.(component_names{i}).get_type);
            end
        end
        % -----
        function list_parameters(obj)
            component_names = fieldnames(obj.components);
            for i = 1:length(component_names)
                fprintf('%10s: %s\n', component_names{i}, obj.components.(component_names{i}).get_type);
                obj.components.(component_names{i}).list_parameters();
            end
        end        
        % -----
        function list_connections(obj)
            aks = obj.gen_aks();
            for i = 1:size(aks.connections,1)
                fprintf('%d-%d (%s) %s %d-%d (%s) %s\n',aks.connections(i,1)+1,aks.connections(i,2)+1,aks.components{aks.connections(i,1)+1}.ref_component_type,oc_to_configuration(aks.components{aks.connections(i,1)+1}.ports{aks.connections(i,2)+1}.orientation,aks.components{aks.connections(i,1)+1}.ports{aks.connections(i,2)+1}.clicks),...
                                                        aks.connections(i,3)+1,aks.connections(i,4)+1,aks.components{aks.connections(i,3)+1}.ref_component_type,oc_to_configuration(aks.components{aks.connections(i,3)+1}.ports{aks.connections(i,4)+1}.orientation,aks.components{aks.connections(i,3)+1}.ports{aks.connections(i,4)+1}.clicks));
            end
        end
        % -----
        function output = solve_batch(obj, sweep_params)
            % check server status
            data = struct('type', 'ServerStatusRequest',...
                          'data', struct('job_info_requests',[],...
                                         'send_user_notification',true));
            [response, status] = server_post(obj.server,data);
            status = status.value;
            if (status ~= 200)
                error('Server: no connection!');
            end
            % submit aks data
            args = struct('component_system', obj.gen_aks(),...
                          'compute_stresses', true,...
                          'compute_reaction_forces', true,...
                          'final_time', 1.0,...
                          'num_proc', 1,...
                          'interval_time', 0.1,...
                          'solver_options_name', 'Direct (MUMPS LU)');
            % populate the parameter batch            
            num_batch = sweep_params(3);
            k_range = linspace(sweep_params(1),sweep_params(2),sweep_params(3));
            batch_model_parameters = cell(1,num_batch);
            for i = 1:num_batch
                component_names = fieldnames(obj.components);
                num_comp = length(component_names);
                model_parameters = cell(1,num_comp);
                k_val = k_range(i);
                for id = 1:num_comp
                    model_parameters{id} = struct('component_id', id-1,...
                                                  'parameters', struct('k', k_val),...
                                                  'sources', {{}});
                end
                batch_model_parameters{i} = struct('model_parameters', {model_parameters});
            end
            args.('batch_solve_request') = struct('batch_model_parameters',{batch_model_parameters});

            data = struct('type', 'ScrbeSolverSolve', 'data', args);
            response = loadjson(char(server_post(obj.server,data)));
            if isfield(response,'error')
                error(response.developer_message);
            end
            job_id = response.('job_id');
            % poke server uptil it gives in
            has_finished = 0;
            while (has_finished == 0)
                args = struct('send_user_notification',true);
                args.('job_info_requests') = {struct('job_id', job_id)};
                data = struct('type', 'ServerStatusRequest', 'data', args);
                              
                response = loadjson(char(server_post(obj.server,data)));
                has_finished = response.job_statuses{1}.('has_finished');
            end
            % we get everything in one go... (maybe too much!)
            data = struct('type', 'ResultRequest', 'data', struct('job_id', job_id, 'idx', 0, 'end_idx', num_batch-1));
            raw_response = char(server_post(obj.server,data));
            response = loadjson(raw_response);
%             % or we get one solution back, one at a time
%             % better for larger num_batch (mainly due to JSON parse speed)
%             response = cell(1,num_batch);
%             for i = 1:num_batch
%                 data = struct('type', 'ResultRequest', 'data', struct('job_id', job_id, 'idx', i-1));
%                 raw_response = char(server_post(obj.server,data));
%                 response{i} = loadjson(raw_response);
% %                 fid = fopen(['response_',sprintf('%03d',i-1),'.json'],'w');
% %                 fprintf(fid,raw_response);
% %                 fclose(fid);
%             end
            output = struct();
            if strcmp(obj.physics_type,'acoustics')
                % reorganize flux information
                Dports = [];
                for id = 1:length(fieldnames(obj.components))
                    name = obj.state.map.fmap{id};
                    for j = 1:length(obj.components.(name).state.ports)
                        % construct a list of port with Dirichlet bc
%                         if (obj.components.(name).state.ports{j}.boundary_condition.on)
                            Dports = [Dports; [id, j]];
%                         end
                    end
                end
                flux_port_outputs = {};
                if (size(Dports,1) > 0)
                    if iscell(response) % single response (scalar) format
                        num_port_flux_solution = length(response{1}.data.('output_datas'));
                        for i = 1:num_port_flux_solution
                            % flux information
                            if not(strcmp(response{1}.data.('output_datas'){i}.output_type,'component_output'))
                                % assuming that the ids are consistent
                                % otherwise it won't work!
                                vport = [response{1}.data.('output_datas'){i}.int_valued_data.component_id,...
                                         response{1}.data.('output_datas'){i}.int_valued_data.port_idx]+1;
                                [isDport, I] = ismember(vport,Dports,'rows');
                                if isDport
                                    component = obj.components.(obj.state.map.fmap{vport(1)});
                                    area = component.cal_area(component.def.faces{vport(2)}.boundary_id);
                                    new_flux = struct('component_name',obj.state.map.fmap{vport(1)},...
                                                      'component_id',vport(1),...
                                                      'port_id',vport(2),...
                                                      'area', area,...
                                                      'flux_output', zeros(1,num_batch));
                                    for j = 1:num_batch
                                        e_output = [response{j}.data.('output_datas'){i}.real_valued_data.real_value,...
                                                    response{j}.data.('output_datas'){i}.imag_valued_data.imag_value];
                                        % Dave's conjugate bug again
                                        new_flux.flux_output(j) = 1/area*(e_output(1) - 1i*e_output(2));
                                    end
                                    flux_port_outputs = [flux_port_outputs, new_flux];
                                end
                            else % component_output
                                % TODO: update after David fixes the conjugate bug
                                name = obj.state.map.fmap{response{1}.data.('output_datas'){i}.int_valued_data.component_id+1};
                                output_id = response{1}.data.('output_datas'){i}.int_valued_data.output_id+1;
                                % calculate area
                                surface_names = obj.components.(name).ref.outputs{output_id}.output_operator_defn.surfaces;
                                area = 0;
                                for j = 1:length(surface_names)
                                    area = area + obj.components.(name).cal_area(surface_names);
                                end
                                tmp_output = struct('area',area,...
                                                    'k', k_range,...
                                                    's', zeros(1,num_batch));
                                for j = 1:num_batch
                                    tmp_output.s(j) = 1/area*(response{j}.data.data.('output_datas'){i}.real_valued_data.real_value - 1i*response{j}.data.('output_datas'){i}.real_valued_data.imag_value);
                                end
                                output.(name){output_id} = tmp_output;
                            end
                        end
                    else % batch (array) format
                        num_port_flux_solution = length(response.data.('output_datas'));
                        for i = 1:num_port_flux_solution
                            % flux information
                            if not(strcmp(response.data.('output_datas'){i}.output_type,'component_output'))
                                vport = [response.data.('output_datas'){i}.int_valued_data.component_id,...
                                         response.data.('output_datas'){i}.int_valued_data.port_idx]+1;
                                [isDport, I] = ismember(vport,Dports,'rows');
                                if isDport
                                    component = obj.components.(obj.state.map.fmap{vport(1)});
                                    area = component.cal_area(component.def.faces{vport(2)}.boundary_id);
                                    % Dave's conjugate bug again
                                    new_flux = struct('component_name',obj.state.map.fmap{vport(1)},...
                                                      'component_id',vport(1),...
                                                      'port_id',vport(2),...
                                                      'area', area,...
                                                      'flux_output', 1/area*(response.data.('output_datas'){i}.real_valued_data.real_value - 1i*response.data.('output_datas'){1}.real_valued_data.imag_value));
                                    flux_port_outputs = [flux_port_outputs, new_flux];
                                end
                            else % component_output
                                name = obj.state.map.fmap{response.data.data.('output_datas'){i}.int_valued_data.component_id+1};
                                output_id = response.data.('output_datas'){i}.int_valued_data.output_id+1;
                                % calculate area
                                surface_names = obj.components.(name).ref.outputs{output_id}.output_operator_defn.surfaces;
                                area = 0;
                                for j = 1:length(surface_names)
                                    area = area + obj.components.(name).cal_area(surface_names);
                                end
                                output.(name){output_id} = struct('area',area,...
                                                                  'k', k_range,...
                                                                  's', 1/area*(response.data.('output_datas'){i}.real_valued_data.real_value - 1i*response.data.('output_datas'){1}.real_valued_data.imag_value));

                            end
                        end
                    end
                end
                flux_output = struct();
                for i = 1:length(flux_port_outputs)
                    flux_output.(flux_port_outputs{i}.component_name){flux_port_outputs{i}.port_id} = ...
                        struct('area', flux_port_outputs{i}.area,...
                               'k', k_range,...
                               's', flux_port_outputs{i}.flux_output);
                end
%                 if iscell(response) % single response (scalar) format
%                     % use first response data to sample output information
%                     num_output = length(response{1}.data.component_outputs);
%                     for i = 1:num_output
%                         % TODO: update after David fixes the conjugate bug
%                         name = obj.state.map.fmap{response{1}.data.component_outputs{i}.component_id+1};
%                         output_id = response{1}.data.component_outputs{i}.output_id+1;
%                         % calculate area
%                         surface_names = obj.components.(name).ref.outputs{output_id}.output_operator_defn.surfaces;
%                         area = 0;
%                         for j = 1:length(surface_names)
%                             area = area + obj.components.(name).cal_area(surface_names);
%                         end
%                         tmp_output = struct('area',area,...
%                                             'k', k_range,...
%                                             's', zeros(1,num_batch));
%                         for j = 1:num_batch
%                             tmp_output.s(j) = 1/area*(response{j}.data.component_outputs{i}.real_value - 1i*response{j}.data.component_outputs{i}.imag_value);
%                         end
%                         output.(name){output_id} = tmp_output;
%                     end
%                 else % batch (array) format
%                     num_output = length(response.data.component_outputs);
%                     for i = 1:num_output
%                         % TODO: update after David fixes the conjugate bug
%                         name = obj.state.map.fmap{response.data.component_outputs{i}.component_id+1};
%                         output_id = response.data.component_outputs{i}.output_id+1;
%                         % calculate area
%                         surface_names = obj.components.(name).ref.outputs{output_id}.output_operator_defn.surfaces;
%                         area = 0;
%                         for j = 1:length(surface_names)
%                             area = area + obj.components.(name).cal_area(surface_names);
%                         end
%                         output.(name){output_id} = struct('area',area,...
%                                                           'k', k_range,...
%                                                           's', 1/area*(response.data.component_outputs{i}.real_value - 1i*response.data.component_outputs{i}.imag_value));
%                     end
%                 end
                
                output = struct('output',output,'flux_output',flux_output);
            end
        end
        % -----
        function [output, flux_output] = solve(obj, sweep_params)
            % check server status
            data = struct('type', 'ServerStatusRequest',...
                          'data', struct('job_info_requests',[],...
                                         'send_user_notification',true));
            [response, status] = server_post(obj.server,data);
            status = status.value;
            if (status ~= 200)
                error('Server: no connection!');
            end
            % submit aks data
            args = struct('component_system', obj.gen_aks(),...
                          'num_proc', 1,...
                          'force_global_truth_solve', false,...
                          'solver_parameters', struct(...
                            'real_valued_data', struct(),...
                            'boolean_data', struct(...
                              'compute_port_outputs', true,...
                              'out_of_core', false),...
                            'int_valued_data', struct('max_dofs_per_port', obj.solver_option.max_dofs_per_port),...
                            'solve_type', 'default',...
                            'string_data', struct(...
                              'linear_solver', 'Direct (MUMPS LU)')),...
                          'visualization_parameters', struct(...
                            'extra_fields', struct(),...
                            'boolean_data', struct(...
                              'compute_stresses', false,...
                              'force_global_truth_solve', false,...
                              'force_mesh_dependent_viz', false,...
                              'plot_gmv', false,...
                              'plot_discontinuous', false,...
                              'plot_surface_only', false,...
                              'single_scalar_viz', false,...
                              'plot_exodus', true,...
                              'no_viz_cache', false,...
                              'use_element_avg_stress', false)));
            
            if exist('sweep_params','var')
                % check k range (hacky)
                comp_names = fieldnames(obj.components);
                k_range = obj.components.(comp_names{1}).dict.parameters.k.range;
                if sweep_params(1) < k_range(1)
                    warning('Range error: k_min is set to %f',k_range(1));
                    sweep_params(1) = k_range(1);
                end
                if sweep_params(2) > k_range(2)
                    warning('Range error: k_max is set to %f',k_range(2));
                    sweep_params(2) = k_range(2);
                end
                
                args.('scrbe_solver_sweep') = struct('f_sweep_min', sweep_params(1),...
                                                     'f_sweep_max', sweep_params(2),...
                                                     'n_sweep_steps', sweep_params(3));
            else
                args.('compute_reaction_forces') = true;
            end
            data = struct('type', 'ScrbeSolverSolve', 'data', args);
            
            server_response = char(server_post(obj.server,data));
            
            response = loadjson(server_response);
            if isfield(response,'error')
                error(response.developer_message);
            end
            job_id = response.('job_id');
            % poke server uptil it gives in
            has_finished = 0;
            while (has_finished == 0)
                args = struct('send_user_notification',true);
                args.('job_info_requests') = {struct('job_id', job_id)};
                data = struct('type', 'ServerStatusRequest', 'data', args);
                              
                response = loadjson(char(server_post(obj.server,data)));
                try
                    has_finished = response.job_statuses{1}.('has_finished');
                catch
                    keyboard
                end
            end
            % request coefficient result
            data = struct('type', 'ResultRequest', 'data', struct('job_id', job_id, 'idx', 0));
            response_text = char(server_post(obj.server,data));            
%             response = loadjson(response_text);
            response = loadjson(response_text,'SkipItems',{'output_datas'});
            
%             fid = fopen('solve_response.json','w');
%             fprintf(fid,'%s', response_text);
%             fclose(fid);
            
            if exist('sweep_params','var')
                obj.solutions.('sweeps') = response.('data');
                
                fprintf('Solution finished! %s', regexprep(response.('data').info_string,{'\nTiming:','\n\n'},{'','\n'}));
                output = struct();
                if strcmp(obj.physics_type,'acoustics')
                    % reorganize flux information
                    % construct a port filter
                    Dports = [];
                    for id = 1:length(fieldnames(obj.components))
                        name = obj.state.map.fmap{id};
                        for j = 1:length(obj.components.(name).state.ports)
                             % filtering Dirichlet bc ports
%                             if (obj.components.(name).state.ports{j}.boundary_condition.on)
                                Dports = [Dports; [id, j]];
%                             end
                        end
                    end
                    flux_port_outputs = {};
                    if (size(Dports,1) > 0)
                        num_sweep_pts = sweep_params(3);
                        num_port_flux_solution = length(response.data.('output_datas'));
                        for i = 1:num_port_flux_solution
                            % only consider flux information
                            if not(strcmp(response.data.('output_datas'){i}.output_type,'component_output'))
                                % assuming that the ids are consistent
                                % between input and output
                                % otherwise it won't work!
                                vport = [response.data.('output_datas'){i}.int_valued_data.component_id, response.data.('output_datas'){i}.int_valued_data.port_idx]+1;
                                [isDport, I] = ismember(vport,Dports,'rows');
                                if isDport
                                    component = obj.components.(obj.state.map.fmap{vport(1)});
                                    area = component.cal_area(component.def.faces{vport(2)}.boundary_id);
                                    % Dave's conjugate bug again
                                    new_flux = struct('component_name',obj.state.map.fmap{vport(1)},...
                                                      'component_id',vport(1),...
                                                      'port_id',vport(2),...
                                                      'area', area,...
                                                      'flux_output', 1/area*(response.data.('output_datas'){i}.real_valued_data.real_value - 1i*response.data.('output_datas'){i}.real_valued_data.imag_value));
                                    flux_port_outputs = [flux_port_outputs, new_flux];
                                end
                            end
                        end
                    end

                    for i = 1:length(obj.solutions.('sweeps').sweep_outputs.outputs)
                        % TODO: update after David fixes the conjugate bug
                        name = obj.state.map.fmap{obj.solutions.('sweeps').sweep_outputs.outputs{i}.component_id+1};
                        output_id = obj.solutions.('sweeps').sweep_outputs.outputs{i}.output_id+1;
                        % calculate area
                        surface_names = obj.components.(name).ref.outputs{output_id}.output_operator_defn.surfaces;
                        area = 0;
                        for j = 1:length(surface_names)
                            area = area + obj.components.(name).cal_area(surface_names);
                        end
                        output.(name){obj.solutions.('sweeps').sweep_outputs.outputs{i}.output_id+1} = ...
                                struct('area',area,...
                                       'k', obj.solutions.('sweeps').sweep_outputs.abscissas,...
                                       's', 1/area*(obj.solutions.('sweeps').sweep_outputs.outputs{i}.real_ordinates - 1i*obj.solutions.('sweeps').sweep_outputs.outputs{i}.imag_ordinates));
                    end
                    
                    flux_output = struct();
                    for i = 1:length(flux_port_outputs)
                        flux_output.(flux_port_outputs{i}.component_name){flux_port_outputs{i}.port_id} = ...
                            struct('area', flux_port_outputs{i}.area,...
                                   'k', obj.solutions.('sweeps').sweep_outputs.abscissas,...
                                   's', flux_port_outputs{i}.flux_output);
                    end
%                     output = struct('output',output', 'flux_output', flux_output);
                else
                    output = struct('k',obj.solutions.('sweeps').sweep_outputs.abscissas, 'outputs',obj.solutions.('sweeps').sweep_outputs.outputs);
%                     output = struct('output',struct('k',obj.solutions.('sweeps').sweep_outputs.abscissas, 'outputs',obj.solutions.('sweeps').sweep_outputs.outputs));
                end
            else
                obj.solutions.('type') = 'RB';
                obj.solutions.('coefficients') = response.('data');
                obj.solutions.('timings') = response.('data').info_string;
                obj.solutions.('files') = '';
                obj.solutions.('viz') = 0;
                fprintf('Solution finished! %s', regexprep(response.('data').info_string,{'\nTiming:','\n\n'},{'','\n'}));
                if nargout == 0
                    return
                end
                if (strcmp(obj.physics_type,'elasticity') || (strcmp(obj.physics_type,'elasticitiy_eigen')))
                    % output = obj.request_max_viz();
                    % return output
                    flux_port_outputs = {};
                    for i = 1:length(response.('data').('output_datas'))
                        if length(response.('data').('output_datas'){i}.output_type)>0
                            name = obj.state.map.fmap{response.('data').('output_datas'){i}.int_valued_data.component_id+1};
                            port_id = response.('data').('output_datas'){i}.int_valued_data.port_idx+1;
                            flux_type = response.('data').('output_datas'){i}.output_type;
                            new_flux = struct('component_name',name,...
                                              'port_id', port_id,...
                                              'type', flux_type,...
                                              'flux_output', [response.data.output_datas{i}.real_valued_data.element_1, response.data.output_datas{i}.real_valued_data.element_2, response.data.output_datas{i}.real_valued_data.element_3]);
                            flux_port_outputs = [flux_port_outputs, new_flux];
                        end
                    end
                    flux_output = struct();
                    for i = 1:length(flux_port_outputs)
                        if isfield(flux_output, flux_port_outputs{i}.component_name) && (length(flux_output.(flux_port_outputs{i}.component_name))>flux_port_outputs{i}.port_id) not(isempty(flux_output.(flux_port_outputs{i}.component_name){flux_port_outputs{i}.port_id}))
                            flux_data = flux_output.(flux_port_outputs{i}.component_name){flux_port_outputs{i}.port_id};
                            flux_output.(flux_port_outputs{i}.component_name){flux_port_outputs{i}.port_id}.(flux_port_outputs{i}.type) = 1/flux_data.area*flux_port_outputs{i}.flux_output;
                        else
                            % calculate area
                            component = obj.components.(flux_port_outputs{i}.component_name);
                            area = component.cal_area(component.def.faces{flux_port_outputs{i}.port_id}.boundary_id);
                            flux_output.(flux_port_outputs{i}.component_name){flux_port_outputs{i}.port_id} = ...
                                struct('area', area,...
                                       flux_port_outputs{i}.type, 1/area*flux_port_outputs{i}.flux_output);
                        end
                    end
                    output = flux_output;
                elseif strcmp(obj.physics_type,'acoustics')
                    output = {};
                    % reorganize flux information
                    % construct a port filter
                    Dports = [];
                    for id = 1:length(fieldnames(obj.components))
                        name = obj.state.map.fmap{id};
                        for j = 1:length(obj.components.(name).state.ports)
                             % filtering Dirichlet bc ports
%                             if (obj.components.(name).state.ports{j}.boundary_condition.on)
                                Dports = [Dports; [id, j]];
%                             end
                        end
                    end
                    flux_port_outputs = {};
                    if (size(Dports,1) > 0)
                        num_port_flux_solution = length(response.data.('output_datas'));
                        for i = 1:num_port_flux_solution
                            % only consider flux information
                            if not(strcmp(response.data.('output_datas'){i}.output_type,'component_output'))
                                % assuming that the ids are consistent
                                % between input and output
                                % otherwise it won't work!
                                vport = [response.data.('output_datas'){i}.int_valued_data.component_id, response.data.('output_datas'){i}.int_valued_data.port_idx]+1;
                                [isDport, I] = ismember(vport,Dports,'rows');
                                if isDport
                                    component = obj.components.(obj.state.map.fmap{vport(1)});
                                    area = component.cal_area(component.def.faces{vport(2)}.boundary_id);
                                    % Dave's conjugate bug again
                                    new_flux = struct('component_name',obj.state.map.fmap{vport(1)},...
                                                      'component_id',vport(1),...
                                                      'port_id',vport(2),...
                                                      'area', area,...
                                                      'flux_output', 1/area*(response.data.('output_datas'){i}.real_valued_data.real_value - 1i*response.data.('output_datas'){i}.real_valued_data.imag_value));
                                    flux_port_outputs = [flux_port_outputs, new_flux];
                                end
                            else
                                name = obj.state.map.fmap{response.data.('output_datas'){i}.int_valued_data.component_id+1};
                                output_id = response.data.('output_datas'){i}.int_valued_data.output_id+1;
                                % calculate area
                                surface_names = obj.components.(name).ref.outputs{output_id}.output_operator_defn.surfaces;
                                area = 0;
                                for j = 1:length(surface_names)
                                    area = area + obj.components.(name).cal_area(surface_names);
                                end
                                output.(name){output_id} = ...
                                        struct('area',area,...
                                               's', 1/area*(response.data.('output_datas'){i}.real_valued_data.real_value - 1i*response.data.('output_datas'){i}.real_valued_data.imag_value));
                            end
                        end
                    end
                    flux_output = struct();
                    for i = 1:length(flux_port_outputs)
                        flux_output.(flux_port_outputs{i}.component_name){flux_port_outputs{i}.port_id} = ...
                            struct('area', flux_port_outputs{i}.area,...
                                   's', flux_port_outputs{i}.flux_output);
                    end
                elseif strcmp(obj.physics_type,'heat')
                    output = struct();
                    for i = 1:length(response.('data').('output_datas'))
                        if strcmp(response.('data').('output_datas'){i}.output_type,'component_output')
                            name = obj.state.map.fmap{response.data.('output_datas'){i}.('int_valued_data').component_id+1};
                            output_id = response.data.('output_datas'){i}.('int_valued_data').output_id+1;
                            % calculate area
                            surface_names = obj.components.(name).ref.outputs{output_id}.output_operator_defn.surfaces;
                            area = 0;
                            for j = 1:length(surface_names)
                                area = area + obj.components.(name).cal_area(surface_names);
                            end
                            output.(name){output_id} = struct('area',area,...
                                                              's', 1/area*(response.data.('output_datas'){i}.('real_valued_data').real_value));
                        end
                    end
                end
            end
        end
        % -----
        function output = solve_truth(obj, sweep_params)
            % I think I was drunk when I wrote this function
            % check server status
            data = struct('type', 'ServerStatusRequest',...
                          'data', struct('job_info_requests',[],...
                                         'send_user_notification',true));
            [response, status] = server_post(obj.server,data);
            status = status.value;
            if (status ~= 200)
                error('Server: no connection!');
            end
            % submit aks data
            args = struct('component_system', obj.gen_aks(),...
                          'num_proc', 1,...
                          'save_mesh_formats', struct(),...
                          'save_system', false,...
                          'use_load_variation', false,...
                          'point_locator_tol', 0.01,...
                          'stitching_tolerance', 0.1,...
                          'solver_parameters', struct(...
                            'real_valued_data', struct(),...
                            'boolean_data', struct('out_of_core', false),...
                            'int_valued_data', struct('max_dofs_per_port', obj.solver_option.max_dofs_per_port),...
                            'solve_type', 'default',...
                            'string_data', struct(...
                              'linear_solver', 'Direct (MUMPS LU)')),...
                          'visualization_parameters', struct(...
                            'extra_fields', struct(),...
                            'boolean_data', struct(...
                              'compute_stresses', false,...
                              'plot_discontinuous', false,...
                              'write_slice_exodus_files', false,...
                              'write_solution_gmv_file', false,...
                              'write_solution_exodus_file', true,...
                              'plot_surface_only', false,...
                              'write_slice_gmv_files', false,...
                              'extract_slices_from_dirichlet_ports', false,...
                              'use_element_avg_stress', false,...
                              'extract_slices', false)));
%                           
%             args = struct('component_system', obj.gen_aks(),...
%                           'compute_stress', true,...
%                           'compute_reaction_forces', true,...
%                           'final_time', 1.0,...
%                           'num_proc', 1,...
%                           'interval_time', 0.1,...
%                           'write_solution_exodus_file', true,...
%                           'write_solution_gmv_file', false,...
%                           'extract_slices', false,...
%                           'write_slice_exodus_files', false,...
%                           'write_slice_gmv_files', false,...
%                           'plot_surface_only', false,...
%                           'plot_discontinuous', false,...
%                           'use_load_variations', false,...
%                           'extract_slices_from_dirichlet_ports', false,...
%                           'skip_solve', false,...
%                           'send_principal_stresses', false,...
%                           'send_full_strain_tensor', false,...
%                           'send_full_stress_tensor', false,...
%                           'stitching_tolerance', 0.1,...
%                           'save_mesh_formats', [],...
%                           'save_system', false,...
%                           'point_locator_tol', 0.01,...
%                           'use_element_avg_stress', false,...
%                           'solver_options_name', 'Direct (MUMPS LU)',...
%                           'solve_max_iterations', 5000,...
%                           'solve_tolerance', 1e-12);
            if strcmp(obj.physics_type,'acoustics')
                args.('visualization_parameters').('boolean_data').('compute_stress') = false;
            end            
            
            if exist('sweep_params','var')
                % check k range (hacky)
                comp_names = fieldnames(obj.components);
                k_range = obj.components.(comp_names{1}).dict.parameters.k.range;
                if sweep_params(1) < k_range(1)
                    warning('Range error: k_min is set to %f',k_range(1));
                    sweep_params(1) = k_range(1);
                end
                if sweep_params(2) > k_range(2)
                    warning('Range error: k_max is set to %f',k_range(2));
                    sweep_params(2) = k_range(2);
                end
                
                args.('fe_solver_sweep') = struct('f_sweep_min', sweep_params(1),...
                                                  'f_sweep_max', sweep_params(2),...
                                                  'n_sweep_steps', sweep_params(3));
            end
            data = struct('type', 'FeSolverSolve', 'data', args);
            
            server_response = char(server_post(obj.server,data));
            response = loadjson(server_response);
            job_id = response.('job_id');
            % poke server uptil it gives in
            has_finished = 0;
            while (has_finished == 0)
                args = struct('send_user_notification',true);
                args.('job_info_requests') = {struct('job_id', job_id)};
                data = struct('type', 'ServerStatusRequest', 'data', args);
                              
                response = loadjson(char(server_post(obj.server,data)));
                has_finished = response.job_statuses{1}.('has_finished');
            end
            
            % request coefficient result
            data = struct('type', 'ResultRequest', 'data', struct('job_id', job_id, 'idx', 0));
            response = loadjson(char(server_post(obj.server,data)));
            if exist('sweep_params','var')
                obj.solutions.('sweeps').sweep_outputs = struct('outputs',cell(length(response.data.files),1));
                fprintf('Solution finished! %s', regexprep(response.('data').info_string,{'\nTiming:','\n\n'},{'','\n'}));
                output = struct();
                k_range = linspace(sweep_params(1),sweep_params(2),sweep_params(3))';
                for ns = 1:length(response.data.files)
                    fname = response.data.files{ns};
                    I = regexp(fname,'/');
                    fname = [fname(1:I(end)),sprintf('solution_%03d_fe_outputs.txt',(ns-1))];
                    data = struct('type', 'download', 'data', fname);
                    txt_data = char(server_post(obj.server,data));
                    single_output = reshape(sscanf(txt_data,'Component %d, Output %d, value = (%f, %f)\n'),4,[])';
                    if ns == 1
                        for i = 1:size(single_output,1)
                            component_id = single_output(i,1)+1;
                            output_id = single_output(i,2)+1;
                            name = obj.state.map.fmap{component_id};
                            surface_names = obj.components.(name).ref.outputs{output_id}.output_operator_defn.surfaces;
                            area = 0;
                            for j = 1:length(surface_names)
                                area = area + obj.components.(name).cal_area(surface_names);
                            end
                            if not(isfield(output,name))
                                output.(name) = cell(0,1);
                            end
                            if output_id > length(output.(name))
                                output.(name){output_id} = struct('k',k_range','area',area','s',zeros(1,sweep_params(3)));
                            end
                        end
                    end
                    for i = 1:size(single_output,1)
                        component_id = single_output(i,1)+1;
                        output_id = single_output(i,2)+1;
                        name = obj.state.map.fmap{component_id};
                        % TODO: Dave's bug - we have to take the conjugate
                        output.(name){output_id}.s(ns) = 1/output.(name){output_id}.area*(single_output(i,3) - 1i*single_output(i,4));
                    end
                end
            else
                obj.solutions.('type') = 'FE';
%                 obj.solutions.('timings') = response.('data').('timings');
                obj.solutions.('files') = response.('data').('files'){1};
                obj.solutions.('viz') = 0;
                fprintf('Solution finished! %s', regexprep(response.('data').info_string,{'\nTiming:','\n\n'},{'','\n'}));
                if nargout == 0
                    return
                end
                output = '';
            end
        end
        % -----
        function output = request_max_viz(obj)
            % request max viz
            fprintf('Requesting max data... ');
            num_comp = length(obj.solutions.('coefficients'));
            viz_response = cell(1,num_comp);
            component_names = fieldnames(obj.components);
            for id = 1:num_comp
                name = component_names{id};
                % request visualization
                args = struct('visualization_parameters', struct(...
                                    'extra_fields', struct(),...
                                    'boolean_data', struct(...
                                      'compute_stresses', false,...
                                      'force_global_truth_solve', false,...
                                      'force_mesh_dependent_viz', false,...
                                      'plot_gmv', false,...
                                      'plot_discontinuous', false,...
                                      'plot_surface_only', false,...
                                      'single_scalar_viz', true,...
                                      'plot_exodus', true,...
                                      'no_viz_cache', false,...
                                      'use_element_avg_stress', false)),...
                                  'rb_component_solution', obj.solutions.coefficients.('rb_solutions')(id));

                if strcmp(obj.physics_type,'elasticity')
                    args.('visualization_parameters').('boolean_data').('compute_stresses') = true;
                    args.('visualization_parameters').('extra_fields') = {'full_stress_tensor', 'full_strain_tensor', 'von_mises', 'principal_stresses'};
                end
                data = struct('type', 'ComponentVisualizationPlot', 'data', args);
                viz_response{id} = loadjson(char(server_post(obj.server,data)));
            end
            fprintf('done!\n');
            output = struct('system',[],'components',[]);
            fnames = fieldnames(viz_response{1}.visualization_summary);
            for id = 1:num_comp
                name = component_names{id};
                output.components.(name) = viz_response{id}.visualization_summary;
                for i = 1:length(fnames)
                    fname = fnames{i};
                    if id == 1
                        output.system.(fname) = struct('min',output.components.(name).(fname).min,'max',output.components.(name).(fname).max);
                    else
                        output.system.(fname).min = min(output.system.(fname).min,output.components.(name).(fname).min);
                        output.system.(fname).max = min(output.system.(fname).max,output.components.(name).(fname).max);
                    end
                end
            end
        end
        % -----
        % Mesh stitching (for debug purpose)
        function mesh = stitch_mesh(obj)
            component_names = fieldnames(obj.components);
            mesh = struct('node_num',0, 'elem_num', 0,...
                          'elem',[], 'node', zeros(0,3),...
                          'surf',[], 'tr_elem', [],...
                          'tnum',[], 'snum', [], ...
                          'tid', {{}}, 'sid', {{}});
            tol = 1e-6;
            all_tnum = []; all_snum = [];
            for id = 1:length(component_names)
                name = component_names{id};
                
                % component node
                tmp_node = obj.components.(name).mesh.tnode;
                R = reshape(obj.components.(name).state.docking_parameters(1:9),3,3)';
                T = obj.components.(name).state.docking_parameters(10:12);
                tmp_node = tmp_node*R' + ones(size(tmp_node,1),1)*T;
                
                % build map using nearest pts search 
                % (need to change to conenction-based later)
                [idx, dist] = knnsearch(mesh.node, tmp_node, 'dist', 'euclidean', 'k', 1);
                pI = find(dist<1e-6);
                npI = setdiff(1:size(tmp_node,1), pI)';
                I = zeros(size(tmp_node,1),1);
                I(pI) = idx(pI);
                I(npI) = (1:length(npI)) + size(mesh.node,1);

%                 % build map using connections
%                 I = zeros(size(tmp_node,1),1);
%                 for i = 1:length(obj.components.(name).state.ports)
%                     if not(isempty(obj.components.(name).state.ports{i}.connection.component))
%                         if find(strcmp(obj.state.map.fmap,obj.components.(name).state.ports{i}.connection.component)) < id
%                             source_port_id = obj.components.(name).dict.idnames.(['port_',num2str(i)]).ids;
%                             target_port_id = find(strcmp(mesh.sid,[obj.components.(name).state.ports{i}.connection.component,'_port_',num2str(obj.components.(name).state.ports{i}.connection.port)]));
%                             I_source = unique(reshape(obj.components.(name).mesh.surf(obj.components.(name).mesh.snum == source_port_id,:),[],1));
%                             I_target = unique(reshape(mesh.surf(mesh.snum == target_port_id,:),[],1));
%                             [idx, dist] = knnsearch(mesh.node(I_target,:), tmp_node(I_source,:), 'dist', 'euclidean', 'k', 1);
%                             if max(dist)>tol
%                                 keyboard
%                                 error('mesh are not conforming')
%                             end
%                             I(I_source) = I_target(idx);
%                             keyboard
%                         end
%                     end
%                 end
                % (need to change to conenction-based later)
                [idx, dist] = knnsearch(mesh.node, tmp_node, 'dist', 'euclidean', 'k', 1);
                pI = find(dist<1e-6);
                npI = setdiff(1:size(tmp_node,1), pI)';
                I = zeros(size(tmp_node,1),1);
                I(pI) = idx(pI);
                I(npI) = (1:length(npI)) + size(mesh.node,1);
                
                mesh.node(I,:) = tmp_node;
                mesh.elem = [mesh.elem; I(obj.components.(name).mesh.elem)];
                mesh.tr_elem = [mesh.tr_elem; I(obj.components.(name).mesh.tr_elem)];
                mesh.surf = [mesh.surf; I(obj.components.(name).mesh.surf)];
                
                new_tnum = unique(obj.components.(name).mesh.tnum);
                tnum_val = length(all_tnum) + (1:length(new_tnum));
                tnum_map = (1:max(new_tnum))'; tnum_map(new_tnum) = tnum_val;
                all_tnum = [all_tnum; tnum_val'];
                mesh.tnum = [mesh.tnum; tnum_map(obj.components.(name).mesh.tnum)];
                for i = 1:length(tnum_val)
                    mesh.tid{tnum_val(i)} = [name,'_',obj.components.(name).dict.ids.(['id_',num2str(new_tnum(i))])];
                end
                
                new_snum = unique(obj.components.(name).mesh.snum);
                snum_val = length(all_snum) + (1:length(new_snum));
                snum_map = (1:max(new_snum))'; snum_map(new_snum) = snum_val;
                all_snum = [all_snum; snum_val'];
                for i = 1:length(snum_val)
                    mesh.sid{snum_val(i)} = [name,'_',obj.components.(name).dict.ids.(['id_',num2str(new_snum(i))])];
                end
                mesh.snum = [mesh.snum; snum_map(obj.components.(name).mesh.snum)];                
            end
            mesh.node_num = size(mesh.node,1);
            mesh.elem_num = size(mesh.elem,1);
%             close all;
%             patch('Vertices',mesh.node,'Faces',mesh.tr_elem(:,1:3),'FaceColor','w','EdgeColor','k'); axis equal;
        end
        % -----
        function eig_values = eig_solve(obj, eig_start, eig_end)
            % check server status
            data = struct('type', 'ServerStatusRequest',...
                          'data', struct('job_info_requests',[],...
                                         'send_user_notification',true));
            [response, status] = server_post(obj.server,data);
            status = status.value;
            if (status ~= 200)
                error('Server: no connection!');
            end
            
            fprintf('Solving for eigenvalues...\n');
            
            eig_values = [];
            if nargin == 1
                eig_start = 1;
                eig_end = 1000;
            elseif nargin == 2
                eig_end = eig_start;
            end
            for eig_id = eig_start:eig_end
                % submit aks data
                args = struct('component_system', obj.gen_aks(),...
                              'num_proc', 1,...
                              'force_global_truth_solve', false,...
                              'solver_parameters',...
                               struct(...
                                'real_valued_data', struct(),...
                                'boolean_data', struct('out_of_core', false),...
                                'int_valued_data', struct('number_of_eigenvalue', eig_id, 'max_dofs_per_port', obj.solver_option.max_dofs_per_port),...
                                'solve_type', 'eigen',...
                                'string_data', struct('linear_solver', 'Direct (MUMPS LU)')...
                               ),...
                              'use_parallel_viz', false);
                data = struct('type', 'ScrbeSolverSolve', 'data', args);

                server_response = char(server_post(obj.server,data));

                response = loadjson(server_response);
                if isfield(response,'error')
                    error(response.developer_message);
                end
                job_id = response.('job_id');
                % poke server uptil it gives in
                has_finished = 0;
                while (has_finished == 0)
                    args = struct('send_user_notification',true);
                    args.('job_info_requests') = {struct('job_id', job_id)};
                    data = struct('type', 'ServerStatusRequest', 'data', args);

                    response = loadjson(char(server_post(obj.server,data)));
                    try
                        has_finished = response.job_statuses{1}.('has_finished');
                    catch
                        keyboard
                    end
                end
                % request coefficient result
                data = struct('type', 'ResultRequest', 'data', struct('job_id', job_id, 'idx', 0));
                response_text = char(server_post(obj.server,data));
                response = loadjson(response_text);
                
                eig_val = response.data.eigenvalue;
                if eig_val > 0
                    eig_val = sqrt(eig_val);
                    eig_values = [eig_values; eig_val];
                    obj.solutions.('type') = 'RB';
                    obj.solutions.('coefficients') = response.('data');
                    obj.solutions.('timings') = response.('data').info_string;
                    obj.solutions.('files') = '';
                    obj.solutions.('viz') = 0;
                    obj.('plot_option').('deformation_scale_factor') = [];
                    fprintf('Find eigenvalue #%d: %f!\n %s\n%s\n', eig_id, eig_val, regexprep(response.('data').info_string,{'\nTiming:','\n\n'},{'','\n'}),'----------');
                else
                    break;
                end
            end
        end
        % -----
        function request_viz(obj, viz_download)
            if not(exist('viz_download','var'))
                viz_download = 1;
            end
            % request solution if there isn't nay
            if not(isfield(obj.solutions,'type'))
                obj.solve();
            end
            if strcmp(obj.solutions.type,'RB')
                % request component visualization
                component_names = fieldnames(obj.components);
                h = waitbar(0,'Requesting solutions...');
                for id = 1:length(component_names)
                    name = component_names{id};

                    waitbar(id/length(component_names),h, sprintf('Requesting solutions... (%d of %d)', id, length(component_names)));

                    % request visualization
                    args = struct('visualization_parameters', struct(...
                                    'extra_fields', struct(),...
                                    'boolean_data', struct(...
                                      'compute_stresses', false,...
                                      'force_global_truth_solve', false,...
                                      'force_mesh_dependent_viz', false,...
                                      'plot_gmv', false,...
                                      'plot_discontinuous', false,...
                                      'plot_surface_only', false,...
                                      'single_scalar_viz', false,...
                                      'plot_exodus', true,...
                                      'no_viz_cache', false,...
                                      'use_element_avg_stress', false)),...
                                  'queue_job', true,...
                                  'rb_component_solution', obj.solutions.coefficients.('rb_solutions')(id));
                    
                    if strcmp(obj.physics_type,'elasticity')
                        args.('visualization_parameters').('boolean_data').('compute_stresses') = true;
                        if isfield(obj.plot_option,'full_stress') && (obj.plot_option.full_stress)
                            args.('visualization_parameters').('extra_fields') = {'full_stress_tensor', 'von_mises', 'principal_stresses'};
                        end
                    end

                    data = struct('type', 'ComponentVisualizationPlot', 'data', args);
                    raw_response = char(server_post(obj.server,data));
                    viz_job_response = loadjson(raw_response);
                    job_id = viz_job_response.job_id;
                    
                    % poke server uptil it gives in
                    has_finished = 0;
                    while (has_finished == 0)
                        args = struct('send_server_info',true);
                        args.('job_info_requests') = {struct('job_id', job_id)};
                        data = struct('type', 'ServerStatusRequest', 'data', args);

                        response = loadjson(char(server_post(obj.server,data)));
                        has_finished = response.job_statuses{1}.('has_finished');
                    end
                    data = struct('type', 'ResultRequest', 'data', struct('job_id', job_id, 'idx', 0));
                    raw_response = char(server_post(obj.server,data));
                    viz_response = loadjson(raw_response);

                    if isfield(viz_response,'visualization_summary')
                        all_solution_field_names = fieldnames(viz_response.visualization_summary);
                        obj.components.(name).mesh.solution_summary = struct();
                        for ifn = 1:length(all_solution_field_names)
                            obj.components.(name).mesh.solution_summary.(all_solution_field_names{ifn}) = viz_response.visualization_summary.(all_solution_field_names{ifn});
                        end
                    end
                    
                    if viz_download
                        waitbar(id/length(component_names),h, sprintf('Downloading solutions... (%d of %d)', id, length(component_names)));
                        % download data
                        fname = viz_response.('data').('result_filepath');
    %                     if ispc
    %                         fname = regexprep(fname,'\.bz2','');
    %                     end
                        data = struct('type', 'download', 'data', fname);
                        exo_data = server_post(obj.server,data);
                        I = regexp(fname,'/'); fname = fname(I(end)+1:end);
                        tmpfname = ['tmp_',name,'_',fname];
                        fid = fopen(tmpfname,'w');
                        fwrite(fid,exo_data,'uint8');
                        fclose(fid);

                        waitbar(id/length(component_names),h, sprintf('Processing solutions... (%d of %d)', id, length(component_names)));

                        % uncompress bz2 if necessary
                        % TODO: find a way to deal with bz2 in Windows
                        if regexp(fname,'gz')
                            gunzip(tmpfname);
                            delete(tmpfname);
                            tmpfname = regexprep(tmpfname,'.gz','');
                        end
                        % parse data
                        if regexp(fname,'cdf') % fastviz format
                            obj.components.(name).read_cdf_solution(tmpfname);
                        elseif regexp(fname,'exo') % fullviz nodal format
                            obj.components.(name).read_exo_solution(tmpfname);
                        end
                        % remove the solution data
                        delete(tmpfname);
                    end
                end
                close(h);
            elseif strcmp(obj.solutions.type,'FE')
                h = waitbar(0,'Downloading FE solutions...');
                % download FE data
                fname = obj.solutions.files;
                if ispc
                    fname = regexprep(fname,'\.bz2','');
                end
                data = struct('type', 'download', 'data', fname);
                exo_data = server_post(obj.server,data);
                I = regexp(fname,'/'); fname = fname(I(end)+1:end);
                tmpfname = ['tmp_FE_',fname];
                fid = fopen(tmpfname,'w');
                fwrite(fid,exo_data,'uint8');
                fclose(fid);
                
                if regexp(fname,'bz2')
                    system(sprintf('bunzip2 %s',tmpfname));
                    tmpfname = regexprep(tmpfname,'.bz2','');
                end
                close(h);
                
                mesh = [];
                ncid = netcdf.open(tmpfname, 'NOWRITE');
                [tmp, num_nodes] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_nodes'));
                [tmp, num_nod_var] = netcdf.inqDim(ncid,netcdf.inqDimID(ncid,'num_nod_var'));
                mesh.node = zeros(num_nodes,3);
                mesh.u = zeros(num_nodes,num_nod_var);
                mesh.node(:,1) = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordx'));
                mesh.node(:,2) = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordy'));
                mesh.node(:,3) = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'coordz'));
                for i = 1:num_nod_var
                    mesh.u(:,i) = netcdf.getVar(ncid,netcdf.inqVarID(ncid,['vals_nod_var',num2str(i)]));
                end
                tmp = netcdf.getVar(ncid,netcdf.inqVarID(ncid,'name_nod_var'));
                for i = 1:size(tmp,2)
                    mesh.unames{i} = deblank(tmp(:,i)');
                end
                netcdf.close(ncid);
                
                % spread solutions onto components
                all_components = fieldnames(obj.components);
                for i = 1:length(all_components)
                    component_node = obj.components.(all_components{i}).mesh.tnode;
                    R = reshape(obj.components.(all_components{i}).state.docking_parameters(1:9),3,3)';
                    T = obj.components.(all_components{i}).state.docking_parameters(10:12);
                    component_node = component_node*R' + ones(size(component_node,1),1)*T;
                    [idx, dist] = knnsearch(mesh.node, component_node,'dist','euclidean','k',2);
                    if max(dist(:,1)) > min(dist(:,2))
                        error('matching FE mesh and component meshes failed!');
                    end
                    idx = idx(:,1);
                    obj.components.(all_components{i}).mesh.u = mesh.u(idx,:);
                    obj.components.(all_components{i}).mesh.unames = mesh.unames;
                end
                % remove the solution data
                delete(tmpfname);
            end
            obj.solutions.viz = 1;
        end
        % -----  
        function h = visualize(obj,uname,wire_alpha,plot_option)
            if not(exist('uname','var')) || isnumeric(uname)
                uname = 'none';
                if isnumeric(uname)
                    wire_alpha = uname;
                end
            end
            if not(iscell(uname)) && not(strcmp(uname,'none')) && not(obj.solutions.viz)
                obj.request_viz();
            end
            component_names = fieldnames(obj.components);
            if strcmp(uname,'all')
                uname = obj.components.(component_names{1}).mesh.unames;
            end
            if not(exist('wire_alpha','var'))
                wire_alpha = 0;
            end
            if not(iscell(uname))
                uname = {uname};
            end
            m = length(uname);
            if m < 4
                n1 = 1;
            else
                n1 = ceil(sqrt(m));
            end
            n2 = ceil(m/n1);
            if m == 1
                h = figure;
            else
                h = zeros(m,1);
            end
            
            % calculate deformation factor
            if (strcmp(obj.physics_type,'elasticity') || strcmp(obj.physics_type,'elasticity_eigen'))
                if not(strcmp(uname{1},'none')) && isempty(obj.('plot_option').('deformation_scale_factor'))
                    bbsize = [-1e8*[1,1];1e8*[1,1]]; usize = bbsize;
                    for i = 1:length(component_names)
                        bbsize(1,:) = max([max(obj.components.(component_names{i}).mesh.node),bbsize(1,:)]);
                        bbsize(2,:) = min([min(obj.components.(component_names{i}).mesh.node),bbsize(2,:)]);
                        I = [find(strcmp(obj.components.(component_names{i}).mesh.unames,'u')),find(strcmp(obj.components.(component_names{i}).mesh.unames,'v')),find(strcmp(obj.components.(component_names{i}).mesh.unames,'w'))];
                        usize(1,:) = max([max(obj.components.(component_names{i}).mesh.u(:,I)),usize(1,:)]);
                        usize(2,:) = min([min(obj.components.(component_names{i}).mesh.u(:,I)),usize(2,:)]);
                    end
                    obj.('plot_option').('deformation_scale_factor') = 0.2*max(max(bbsize(1,:)-bbsize(2,:)))/max(max(usize(1,:)-usize(2,:)));
                else
                    obj.('plot_option').('deformation_scale_factor') = 0.;
                end
            end
            for j = 1:m
                h(j) = subplot(n1,n2,j);
                for i = 1:length(component_names)
                    if (strcmp(obj.physics_type,'elasticity') || strcmp(obj.physics_type,'elasticity_eigen')) && isfield(obj.('plot_option'),'deformation_scale_factor')
                        obj.components.(component_names{i}).visualize(wire_alpha,0,uname{j},obj.('plot_option').('deformation_scale_factor'));
                    else
                        obj.components.(component_names{i}).visualize(wire_alpha,0,uname{j});
                    end
                end
                if not(strcmp(uname{j},'none'))
                    if strcmp(obj.solutions.type,'FE')
                        title([obj.components.(component_names{i}).physics.solution_fields.(uname{j}).gui_name,' (',obj.solutions.type,')']);
                    else
                        title(obj.components.(component_names{i}).physics.solution_fields.(uname{j}).gui_name);
                    end
                end
                if exist('plot_option','var')
                    eval(plot_option)
                end
            end
        end
        % -----  
        function h = visualize_slice(obj,uname,plane,plot_option)
            if not(exist('uname','var')) || isnumeric(uname)
                uname = 'none';
            end
            if not(strcmp(uname,'none')) && not(obj.solutions.viz)
                obj.request_viz();
            end
            component_names = fieldnames(obj.components);
            if strcmp(uname,'all')
                uname = obj.components.(component_names{1}).mesh.unames;
            end
            if not(iscell(uname))
                uname = {uname};
            end
            m = length(uname);
            if m < 4
                n1 = 1;
            else
                n1 = ceil(sqrt(m));
            end
            n2 = ceil(m/n1);
            if m == 1
                h = figure;
            else
                h = zeros(m,1);
            end
            for j = 1:m
                h(j) = subplot(n1,n2,j);
                for i = 1:length(component_names)
                    obj.components.(component_names{i}).visualize_slice(plane,0,uname{j});
                end
                if not(strcmp(uname{j},'none'))
                    title(obj.components.(component_names{i}).physics.solution_fields.(uname{j}).gui_name);
                end
                if exist('plot_option','var')
                    eval(plot_option)
                end
            end
        end
        % -----  
        function h = visualize_clip(obj,uname,plane,plot_option)
            if not(exist('uname','var')) || isnumeric(uname)
                uname = 'none';
            end
            if not(strcmp(uname,'none')) && not(obj.solutions.viz)
                obj.request_viz();
            end
            component_names = fieldnames(obj.components);
            if strcmp(uname,'all')
                uname = obj.components.(component_names{1}).mesh.unames;
            end
            if not(iscell(uname))
                uname = {uname};
            end
            m = length(uname);
            if m < 4
                n1 = 1;
            else
                n1 = ceil(sqrt(m));
            end
            n2 = ceil(m/n1);
            if m == 1
                h = figure;
            else
                h = zeros(m,1);
            end
            for j = 1:m
                h(j) = subplot(n1,n2,j);
                for i = 1:length(component_names)
                    obj.components.(component_names{i}).visualize_clip(plane,0,uname{j});
                end
                if not(strcmp(uname{j},'none'))
                    title(obj.components.(component_names{i}).physics.solution_fields.(uname{j}).gui_name);
                end
                if exist('plot_option','var')
                    eval(plot_option)
                end
            end
        end
    end
end

function [orientation, click] = configuration_to_oc(conf_name)
    if not(isempty(regexp(conf_name,'OUTWARD','once')))
        orientation = 0;
    else
        orientation = 1;
    end
    click = str2double(regexprep(conf_name,{'INWARD','OUTWARD'},{'',''}));
end

function configuration = oc_to_configuration(orientation, click)
    if (orientation==0)
        configuration = 'OUTWARD';
    else
        configuration = 'INWARD';
    end
    configuration = [configuration,num2str(click)];
end

function pts = get_three_pts(pts, o, c)
    c = c+1;
    n = size(pts,1);
    if (o>0)
        pts = [pts(end:-1:1,:);pts(end:-1:1,:)];
    else
        pts = [pts;pts];
    end
    pts = pts(c:c+2,:);
end

function [R, T] = find_rotation_matrix(p1, p2)
    if size(p1,1) == 2
        % SVD
        pc1 = mean(p1);
        pc2 = mean(p2);

        ps1 = p1 - ones(2,1)*pc1;
        ps2 = p2 - ones(2,1)*pc2;
        M = ps2'*ps1;
        [s,v,d] = svd(M);
        R = s*d';
        T = pc2-pc1*R';
        return;
    end

    pn1 = p1(2,:) + cross(p1(2,:)-p1(1,:),p1(3,:)-p1(2,:));
    pn2 = p2(2,:) + cross(p2(2,:)-p2(1,:),p2(3,:)-p2(2,:));

    M1 = zeros(4,4);
    M1(1:3,:) = [p1;pn1]';
    M1(4,1:4) = ones(1,4);
    M2 = zeros(4,4);
    M2(1:3,:) = [p2;pn2]';
    M2(4,1:4) = ones(1,4);
    R = M2*inv(M1);

    T = R(1:3,4)';
    R = R(1:3,1:3);
end

function valid = validate_rotation_matrix(R)
    valid = (norm(R'*R-eye(3)) < 1e-3);
end

function pairs = find_valid_configurations(c1, c2)
    % generate a list of possible connections
    pairs = {};
    for i = 1:length(c1)
        for j = 1:length(c2)
            if ((isempty(strfind(c1{i},'INWARD')) + isempty(strfind(c2{j},'INWARD'))) == 1)
                pairs = [pairs;{c1{i},c2{j}}];
            end
        end
    end
end

function patch_id = graphcomp(G)
    % graph connection by BFS
    n = size(G,1);
    I = cell(n,1);
    for i = 1:n
        I{i} = find(G(i,:));
    end
    
    patch_id = -1*ones(1,n);
    v_ = find(patch_id == -1);
    id_ = 1;
    patch = {};
    while length(v_)>0
        v_ = v_(1);
    	patch_ = [];
	    Q_ = [];
	    Q_ = [Q_, v_];
	    patch_ = [patch_, v_];
	    patch_id(v_) = id_;
	    while length(Q_)>0
	    	v_ = Q_(end);
            Q_(end) = [];
            for i = 1:length(I{v_})
	    		w_ = I{v_}(i);
	    		if (patch_id(w_) == -1)
	    			Q_ = [Q_,w_];
	    			patch_ = [patch_, w_];
	    			patch_id(w_) = id_;
                end
            end
        end
	    id_ = id_ + 1;
	    v_ = find(patch_id == -1);
	    patch = [patch, patch_];
    end
end

function [response, status] = server_post(server,params)
    query = params;
    
    if ~isfield(params,'username') || ~isfield(params,'password')
        params.username = server.username;
        params.password = server.password;
    end
    time_id = datestr(now,'HH_MM_SSFFF');
    
    headers = struct('name',{'content-type','Accept-Encoding'},...
                     'value',{'application/x-www-form-urlencoded', 'identity'});
    params = savejson('',params);
    % hack Sylvain's silly string
    params = regexprep(params,'number_of_eigenvalue','Number of eigenvalues');
    
    url = ['http://',server.ip_address,':',num2str(server.http_port),server.prefix,'/'];
    [response, extra] = urlread2(url,'POST',params,headers,1);
%     response = char(response);
    status = extra.status;
    
%     c_id = datestr(now,'HH-MM-SSFFF');
%     c_response = char(response);
%     c_query = savejson('',params);
%     if c_response(1) == '{'
% %         c_response = loadjson(c_response);
%     else
%         c_response = 'bin';
%     end
%     if not(exist('MUI_log.mat','file'))
%         data = struct('query',c_query,'response',c_response,'id',c_id);
%         save('MUI_log','data');
%     else
%         load('MUI_log');
%         count = length(data);
%         data(count+1).query = c_query;
%         data(count+1).response = c_response;
%         data(count+1).id = c_id;
%         save('MUI_log','data');
%     end
end