%% added points are added in the end of the p list
function [p,t,ec,ecnum] = cdelaunay(p,e,enum,icheck,mflag)

% no constraints, just delaunay
if nargin == 1
    t = delaunay(p(:,1),p(:,2),{'Qt','Qbb','Qc','Qz'});
    return;
end

if not(exist('mflag'))
    mflag = 1; % edge swap method
end

if not(exist('icheck')) || icheck
    if isintersect(p,e)
        [ii,pc] = isintersect(p,e);
        figure;
        plot(p(:,1),p(:,2),'.b');
        hold on;
        plot(pc(1),pc(2),'-or');
        for i = 1:size(e,1);
            plot(p(e(i,:),1),p(e(i,:),2),'-xg');
        end
        hold off;
        error('constrained edges are intesected themselves!');
    end
end

if not(exist('enum')) || isempty(enum)
    enum = ones(size(e,1),1);
end

[ec,I] = sort(e,2);
ecnum = enum;
t = delaunay(p(:,1),p(:,2),{'Qt','Qbb','Qc','Qz'});
e = unique(sort([t(:,[1,2]);t(:,[2,3]);t(:,[3,1])],2),'rows');

switch mflag
    case 0
        % point insertion method
        while sum(ismember(ec,e,'rows')) ~= size(ec,1)
        
        %     gcf = figure;
        %     subplot(1,2,1); hold on; triplot(t,p(:,1),p(:,2)); for i = 1:size(ec,1); plot(p(ec(i,:),1),p(ec(i,:),2),'-or'); end
        
            I = find(not(ismember(ec,e,'rows')));
            etmp = ec(I,:);
            ec(I,:) = [];
            ecnumtmp = ecnum(I);
            ecnum(I) = [];
            for i = 1:size(etmp,1)
                p = [p; sum(p(etmp(i,:),:))/2];
                ec = [ec; [etmp(i,1),size(p,1)]; [etmp(i,2),size(p,1)]];
                ecnum = [ecnum;ecnumtmp(i);ecnumtmp(i)];
            end
        
            t = delaunay(p(:,1),p(:,2),{'Qt','Qbb','Qc','Qz'});
            e = unique(sort([t(:,[1,2]);t(:,[2,3]);t(:,[3,1])],2),'rows');
        
        %     subplot(1,2,2); triplot(t,p(:,1),p(:,2)); hold on; triplot(t,p(:,1),p(:,2)); for i = 1:size(ec,1); plot(p(ec(i,:),1),p(ec(i,:),2),'-or'); end
        %     pause
        % % %     keyboard
        %     close(gcf);
        end

    case 1
        % flipping method
        while sum(ismember(ec,e,'rows')) ~= size(ec,1)

            I = find(not(ismember(ec,e,'rows')));

            [e,te,tadj,eadj,padj] = get_te(t); e = sort(e,2);
            ectmp = ec(I(1),:);
            tball = padj{ectmp(1)};
            eball = unique(reshape(te(tball,:),length(tball)*3,1));
            eball = eball(find(not(any(ismember(e(eball,:),ectmp(1)),2))));
            for i = 1:size(eball,1)
                if isintersect(p,[e(eball(i),:);ectmp])
                    break;
                end
            end
            eintersect = eball(i);
            tball = eadj(eintersect,:);
            if ismember(ectmp(1),t(tball(2),:))
                tball = tball([2,1]);
            end
            pball = unique(reshape(t(tball,:),length(tball)*3,1));
            while not(all(ismember(ectmp,pball)))
                etmp = setdiff(te(tball(end),:),eintersect);
                for i = 1:length(etmp)
                    if isintersect(p,[e(etmp(i),:);ectmp])
                        break;
                    end
                end
                eintersect = [eintersect,etmp(i)];
                tball = [tball,setdiff(eadj(eintersect(end),:),tball)];
                pball = unique(reshape(t(tball,:),length(tball)*3,1));
            end

%             gcf = figure;
%             subplot(1,2,1); hold on; triplot(t,p(:,1),p(:,2)); for i = 1:size(I,1); plot(p(ec(I(i),:),1),p(ec(I(i),:),2),'-k','LineWidth',2); end
%             for i = 1:length(tball); fill(p(t(tball(i),:),1),p(t(tball(i),:),2),'r','FaceAlpha',0.5); end

            % swapping edges
            tnew = zeros(0,3);
            ttmp = t(tball(1),:);
            for i = 1:length(tball)-1
                ptmp = unique([ttmp';t(tball(i+1),:)']); ptmp = setdiff(ptmp,e(eintersect(i),:));
                ttmp = [ptmp,e(eintersect(i),1);ptmp,e(eintersect(i),2)];
                if i == length(tball)-1
                    tnew = [tnew; ttmp];
                else
                    if all(ismember(e(eintersect(i+1),:),ttmp(1,:)))
                        tnew = [tnew; ttmp(2,:)];
                        ttmp = ttmp(1,:);
                    else
                        tnew = [tnew; ttmp(1,:)];
                        ttmp = ttmp(2,:);
                    end
                end
            end
            t(tball,:) = [];
            t = [t;tnew];
            e = unique(sort([t(:,[1,2]);t(:,[2,3]);t(:,[3,1])],2),'rows');

%             subplot(1,2,2); triplot(t,p(:,1),p(:,2)); hold on; triplot(t,p(:,1),p(:,2)); for i = 1:size(ec,1); plot(p(ec(i,:),1),p(ec(i,:),2),'-or'); end
%             for i = 1:size(tnew,1); fill(p(tnew(i,:),1),p(tnew(i,:),2),'r'); end
%             pause
%             close(gcf);
        end
end

%----------------------------------------------------------------------
function [ii,pc] = isintersect(p,e)
ii = 0;
for i = 1:size(e,1)
    for j = (i+1):size(e,1)
        if length(unique([e(i,:),e(j,:)]))==4
            pp = [p(e(i,:),:);p(e(j,:),:)];
            A = [(pp(2,1)-pp(1,1)),-(pp(4,1)-pp(3,1));...
                (pp(2,2)-pp(1,2)),-(pp(4,2)-pp(3,2))];
            if abs(det(A))< 1e-8 % parallel lines
                break;
            end
            t = A\[pp(3,1)-pp(1,1);pp(3,2)-pp(1,2)];
            if min(t)>0 && max(t)<1
                ii = 1;
                pc = [pp(1,1) + t(1)*(pp(2,1)-pp(1,1)), pp(1,2) + t(1)*(pp(2,2)-pp(1,2))];
                % pc2 = [pp(3,1) + t(2)*(pp(4,1)-pp(3,1)), pp(3,2) + t(2)*(pp(4,2)-pp(3,2))]; [pc, pc2]
                break;
            end
        end
    end
end

