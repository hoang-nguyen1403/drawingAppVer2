function [p,t,ec,ecnum,tnum] = meshing2d(pp,ee,gfun,gref,esize)

% Note: becareful when eval gfun since its variable is "t"

% pp = [0,0;3,0;3,1;3,2;3,3;3,4;2,4;2,1;1,1;1,4;0,4;0,3;0,2;0,1];
% ee = [1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12,13;13,14;14,1]; 
% gref = {[1,2;2,3],[6,3;7,2]};
% esize = 0.2;

% pp = [0,0; 4,0; 2,3 ; 1.5,0.5;2.5,0.5;2.5,1.5;1.5,1.5];
% ee = {[1,2;2,3;3,1],[4,5;5,6;6,7;7,4]}; 
% esize = 0.5;

% pp = [0,0;3,0;3,6;2,6;2,1;1,1;1,6;0,6];
% ee = {[1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,1]}; 
% esize = 0.5;

% pp = [-4,-4;4,-4;4,4;-4,4; -3,-3;-2,-3;-2,-2;-3,-2; 3,-3;2,-3;2,-2;3,-2;-3,-1;3,-1;2,3;-3,2];
% ee = {[1,2;2,3;3,4;4,1],[5,6;6,7;7,8;8,5;9,10;10,11;11,12;12,9;13,14;14,15;15,16;16,13],[6,10;7,11]}; 
% esize = 0.5;

% pp = [0,0;3,0;3,10;-1,10;-1,3;1,3;1,5;0,5;0,9;2,9;2,1;1,1;1,2;0,2; -0.5,3.5;0.5,3.5;0.5,4.5;-0.5,4.5];
% ee = {[1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12,13;13,14;14,1],[15,16;16,17;17,18;18,15],[5,15;7,17]};
% gref = {[15,3;16,3;17,3;18,3],[]};
% esize = 0.25;

% pp = [0,0;3,0;3,10;2,10;2,1;1,1;1,2;0,2];
% ee = [1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,1];
% for i = 1:size(ee,1); gfun{i} = {0,0,0}; end; gfun{1} = {{'1.5+1.5*cos(t)','2.5*sin(t)'},[-pi,0],1};
% gref = {[],[1,3]};
% esize = 0.5;

% pp = [0,0;3,0;3,10;-1,10;-1,3;0,3;0,6;2,6;2,1;1,1;1,2;0,2;0.5,7;1.5,7;2,8;1,9;0,8];
% ee = {[1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12,1],[13,14;14,15;15,16;16,17;17,13],[16,3;16,4;7,13;8,14]};
% gref = {[],[13,4;14,4;15,4;16,4;17,4]};
% esize = 0.3;

% pp = [0         0;    0.3750         0;    0.6250         0;    1.0000         0;    1.0000    0.2500;    1.0000    0.7500;    1.0000    1.0000;    0.6250    1.0000;    0.3750    1.0000;         0    1.0000;         0    0.7500;         0    0.2500;    0.3750    0.2500;    0.6250    0.2500;    0.6250    0.7500;    0.3750    0.7500];
% ee = {[1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;1,12],[13,14;14,15;15,16;13,16],[2,12;2,13;2,14;3,14;4,14;5,14;5,15;6,15;7,15;8,15;9,11;9,15;9,16;11,13;11,16;12,13]};
% esize = 0.05;

if iscell(ee)
    eb = ee;
    if size(ee)<3 % no extra contrained edges
        ee{3} = [];
    end
    epnum = size(ee{1},1);
    % outer and inner boundaries
    eeb = [ee{1};ee{2}];
    ebnum = size(eeb,1);
    ee = [ee{1};ee{2};ee{3}]; % ee{3} contains extra constrained edges
    ee = sort(ee,2);
%     [ee,I,J] = unique(ee,'rows');
    eenum = (1:size(ee,1))';
else
    eeb = ee;
    eenum = (1:size(ee,1))';
    ebnum = size(ee,1);
    epnum = size(ee,1);
end

isgfun = 1;
if not(exist('gfun')) || isempty(gfun)
    for i = 1:size(ee,1)
%         pe = pp(ee(i,:),:);
%         gfun{i} = {{[num2str(pe(1,1)),'+t*',num2str(pe(2,1)-pe(1,1))],[num2str(pe(1,2)),'+t*',num2str(pe(2,2)-pe(1,2))]},[0,1],0};
        gfun{i} = {0,0,0};
    end
    isgfun = 0;
end

isgref = 1;
greftmp{1} = [(1:size(pp,1))',ones(size(pp,1),1)];
greftmp{2} = [(1:size(ee,1))',ones(size(ee,1),1)];
if not(exist('gref')) || isempty(gref)
    gref = greftmp;
else
    for i = 1:2
        if not(isempty(gref{i}))
            I = find(ismember(greftmp{i}(:,1),gref{i}(:,1)));
            greftmp{i}(I,:) = gref{i};
        end
    end
    gref = greftmp;
end

t = delaunay(pp(:,1),pp(:,2));
[e,te] = get_te(t);

le = get_le(pp,ee);
if not(exist('esize'))
    esize = min(le)/3;
end

if esize>min(le)
    esize = min(le);
end

% now we begin to construct the mesh
% pp should be always in the first part of p during the whole process...

% construct a (coarse) background mesh
if isgfun
    esizetmp = esize;
    eflag = zeros(ebnum,1);
    for i = 1:ebnum
        if gfun{i}{3}
            eflag(i) = 1;
        end
    end
    [ptmp,ectmp,ecnumtmp] = lgdivide(pp,eeb,gfun,eenum,esizetmp,eflag);
    bgm = dpartition(ptmp,ectmp);
    [p,ec,ecnum,ect] = lgdivide(pp,ee,gfun,eenum,esize);
else
    bgm = dpartition(pp,eeb);
    [p,ec,ecnum,ect] = lgdivide(pp,ee,gfun,eenum,esize);
end

% triplot(bgm.t(find(bgm.tflag),:),bgm.p(:,1),bgm.p(:,2)); axis equal;

% figure;
% hold on;
% for i = 1:size(ee,1)
%     pe = pp(ee(i,:),:);
%     plot(pe(:,1),pe(:,2),'-or');    
% end
% axis equal;
% hold off;

% ecnum_old = ecnum; ec_old = ec;

% construct an empty mesh using bgm
[p,t] = dpartition(p,ec,ecnum,bgm);
% circumcenter insertions
[p,t] = pinsert(p,ec,ecnum,t,esize,bgm);
% mesh optimization
[p,t] = mesh_opt(p,t,ec,ecnum,esize,bgm);

% if any(any([ec-ec_old,ecnum-ecnum_old]),2)
%     keyboard
% end

% pause

% refine mesh
grefnum = 2;
while grefnum <= max([gref{1}(:,2);gref{2}(:,2)])
    esize = esize/2;
    % recreate bgm
    esizetmp = esize;
    eflag = zeros(ebnum,1);
    for i = 1:ebnum
        if gfun{i}{3}
            eflag(i) = 1;
        end
    end
    [ptmp,ectmp] = lgdivide(pp,eeb,gfun,eenum,esizetmp,eflag);
    bgm = dpartition(ptmp,ectmp);
    % insert new point (edge based)
    [p,ec,ecnum,ect] = mesh_ref(p,t,ec,ecnum,ect,gfun,esize,gref,grefnum);
    % reconstruct the mesh
    [p,t] = dpartition(p,ec,ecnum,bgm);
    [p,t,ec,ecnum] = mesh_opt(p,t,ec,ecnum,esize,bgm,[0,1,1,1]);
    grefnum = grefnum + 1;
    
%     close all;
%     hold on;
%     triplot(t,p(:,1),p(:,2)); axis equal;
%     for j = 1:max(ecnum)
%         color = rand(3,1);
%         I = find(ecnum == j);
%         for i = 1:size(ec(I),1)
%             plot(p(ec(I(i),:),1),p(ec(I(i),:),2),'-','LineWidth',2,'Color',color);
%         end
%     end
% 	drawnow;    

end

% re-winding
for i = 1:size(t,1)
    pe = p(t(i,:),:);
    tmp = [pe,[0;0;0]];
    tmp = cross(tmp(3,:)-tmp(2,:),tmp(1,:)-tmp(2,:));
    if tmp(3)<0
        t(i,:) = t(i,[1,3,2]);
    end
end

tnum = find_tnum(t,ec,ecnum);

% close all;
% hold on;
% for i = 1:max(tnum)
%     I = find(tnum == i);
%     triplot(t(I,:),p(:,1),p(:,2),'Color',[rand,rand/2,rand]);
% end
% axis equal;
% title(['np = ',num2str(size(p,1)),', nt = ',num2str(size(t,1))]);
% pause

%--------------------------------------
function le = get_le(p,e,gfun)
if nargin == 2
    pe = p(reshape(e',size(e,1)*2,1),:);
    tmp = diff(pe);
    tmp = tmp(1:2:end,:);
    le = sqrt(sum(tmp.^2,2));
else
    le = get_le(p,e);
    N = 20; % lousy "segment summation" integration
    for i = 1:size(e,1);
        if gfun{i}{3}
            ttmp = linspace(gfun{i}{2}(1),gfun{i}{2}(2),N);
            ptmp = zeros(N,2);
            for j = 1:N
                t = ttmp(j);
                ptmp(j,:) = [eval(gfun{i}{1}{1}),eval(gfun{i}{1}{2})];
            end
            le(i) = sum(sqrt(sum(diff(ptmp).^2,2)));
        end
    end
end

%---------------------------------------
function [pc,rc] = pcircen(pe)
A = [pe(1,1)-pe(2,1),pe(1,2)-pe(2,2);pe(1,1)-pe(3,1),pe(1,2)-pe(3,2)];
b = 1/2*[(pe(1,1)^2-pe(2,1)^2) + (pe(1,2)^2-pe(2,2)^2);(pe(1,1)^2-pe(3,1)^2) + (pe(1,2)^2-pe(3,2)^2)];
pc = (A\b)';
rc = norm(pc-pe(1,:));
%---------------------------------------
function a = tarea(pe)
a = 0.5*abs(det([[1;1;1],pe]));
%---------------------------------------
function q = cal_q(pe)
a = tarea(pe);
L = [norm(pe(1,:)-pe(2,:));norm(pe(2,:)-pe(3,:));norm(pe(3,:)-pe(1,:));];
p = sum(L)/2;
q = sqrt(3)/6*max(L)*p/a;
%---------------------------------------
function [p,t,ec,ecnum] = pinsert(pp,ec,ecnum,t,esize,bgm)
np = 0; p = pp; esize2 = 0.75*esize^2;j = 0;
while np~=size(p,1);
    np = size(p,1);

    ptmp = pp;

    tic
    for i = 1:size(t,1)
        [pcen,pr] = pcircen(pp(t(i,:),:));
        if pr>esize/(sqrt(3))
            l = sum((ptmp-ones(size(ptmp,1),1)*pcen).^2,2);
            if size(ptmp,1) == 0 || min(l)>esize2
                ptmp = [ptmp;pcen];
            end
        end
    end
    t1 = toc;
    p = ptmp;

    tic
    [p,t,ec,ecnum] = dpartition(p,ec,ecnum,bgm);    
    t2 = toc;

%     triplot(t,p(:,1),p(:,2)); axis equal; hold on;
%     for i = 1:size(ec,1); plot(p(ec(i,:),1),p(ec(i,:),2),'-or','LineWidth',2);end
%     pause
%     close all;
    
    pp = p;
    
%     triplot(t,p(:,1),p(:,2)); axis equal; title(['np = ',num2str(np),', nt = ',num2str(size(t,1))]);
%     drawnow;
%     pause
% keyboard
    
%     [t1,t2]
end

% %---------------------------------------
% function [pp,ee,enum] = ldivide(pp,ee,eenum,esize);
% 
% le = get_le(pp,ee);
% ndiv = ceil(le/esize) + 1;
% npp = size(pp,1);
% 
% etmp = zeros(0,2);
% enum = zeros(0,1);
% for i = 1:size(ee,1)
%     pe = pp(ee(i,:),:);
%     ttmp = linspace(0,1,ndiv(i));
%     ttmp = ttmp(2:end-1);
%     ptmp = zeros(0,2);
%  
%     if length(ttmp)>0
%         etmp = [etmp;ee(i,1),size(pp,1)+1];
%         for j = 1:length(ttmp)
%             ptmp = [ptmp; pe(1,:) + ttmp(j)*(pe(2,:)-pe(1,:))];
%             if j<length(ttmp)
%                 etmp = [etmp; size(pp,1)+j, size(pp,1)+j+1];
%             end
%         end
%         etmp = [etmp; size(pp,1)+length(ttmp), ee(i,2)];
%         pp = [pp;ptmp];
%         enum = [enum; eenum(i)*ones(size(ptmp,1)+1,1)];
%     end
% end
% ee = etmp;

%---------------------------------------
function [pp,ee,enum,ett] = lgdivide(pp,ee,gfun,eenum,esize,eflag);

if not(exist('eflag'))
    eflag = ones(size(ee,1));
end

le = get_le(pp,ee,gfun);
ndiv = ceil(le/esize) + 1;
npp = size(pp,1);

ndiv(find(not(eflag))) = 2;

etmp = zeros(0,2);
enum = zeros(0,1);
ett = zeros(0,2);
for i = 1:size(ee,1)
    pe = pp(ee(i,:),:);
    if gfun{i}{3}
        tt = linspace(gfun{i}{2}(1),gfun{i}{2}(2),ndiv(i));
    else
        tt = linspace(0,1,ndiv(i));
    end
    ttmp = tt(2:end-1);
    ptmp = zeros(0,2);
 
    if length(ttmp)>0
        etmp = [etmp;ee(i,1),size(pp,1)+1];
        ett = [ett; tt(1), tt(2)];
        for j = 1:length(ttmp)
            if gfun{i}{3}
                t = ttmp(j); ptmp = [ptmp; [eval(gfun{i}{1}{1}),eval(gfun{i}{1}{2})]];
            else
                ptmp = [ptmp; pe(1,:) + ttmp(j)*(pe(2,:)-pe(1,:))];
            end
            if j<length(ttmp)
                etmp = [etmp; size(pp,1)+j, size(pp,1)+j+1];
                ett = [ett; tt(j+1), tt(j+2)];
            end
        end
        etmp = [etmp; ee(i,2), size(pp,1)+length(ttmp)];
        ett = [ett; tt(end), tt(end-1)];
        pp = [pp;ptmp];
        enum = [enum; eenum(i)*ones(size(ptmp,1)+1,1)];
    else
        etmp = [etmp;ee(i,:)];
        enum = [enum;i];
        if gfun{i}{3}
            ett = [ett;[gfun{i}{2}(1),gfun{i}{2}(2)]];
        else
            ett = [ett;[0,1]];
        end
    end
end
ee = etmp;

%--------------------------------------
function [p,t,ec] = collapse(p,t,ec)
% reorder t and trim p
ttmp = unique(t(:));
pmap = zeros(length(ttmp),1);
for i = 1:length(ttmp)
    pmap(ttmp(i)) = i;
end
t = pmap(t);
ec = pmap(ec);
p = p(find(pmap),:);

%--------------------------------------
function [p,t,ec,ecnum] = mesh_opt(p,t,ec,ecnum,esize,bgm,opt)

if not(exist('opt'))
    opt = [1,1,1,1]; % all operations
end

% edge splitting
if opt(1)
    e = get_te(t);    
    pec = unique(ec(:));
    ecsort = sort(ec,2);
    le = ones(size(e,1),1);
    for i = 1:size(e,1)
        if any(ismember(e(i,:),pec))
            le(i) = esize; % assumming perfect esize on edges
        else
            le(i) = norm(p(e(i,1),:)-p(e(i,2),:));
        end
    end
    I = find(le>1.5*esize);
    paux = zeros(length(I),2);
    for i = 1:length(I)
        paux(i,:) = sum(p(e(I(i),:),:)/2);
    end
    p = [p;paux];
    % should be done without dpartition
    [p,t,ec,ecnum] = dpartition(p,ec,ecnum,bgm);
%     triplot(t,p(:,1),p(:,2)); axis equal; title(['np = ',num2str(size(p,1)),', nt = ',num2str(size(t,1))]); drawnow; pause
end

% calculate quality number
qe = zeros(size(t,1),1);
for i = 1:size(t,1)
    qe(i) = cal_q(p(t(i,:),:));
end

pec = unique(ec(:));

% edge collapsing
if opt(2)
    [e,te,tadj,eadj,padj,pdeg] = get_te(t);
    pe = p(reshape(e',size(e,1)*2,1),:);
    tmp = diff(pe);
    tmp = tmp(1:2:end,:);
    le = sqrt(sum(tmp.^2,2));
    le(find(any(ismember(e,pec),2))) = esize; % no edge splitting if there is an edge node

    % hold on;
    I = find(le<0.75*esize);
    tflag = ones(size(t,1),1);
    while length(I)>0
        i = 1;
        tball = unique([padj{e(I(i),1)},padj{e(I(i),2)}]);
        etmp = get_te(t(tball,:));
        eball = etmp;
        icount = 0;
        for j = 1:size(etmp)
            if not(any(ismember(e(I(i),:),etmp(j,:))))
                icount = icount + 1;
                eball(icount,:) = etmp(j,:);
            end
        end
        eball = eball(1:icount,:);
        pball = eball(1,:);
        while length(pball)<length(unique(eball(:)))
            for j = 1:size(eball)
                if ismember(pball(end),eball(j,:)) && not(all(ismember(eball(j,:),pball)))
                    pball = [pball,setdiff(eball(j,:),pball(end))];
                end
            end
        end
        pball = [pball,pball(1)];


        pnew = sum(p(e(I(i),:),:))/2;
        tnew = zeros(length(pball)-1,3);
        for j = 1:length(pball)-1
            tnew(j,:) = [size(p,1)+1,pball(j),pball(j+1)];
        end
        np = size(p,1);
        nt = size(t,1);
        p = [p;pnew];
        t = [t;tnew];
        tflag(tball) = 0;
        tflag(nt+1:nt+size(tnew,1)) = 1;

        padj{np+1} = nt+1:nt+size(tnew,1);
        for j = 1:length(pball)-1
            padj{pball(j)} = setdiff(padj{pball(j)},tball);
            for k = 1:size(tnew,1)
                if ismember(pball(j),tnew(k,:))
                    padj{pball(j)} = [padj{pball(j)},nt+k];
                end
            end
        end

        ttmp = t(find(tflag),:);
        e = get_te(ttmp);

        pe = p(reshape(e',size(e,1)*2,1),:);
        tmp = diff(pe);
        tmp = tmp(1:2:end,:);
        le = sqrt(sum(tmp.^2,2));
        le(find(any(ismember(e,pec),2))) = esize;
        I = find(le<0.75*esize);

        %     close all;
        %     triplot(t(find(tflag),:),p(:,1),p(:,2));
        %     hold on;
        %     triplot(t(end-size(tnew,1)+1:end,:),p(:,1),p(:,2),'r'); axis equal;
        %     drawnow;
        %     pause
    end
    [p,t,ec] = collapse(p,t(find(tflag),:),ec);
    pec = unique(ec(:));
    [e,te,tadj,eadj,padj,pdeg] = get_te(t);
end

% eliminate node has small vertex degree (vd == 4)
if opt(3)
    tflag = ones(size(t,1),1);
    I = setdiff(find(pdeg == 4),pec);
    while length(I)>0
        i = 1;
        tball = padj{I(i)};
        etmp = get_te(t(tball,:));
        eball = etmp;
        icount = 0;
        for j = 1:size(etmp)
            if not(any(ismember(I(i),etmp(j,:))))
                icount = icount + 1;
                eball(icount,:) = etmp(j,:);
            end
        end
        eball = eball(1:icount,:);
        pball = eball(1,:);
        while length(pball)<length(unique(eball(:)))
            for j = 1:size(eball)
                if ismember(pball(end),eball(j,:)) && not(all(ismember(eball(j,:),pball)))
                    pball = [pball,setdiff(eball(j,:),pball(end))];
                end
            end
        end

        tnew = [pball([1,2,3]);pball([3,4,1]);pball([2,3,4]);pball([4,1,2])];
        qetmp = zeros(1,4);
        for j = 1:4
            qetmp(j) = cal_q(p(tnew(j,:),:));
        end
        if sum(ismember(pball,pec))>=3 % there are corner nodes in pball
            if any([sum(ismember(tnew(1,:),pec)) >= 3,sum(ismember(tnew(2,:),pec)) >= 3])
                tnew = tnew([3,4],:);
            else
                tnew = tnew([1,2],:);
            end
        elseif sum(ismember(pball,pec))>=2 % there are edges in pball
            if any([sum(ismember(tnew(1,:),pec)) >= 2,sum(ismember(tnew(2,:),pec)) >= 2])
                tnew = tnew([3,4],:);
            else
                tnew = tnew([1,2],:);
            end
        else  % any other cases
            if max(qetmp(1:2))>max(qetmp(3:4))
                tnew = tnew([3,4],:);
            else
                tnew = tnew([1,2],:);
            end
        end
        tflag(tball) = 0;
        nt = size(t);
        t = [t;tnew];
        tflag(nt+1:nt+size(tnew,1)) = 1;

        padj{I(i)} = []; pdeg(I(i)) = 0;
        for j = 1:length(pball)
            padj{pball(j)} = setdiff(padj{pball(j)},tball);
            for k = 1:size(tnew,1)
                if ismember(pball(j),tnew(k,:))
                    padj{pball(j)} = [padj{pball(j)},nt+k];
                end
            end
            pdeg(pball(j)) = length(padj{pball(j)});
        end

        I = setdiff(find(pdeg == 4),pec);

        %     close all;
        %     triplot(t(find(tflag),:),p(:,1),p(:,2));
        %     hold on;
        %     triplot(t(end-size(tnew,1)+1:end,:),p(:,1),p(:,2),'r'); axis equal;
        %     drawnow;
        %     pause
    end
    [p,t,ec] = collapse(p,t(find(tflag),:),ec);
    pec = unique(ec(:));
end

if opt(4)
    % laplacian nodal smoothing
    [e,te,tadj,eadj,padj,pdeg] = get_te(t);
    
    if (length(p)-length(padj))
        keyboard
    end
    omega = 0.5;
    for i = 1:size(p,1)
        if not(ismember(i,pec))
            pt = t(padj{i},:);
            pball = setdiff(unique(pt(:)),i);
            eball = zeros(length(padj{i}),2);
            pe = zeros(length(padj{i}),2);
            for j = 1:length(padj{i})
                eball(j,:) = setdiff(t(padj{i}(j),:),i);
            end
            for j = 1:size(eball,1)
                pe(j,:) = sum(p(eball(j,:),:))/2;
            end
            paux = sum([qe(padj{i}).*pe(:,1),qe(padj{i}).*pe(:,2)])/sum(qe(padj{i}));
            p(i,:) = (1-omega)*p(i,:) + omega*paux;
        end
    end
end

% figure(2);
% triplot(t,p(:,1),p(:,2)); axis equal;
% title(['np = ',num2str(size(p,1)),', nt = ',num2str(size(t,1))]);

% I = find(qe>1.5);
% hold on;
% for i = 1:size(I,1)
%     pe = p(t(I(i),:),:);
%     fill(pe(:,1),pe(:,2),'r');
% end
% 
% keyboard

%-----------------------------------------------------
function [p,ec,ecnum,ect] = mesh_ref(p,t,ec,ecnum,ect,gfun,esize,gref,grefnum)
% finding refinement entities
pref = gref{1}(find(gref{1}(:,2) >= grefnum),1);
lref = gref{2}(find(gref{2}(:,2) >= grefnum),1);
[e,te,tadj,eadj,padj] = get_te(t);
tri = [];
for i = 1:size(pref,1)
    tri = [tri,padj{pref(i)}];
end
ecref = ec(find(ismember(ecnum,lref)),:);
lref = find(ismember(sort(e,2),ecref,'rows'));
for i = 1:size(lref,1)
    tri = [tri,eadj(lref(i),:)];
end
tri = setdiff(unique(tri),0);

% expand the tri set to one more ring
I = unique(t(tri,:));
tri = [];
for i = 1:length(I)
    tri = [tri,padj{I(i)}];
end
tri = unique(tri);

eref = sort(get_te(t(tri,:)),2);
eref = eref(find(get_le(p,eref)>esize),:);

ptmp = zeros(size(eref,1),2);
np = size(p,1);
nec = size(ec,1); ecflag = ones(nec,1);
tt = t;
for i = 1:size(eref,1)
    % should put gfun here later
    pe = p(eref(i,:),:);
    ptmp(i,:) = sum(pe)/2;
    if ismember(eref(i,:),ec,'rows')
        J = find(ismember(ec,eref(i,:),'rows'));
        I = ecnum(J);
        if gfun{I}{3}
            t = sum(ect(J,:))/2;
            ptmp(i,:) = [eval(gfun{I}{1}{1}),eval(gfun{I}{1}{2})];
%             % binary search
%             tend = gfun{I}{2};
%             mt = sum(tend)/2; 
%             t = mt; mp = [eval(gfun{I}{1}{1}),eval(gfun{I}{1}{2})];
%             t = tend(1); pend(1,:) = [eval(gfun{I}{1}{1}),eval(gfun{I}{1}{2})];
%             t = tend(2); pend(2,:) = [eval(gfun{I}{1}{1}),eval(gfun{I}{1}{2})];
%             f = sum((mp-pe(1,:)).^2)-sum((mp-pe(2,:)).^2);
%             fend = [sum((pend(1,:)-pe(1,:)).^2)-sum((pend(1,:)-pe(2,:)).^2),sum((pend(2,:)-pe(1,:)).^2)-sum((pend(2,:)-pe(2,:)).^2)];
%             if fend(1)>fend(2)
%                 tend = tend([2,1]);
%             end
%             while abs(f)>1e-8
%                 if f<0
%                     tend(1) = mt;
%                 else
%                     tend(2) = mt;
%                 end
%                 mt = sum(tend)/2;
%                 t = mt; mp = [eval(gfun{I}{1}{1}),eval(gfun{I}{1}{2})];
%                 f = sum((mp-pe(1,:)).^2)-sum((mp-pe(2,:)).^2);
%             end
%             ptmp(i,:) = mp;
        end
    end
    iec = find(ismember(ec,eref(i,:),'rows'));
    if iec
        ecflag(iec) = 0;
        ec = [ec; ec(iec,1), np+i; ec(iec,2), np+i];
        ecnum = [ecnum; ecnum(iec); ecnum(iec)];
        ect = [ect; ect(iec,1), sum(ect(iec,:))/2; ect(iec,2), sum(ect(iec,:))/2];
        ecflag = [ecflag;1;1];
    end
end
ec = ec(find(ecflag),:);
ecnum = ecnum(find(ecflag),:);
ect = ect(find(ecflag),:);
p = [p;ptmp];
t = tt;

% close all;
% hold on;
% triplot(t,p(:,1),p(:,2)); axis equal;
% plot(p(pref,1),p(pref,2),'.r');
% for i = 1:size(ecref,1)
%     plot(p(ecref(i,:),1),p(ecref(i,:),2),'-r','LineWidth',2);
% end
% triplot(t(tri,:),p(:,1),p(:,2),'r');
% plot(ptmp(:,1),ptmp(:,2),'xk');
% keyboard

%-----------------------------------------------------
function tnum = find_tnum(t,ec,ecnum)
% find domain-tri connection using coloring algorithm
% (similar to the dpartition)
% find a list of adjacent tris that share the same edges
% first, we find duplicated edges and an associated tri list
ttmp = sort(t,2);
etmp = [t(:,[1,2]);t(:,[2,3]);t(:,[3,1])];
nt = size(t,1);
trinum = repmat((1:nt)',3,1);
etmp = sort(etmp,2);
[etmp,tags] = sortrows(etmp);
eflagtmp = zeros(size(etmp,1),1);
for i = 1:max(ecnum)
    I = find(ecnum == i);
    eflagtmp = eflagtmp + i*ismember(etmp,ec(find(ecnum==i),:),'rows');
end
trinum = trinum(tags);
tags = find(all(diff(etmp,[],1)==0,2));
% then we find the list of adjacent tris
tadj = zeros(size(t,1),3);
tadjflag = zeros(size(t,1),3);
tadjcount = zeros(size(t,1),1);
for i = 1:size(tags,1)
    itmp = [trinum(tags(i)),trinum(tags(i)+1)];
    for j = 1:2
        tadjcount(itmp(j)) = tadjcount(itmp(j))+1;
        if eflagtmp(tags(i))>0
            tadjflag(itmp(j),tadjcount(itmp(j))) = eflagtmp(tags(i));
        end
    end
    tadj(itmp(1),tadjcount(itmp(1))) = itmp(2);
    tadj(itmp(2),tadjcount(itmp(2))) = itmp(1);    
end
tnum = -ones(size(t,1),1);
fnum = 1;
current_tri = 1;
tri_list = 1;
while sum(find(tnum == -1))
    i = 1;
    while i<=length(tri_list)
        current_tri = tri_list(i);
        for j = 1:3
            if tadj(current_tri,j) ~= 0 && tnum(tadj(current_tri,j)) == -1 && tadjflag(current_tri,j) == 0
                tnum(tadj(current_tri,j)) = fnum;
                if not(ismember(tadj(current_tri,j),tri_list))
                    tri_list = [tri_list, tadj(current_tri,j)];
                end
            end
        end
        i = i+1;
    end
    fnum = fnum+1;
    % Step 4: empty and then re-create the list
    tri_list = find(tnum == -1);
    if length(tri_list)>0
        tri_list = tri_list(1);
    end
end