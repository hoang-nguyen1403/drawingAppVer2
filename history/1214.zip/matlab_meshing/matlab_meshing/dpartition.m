% return a background mesh when call with one input argument
function [p,t,ec,ecnum] = dpartition(pp,ee,enum,bgm,isplot)

if not(exist('isplot'))
    isplot = 0;
end

% if iscell(ee) %% this should be only used for create bgm...
%     ee_old = ee;
%     if size(ee)<3 % no extra contrained edges
%         ee{3} = [];
%     end
%     eeflag = [ones(size(ee{1},1),1);-1*ones(size(ee{2},1),1);0*ones(size(ee{3},1),1)];
%     eb = [ee{1};ee{2}]; % outer and inner boundaries
%     ee = [ee{1};ee{2};ee{3}]; % ee{3} contains extra constrained edges    
%     ee = sort(ee,2);    
%     [ee,I] = unique(ee,'rows');
%     eeflag = eeflag(I);
% else
%     eeflag = ones(size(ee,1),1);
% end

if iscell(ee) %% this should be only used for create bgm...
    ee_old = ee;
    if size(ee)<3 % no extra contrained edges
        ee{3} = [];
    end
    epnum = size(ee{1},1);
    eb = [ee{1};ee{2}]; % outer and inner boundaries
    ee = [ee{1};ee{2};ee{3}]; % ee{3} contains extra constrained edges    
    ee = sort(ee,2);
    eeflag = (1:size(ee,1))';
    ebnum = size(eb,1);
    [ee,I] = unique(ee,'rows');
    eeflag = eeflag(I);
else
    eeflag = ones(size(ee,1),1);
    ebnum = 1;
    epnum = 1;
end

% if we have a background mesh, use it
if exist('bgm') && not(isempty(bgm))
    
    if not(exist('enum')) || isempty(enum)
        enum = ones(size(ee,1),1);
    end

    % generate a constrained delaunay with constrainted ee edges
    p = pp;
    [p,t,ec,ecnum] = cdelaunay(p,ee,enum,1);
    
    % eliminate the "negative" tris using background mesh
    pc = zeros(size(t,1),2);
    for i = 1:size(t,1)
        pc(i,:) = sum(p(t(i,:),:))/3;
    end
    
    tout = bgm.t(find(bgm.tflag==0),:);
    tflag = zeros(size(t,1),size(tout,1));
    for i = 1:size(tout,1)
        tmp = inpolygon(pc(:,1),pc(:,2),bgm.p(tout(i,:),1),bgm.p(tout(i,:),2));
        tflag(:,i) = tmp;
    end
    tflag = any(tflag,2);
    
    % generate p, e, t and quit
    t = t(not(tflag),:);
    trinum = unique(t(:));
    pflag = ones(size(p,1),1);
    pflag(setdiff(1:max(trinum),trinum)) = 0;

    I = find(pflag);
    p = p(I,:);
    pmap = zeros(max(trinum),1);
    for i = 1:length(I)
        pmap(I(i)) = i;
    end
    t = pmap(t);
    ec = pmap(ec);
%     e = unique(sort([t(:,[1,2]);t(:,[2,3]);t(:,[3,1])],2),'rows');
    
%     triplot(t,p(:,1),p(:,2)); axis equal;
%     keyboard
        
    return;
end

% no background mesh

pbox = [min(pp(:,1)), max(pp(:,1));min(pp(:,2)), max(pp(:,2))];
lbox = [pbox(1,2)-pbox(1,1),pbox(2,2)-pbox(2,1)];
cbox = [pbox(1,2)+pbox(1,1),pbox(2,2)+pbox(2,1)]/2;
padd = [cbox(1) - lbox(1), cbox(2) - lbox(2); cbox(1) + lbox(1), cbox(2) - lbox(2); cbox(1) + lbox(1), cbox(2) + lbox(2); cbox(1) - lbox(1), cbox(2) + lbox(2)];
p = [pp; padd];

% p = [padd;pp]; ee = ee + size(padd,1);

[p,t,ec,ecflag] = cdelaunay(p,ee,eeflag);
I = find(ecflag<=ebnum);
ebflag = ecflag(I);
eb = ec(I,:);
I = find(ecflag<=epnum);
ep = ec(I,:);

e = get_te(t);
% find list of boundary edges
eflag = zeros(size(e,1),1);
for i = 1:size(e,1)
    if ismember(e(i,:),ec,'rows')
        eflag(i) = 1;
    end
end

% box flag
bflag = zeros(size(p,1),1);
bflag(size(pp,1)+1:size(pp,1)+size(padd,1)) = 1;
% bflag(1:size(padd)) = 1;

% find a list of adjacent tris that share the same edges
% first, we find duplicated edges and an associated tri list
ttmp = sort(t,2);
etmp = [t(:,[1,2]);t(:,[2,3]);t(:,[3,1])];
nt = size(t,1);
trinum = repmat((1:nt)',3,1);
etmp = sort(etmp,2);
ebtmp = sort(eb,2);
[etmp,tags] = sortrows(etmp);
% flag positive boundary edges to 1, and 2 to negative boundary edges
eflagtmp = ismember(etmp,ebtmp(find(ebflag<=epnum),:),'rows')+2*ismember(etmp,ebtmp(find(ebflag>epnum),:),'rows'); 
trinum = trinum(tags);
tags = find(all(diff(etmp,[],1)==0,2));
% then we find the list of adjacent tris
tadj = zeros(size(t,1),3);
tadjflag = zeros(size(t,1),3);
tadjcount = zeros(size(t,1),1);
for i = 1:size(tags,1)
    itmp = [trinum(tags(i)),trinum(tags(i)+1)];
    for j = 1:2
        tadjcount(itmp(j)) = tadjcount(itmp(j))+1;
        if eflagtmp(tags(i))>0
            tadjflag(itmp(j),tadjcount(itmp(j))) = eflagtmp(tags(i));
        end
    end
    tadj(itmp(1),tadjcount(itmp(1))) = itmp(2);
    tadj(itmp(2),tadjcount(itmp(2))) = itmp(1);    
end
% toc

if isplot
    % plot the triangulation
    triplot(t,p(:,1),p(:,2));
    hold on;
    for i = 1:size(ee,1)
        plot(p(ee(i,:),1),p(ee(i,:),2),'-or');
    end
    for i = 1:size(e,1)
        if eflag(i)
            plot(p(e(i,:),1),p(e(i,:),2),'-xk');
        end
    end
    for i = 1:size(t,1)
        ptmp = sum(p(t(i,:),:))/3;
        text(ptmp(1),ptmp(2),num2str(i));
    end
    hold off;
end

% eliminate tri
% Step 1: init v and c values
tv = -ones(size(t,1),1);
c = 0;
% Step 2: find a tri contain a box vertex and put it in the list
i = 1;
while i<size(t,1)
    if sum(find(bflag(t(i,:))))
        break;
    end
    i = i+1;
end
tv(i) = c;
current_tri = i;
tri_list = i;
while sum(find(tv == -1))
    i = 1;
    % Step 3: visit and update the list
    while i<=length(tri_list)
        [tv,tri_list] = r_process(tri_list(i),tadj,tadjflag,c,tv,tri_list);
        i = i+1;
    end
    
%     triplot(t(find(tv==c),:),p(:,1),p(:,2));
%     pause
    
    c = c+1;
    % Step 4: empty and then re-create the list
    tri_list = find(tv == -1);
    if length(tri_list)>0
        % the next first tri should contains no inner (holes) boundary
        if c == 1 && epnum<ebnum % there are holes
            tadjflagtmp = sort(tadjflag(tri_list,:),2);
            [tmp,I] = ismember(tadjflagtmp,[0,0,1;0,1,1;1,1,1],'rows');
            I = find(I);
            tri_list = tri_list(I(1));
        else
            tri_list = tri_list(1);
        end
    end
end

% save the background mesh (if there is only one output)
if nargout == 1
    bgm.p = p;
    bgm.t = t;
    bgm.tflag = zeros(size(t,1),1);
    bgm.tflag(find(tv == 1)) = 1;
    bgm.ec = ec;
    bgm.ecnum = ecflag;
    p = bgm;
    return;
end

% t = t(find(tv>0),:); % all the internal tri
to = t(find(tv~=1),:); % all the internal tris in holes
t = t(find(tv==1),:); % all the internal tris except those in holes


if isplot
    hold on;
    for i = 1:size(t,1)
        fill(p(t(i,:),1),p(t(i,:),2),'r');
    end
    hold off;
    axis equal;
end

% remove outer p,t and regenerate e
trinum = unique(t(:));
pflag = ones(size(p,1),1);
pflag(setdiff(1:max(trinum),trinum)) = 0;

I = find(pflag);
p = p(I,:);
pmap = zeros(max(trinum),1);
for i = 1:length(I)
    pmap(I(i)) = i;
end
t = pmap(t);

% p = [p(1:size(pp,1),:);p(size(pp,1)+1+size(padd,1):end,:)];
% % correct t
% for i = 1:3
%     I = find(t(:,i)>size(pp,1)+size(padd,1));
%     t(I,i) = t(I,i)-size(padd,1);
% end
e = unique(sort([t(:,[1,2]);t(:,[2,3]);t(:,[3,1])],2),'rows');

function [tv,tri_list] = r_process(current_tri,tadj,tadjflag,c,tv,tri_list)
for i = 1:3
    if tadj(current_tri,i) ~= 0 && tv(tadj(current_tri,i)) == -1 && tadjflag(current_tri,i) == 0
        tv(tadj(current_tri,i)) = c;
        if not(ismember(tadj(current_tri,i),tri_list))
            tri_list = [tri_list, tadj(current_tri,i)];
        end
    end
end