function f = secondAPI(n)
fileName = 'UIp_FE.json';
data = fileread(fileName);
f = jsondecode(data);
end