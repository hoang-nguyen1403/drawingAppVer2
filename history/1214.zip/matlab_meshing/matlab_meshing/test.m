clear;
clc;
% [p,t,ec,ecnum,tnum] = meshing2d(pp,ee,gfun,gref,esize);
% pp = [0,0; 4,0; 2,3 ; 1.5,0.5;2.5,0.5;2.5,1.5;1.5,1.5];
% ee = {[1,2;2,3;3,1],[4,5;5,6;6,7;7,4]}; 
% esize = 0.5;
% [p,t,ec,ecnum,tnum] = meshing2d(pp,ee,[],[],esize);

%--------------------------------------------------------------- OK
% pp = [0,0;3,0;3,1;3,2;3,3;3,4;2,4;2,1;1,1;1,4;0,4;0,3;0,2;0,1];
% ee = [1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12,13;13,14;14,1]; 
% % gref = {[1,2;2,3],[6,3;7,2]};
% esize = 0.05;
% [p,t,ec,ecnum,tnum] = meshing2d(pp,ee,[],[],esize);

% ---------------------------------------------- OK
% pp = [0,0;3,0;3,10;-1,10;-1,3;0,3;0,6;2,6;2,1;1,1;1,2;0,2;0.5,7;1.5,7;2,8;1,9;0,8];
% ee = {[1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12,1],[13,14;14,15;15,16;16,17;17,13],[16,3;16,4;7,13;8,14]};
% gref = {[],[13,4;14,4;15,4;16,4;17,4]};
% esize = 0.3;
% [p,t,ec,ecnum,tnum] = meshing2d(pp,ee,[],gref,esize);

% --------------------------------------------------
% pp = [0,0;3,0;3,10;2,10;2,1;1,1;1,2;0,2];
% ee = [1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,1];
% for i = 1:size(ee,1) 
%     gfun{i} = {0,0,0}; 
% end
% gfun{1} = {{'1.5+1.5*cos(t)','2.5*sin(t)'},[-pi,0],1};
% gref = {[],[1,3]};
% esize = 0.5;
% [p,t,ec,ecnum,tnum] = meshing2d(pp,ee,gfun,gref,esize);

% ----------------------------------------------- OK
% pp = [0         0;    0.3750         0;    0.6250         0;    1.0000         0;    1.0000    0.2500;    1.0000    0.7500;    1.0000    1.0000;    0.6250    1.0000;    0.3750    1.0000;         0    1.0000;         0    0.7500;         0    0.2500;    0.3750    0.2500;    0.6250    0.2500;    0.6250    0.7500;    0.3750    0.7500];
% ee = {[1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;1,12],[13,14;14,15;15,16;13,16],[2,12;2,13;2,14;3,14;4,14;5,14;5,15;6,15;7,15;8,15;9,11;9,15;9,16;11,13;11,16;12,13]};
% esize = 0.5;
% [p,t,ec,ecnum,tnum] = meshing2d(pp,ee,[],[],esize);
% =======================================================

f = readFileJSON('dataMatlab.json');
% % % % pp = f.('node_coords');
pp = f.node_coords;
e = f.segments;
for i=1:size(e,1)
    for j=1:size(e,2)
        ee(i,j)=(e(i,j)+1);
    end
end
esize = 5;
% disp(ee);

% pp = [0,0;3,0;3,1;3,2;3,3;3,4;2,4;2,1;1,1;1,4;0,4;0,3;0,2;0,1];
% ee = [1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12,13;13,14;14,1];

disp(pp);
disp(ee);

%p: coordinate of all Points (FEcoord)
%t: link point (FETri)


[p,t,ec,ecnum,tnum] = meshing2d(pp,ee,[],[],esize);
result = returnJSON(f,t,p,[],[]);
fid=fopen('result.json','w');
fprintf(fid,'%s',result);
fclose(fid);

function f = readFileJSON(fileName)
data = fileread(fileName);
f = jsondecode(data);
end

function resultFile = returnJSON(f,FEtri,FEcoord,FEsoln,QC)
% s = struct("num_nodes",f.num_nodes ,"num_segments",f.num_segments ,"node_coords",f.node_coords,"node_names",f.node_names,"segments",f.segments,"segment_names",f.segment_names,"surfaces",f.surfaces,"surface_names",f.surface_names,"nodal_loads",f.nodal_loads,"segment_loads",f.segment_loads)
result.jsmat = {struct(f)};
result.FEtri = {FEtri};
result.FEcoord = {FEcoord};
if not(exist('FEsoln')) || isempty(FEsoln)
    result.FEsoln = {};
end

if not(exist('QC')) || isempty(QC)
    result.QC = {};
end
resultFile = jsonencode(result);
end

               













