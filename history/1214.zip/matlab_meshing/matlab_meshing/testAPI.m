clear;
clc;
params= [1,2,3,4];
pname = 'listData';
res=mps_PALc(pname,params);