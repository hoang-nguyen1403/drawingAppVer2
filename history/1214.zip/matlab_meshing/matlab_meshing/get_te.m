%---------------------------------------
% get list of edge and tri associated with edges
function [e,te,tadj,eadj,padj,pdeg] = get_te(t);

e = [t(:,[1,2]);t(:,[2,3]);t(:,[3,1])];
ne = size(e,1);
ee = sort(e,2);
[ee,I,J] = unique(ee,'rows');
e = e(I,:);

if nargout == 1    
    return;
end

te = reshape(reshape(1:ne,size(t,1),3)',size(t,1)*3,1);
te = reshape(J(te),3,size(t,1))';

if nargout == 2
    return;
end

% find a list of adjacent triangles for each triangle
% first, we find duplicated edges and an associated tri list
ttmp = sort(t,2);
etmp = [t(:,[1,2]);t(:,[2,3]);t(:,[3,1])];
nt = size(t,1);
trinum = repmat((1:nt)',3,1);
etmp = sort(etmp,2);
[etmp,tags] = sortrows(etmp);
trinum = trinum(tags);
tags = find(all(diff(etmp,[],1)==0,2));
% then we find the list of adjacent tris
tadj = zeros(size(t,1),3);
tadjcount = zeros(size(t,1),1);
for i = 1:size(tags,1)
    itmp = [trinum(tags(i)),trinum(tags(i)+1)];
    for j = 1:2
        tadjcount(itmp(j)) = tadjcount(itmp(j))+1;
    end
    tadj(itmp(1),tadjcount(itmp(1))) = itmp(2);
    tadj(itmp(2),tadjcount(itmp(2))) = itmp(1);    
end

if nargout == 3
    return;
end

% find a list of adjacent triangles for each edge
etmp = te(:);
[etmp,tags] = sort(etmp);
trinum = repmat((1:size(te,1))',3,1);
trinum = trinum(tags);
tags = find(diff(etmp)==0); % the share edges
ntags = find(diff(etmp)~=0); % the rest
eadj = zeros(size(e,1),2);
eadjcount = zeros(size(e,1),1);
for i = 1:size(etmp,1);
    itmp = etmp(i);
    eadjcount(itmp) = eadjcount(itmp) + 1;
    eadj(itmp,eadjcount(itmp)) = trinum(i);
end
eadj = sort(eadj,2);

if nargout == 4
    return;
end

% find a list of adjacent triangles for each node
[ptmp, tags] = sort(t(:));
trinum = repmat((1:size(t,1))',3,1);
trinum = trinum(tags);
nump = length(unique(t(:)));
tags = find(diff(ptmp) == 1);

for i = 1:size(tags,1)
    if i == 1
        padj{1} = (trinum(1:tags(1)))';
    else
        padj{i} = (trinum(tags(i-1)+1:tags(i)))';
    end
end
padj{size(tags,1)+1} = (trinum(tags(end)+1:size(trinum,1)))';
pdeg = ones(nump,1);
% vertex degree
for i = 1:nump
    pdeg(i) = length(padj{i});
end
