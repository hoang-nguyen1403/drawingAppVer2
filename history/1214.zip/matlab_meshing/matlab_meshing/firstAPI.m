function f = firstAPI(n,m)
% fileName = 'UIp_FE.json';
% data = fileread(fileName);
% f = jsondecode(data);
fid=fopen('MatlabResquest.json','w');
fprintf(fid,'%s',m);
fclose(fid);
fileName = 'MatlabResquest.json';
data = fileread(fileName);
f = jsondecode(data);
end