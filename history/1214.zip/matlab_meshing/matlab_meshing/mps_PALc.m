function res=mps_PALc(pname,params)

% Import HTTP interface packages
import matlab.net.*
import matlab.net.http.*
import matlab.net.http.fields.*

% Setup message body
body = MessageBody;
payload = mps.json.encoderequest({pname,params});
disp(payload)

body.Payload = payload;

% Setup request
% requestUri = URI('http://34.23.153.57:5902/matfun/mps_PAL');
requestUri = URI('http://localhost:5902/matfun/mps_PAL')
options = matlab.net.http.HTTPOptions('ConnectTimeout',20,...
    'ConvertResponse',false);
request = RequestMessage;
request.Header = HeaderField('Content-Type','application/json');
request.Method = 'POST';
request.Body = body;

% Send request
response = request.send(requestUri, options);

res=response.Body.Data;
